'use client';

import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { PurchaseOrder } from '@/lib/firestore/suppliers';
import { getPurchaseOrder } from '@/lib/firestore/purchase_orders_db';
import PurchaseOrderForm from '../../../../components/admin/PurchaseOrderForm';

const PurchaseOrderDetailPage = () => {
  const router = useRouter();
  const params = useParams();
  const id = params?.id as string;
  const [order, setOrder] = useState<PurchaseOrder | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrder = async () => {
      try {
        const fetchedOrder = await getPurchaseOrder(id);
        setOrder(fetchedOrder);
      } catch (err) {
        console.error('Failed to fetch purchase order:', err);
      } finally {
        setLoading(false);
      }
    };
    if (id) {
      fetchOrder();
    }
  }, [id]);

  const handleSuccess = () => {
    router.push('/admin/purchase-orders');
  };

  const handleCancel = () => {
    router.push('/admin/purchase-orders');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  if (!order) {
    return <div className="text-center py-12">Purchase order not found</div>;
  }

  return (
    <div>
      <div className="mb-6">
        <button
          onClick={handleCancel}
          className="text-gray-500 hover:text-gray-700 flex items-center gap-1 text-sm font-medium"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
            <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
          </svg>
          Back to Purchase Orders
        </button>
      </div>
      <PurchaseOrderForm orderId={id} onSuccess={handleSuccess} onCancel={handleCancel} />
    </div>
  );
};

export default PurchaseOrderDetailPage;

