'use client';

import React, { useEffect, useState } from 'react';
import { getAllProducts, updateProduct } from '@/lib/firestore/products_db';
import { Product } from '@/lib/firestore/products';
import { checkLowStock } from '@/lib/firestore/inventory_alerts_db';
import Image from 'next/image';
import Link from 'next/link';

const StockManagementPage = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState<string | null>(null); // Product ID being updated
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const fetchedProducts = await getAllProducts();
      setProducts(fetchedProducts);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStockChange = (productId: string, variantId: string | null, newStock: number) => {
    setProducts(prevProducts =>
      prevProducts.map(product => {
        if (product.id !== productId) return product;

        if (variantId) {
          // Update variant stock
          const updatedVariants = product.variants.map(variant =>
            variant.id === variantId ? { ...variant, stock: newStock } : variant
          );
          return { ...product, variants: updatedVariants };
        } else {
            // Update main product stock (if we had a main stock field, but currently structure uses variants mostly)
            // If product has no variants, we might want to store stock on the product itself?
            // Based on Product interface, stock is only on variants.
            // If the user wants to manage simple products without variants, we should probably check if we need to add stock to the main product interface.
            // For now, let's assume we are editing variants.
            return product;
        }
      })
    );
  };

  const saveStock = async (product: Product) => {
    setUpdating(product.id);
    try {
      // Only update the variants field to save bandwidth/risk
      await updateProduct(product.id, { variants: product.variants });
      
      // Check for low stock alerts after updating
      const LOW_STOCK_THRESHOLD = 10; // Default threshold
      for (const variant of product.variants) {
        await checkLowStock(product.id, variant.id, variant.stock, LOW_STOCK_THRESHOLD);
      }
      
      // Show success feedback if needed
    } catch (error) {
      console.error('Error updating stock:', error);
      alert('Failed to update stock');
    } finally {
      setUpdating(null);
    }
  };
  
  // Filter products based on search
  const filteredProducts = products.filter(product => 
    product.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Stock Management</h1>
        <div className="flex items-center gap-4">
          <Link
            href="/admin/inventory-alerts"
            className="px-4 py-2 bg-yellow-100 text-yellow-800 rounded-lg hover:bg-yellow-200 transition-colors flex items-center gap-2 text-sm font-medium"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
            </svg>
            View Alerts
          </Link>
          <div className="relative">
               <input 
                  type="text" 
                  placeholder="Search products..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none w-64"
               />
               <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-gray-400 absolute left-3 top-2.5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
               </svg>
          </div>
        </div>
      </div>

      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
                <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Variants & Stock</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
                {filteredProducts.map((product) => (
                <tr key={product.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                        <div className="h-10 w-10 flex-shrink-0 relative rounded-md overflow-hidden bg-gray-100 border border-gray-200">
                            {product.images && product.images.length > 0 ? (
                                <Image src={product.images[0]} alt={product.name} fill className="object-cover" />
                            ) : (
                                <div className="flex items-center justify-center h-full w-full text-xs text-gray-400">No Img</div>
                            )}
                        </div>
                        <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">{product.name}</div>
                        <div className="text-sm text-gray-500">PKR {product.price}</div>
                        </div>
                    </div>
                    </td>
                    <td className="px-6 py-4">
                        {product.variants && product.variants.length > 0 ? (
                            <div className="space-y-2">
                                {product.variants.map((variant) => (
                                    <div key={variant.id} className="flex items-center gap-3">
                                        <span className="text-sm text-gray-600 w-24 truncate" title={`${variant.name}: ${variant.value}`}>
                                            {variant.name}: {variant.value}
                                        </span>
                                        <div className={`flex items-center border rounded-md overflow-hidden ${
                                          variant.stock === 0 
                                            ? 'border-red-300 bg-red-50' 
                                            : variant.stock <= 10 
                                            ? 'border-yellow-300 bg-yellow-50' 
                                            : 'border-gray-300'
                                        }`}>
                                            <input 
                                                type="number" 
                                                min="0"
                                                value={variant.stock}
                                                onChange={(e) => handleStockChange(product.id, variant.id, parseInt(e.target.value) || 0)}
                                                className={`w-20 px-2 py-1 text-sm outline-none text-center ${
                                                  variant.stock === 0 
                                                    ? 'text-red-600 font-semibold' 
                                                    : variant.stock <= 10 
                                                    ? 'text-yellow-600 font-medium' 
                                                    : ''
                                                }`}
                                            />
                                        </div>
                                        {variant.stock <= 10 && (
                                          <span className={`text-xs px-2 py-1 rounded-full ${
                                            variant.stock === 0 
                                              ? 'bg-red-100 text-red-800' 
                                              : 'bg-yellow-100 text-yellow-800'
                                          }`}>
                                            {variant.stock === 0 ? 'Out of Stock' : 'Low Stock'}
                                          </span>
                                        )}
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="text-sm text-gray-500 italic">No variants configured</div>
                        )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button
                            onClick={() => saveStock(product)}
                            disabled={updating === product.id}
                            className={`px-4 py-2 rounded-md text-white font-medium transition-colors ${
                                updating === product.id 
                                    ? 'bg-blue-400 cursor-not-allowed' 
                                    : 'bg-blue-600 hover:bg-blue-700'
                            }`}
                        >
                            {updating === product.id ? 'Saving...' : 'Update Stock'}
                        </button>
                    </td>
                </tr>
                ))}
            </tbody>
            </table>
        </div>
        {filteredProducts.length === 0 && (
            <div className="text-center py-12 text-gray-500">
                No products found matching &quot;{searchTerm}&quot;
            </div>
        )}
      </div>
    </div>
  );
};

export default StockManagementPage;