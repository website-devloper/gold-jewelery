'use client';

import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import dynamic from 'next/dynamic';
import { getPageBySlug, updatePageTranslation } from '@/lib/firestore/pages_db';
import { PAGE_SLUGS, Page, PageContentTranslation } from '@/lib/firestore/pages';
import { Timestamp } from 'firebase/firestore';
import { getAllLanguages } from '@/lib/firestore/internationalization_db';
import { Language } from '@/lib/firestore/internationalization';
import { useLanguage } from '../../../../context/LanguageContext';
import { storage } from '@/lib/firebase';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { getAllStoreLocations, createStoreLocation, updateStoreLocation, deleteStoreLocation } from '@/lib/firestore/store_locations_db';
import { StoreLocation } from '@/lib/firestore/store_locations';
import 'react-quill/dist/quill.snow.css';

// Polyfill for findDOMNode in React 19 (React Quill compatibility)
if (typeof window !== 'undefined') {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const ReactDOM = require('react-dom');
  if (!ReactDOM.findDOMNode) {
    ReactDOM.findDOMNode = (node: unknown): Node | null => {
      if (!node) return null;
      if (node && typeof node === 'object' && 'nodeType' in node && (node as { nodeType: number }).nodeType === 1) {
        return node as Node;
      }
      if (node && typeof node === 'object' && 'current' in node) {
        return (node as { current: Node | null }).current;
      }
      if (node && typeof node === 'object' && 'getDOMNode' in node) {
        const getDOMNode = (node as { getDOMNode: () => Node | null }).getDOMNode;
        return getDOMNode();
      }
      return null;
    };
  }
}

// Dynamically import ReactQuill to avoid SSR issues
// Note: React Quill 2.0.0 has compatibility issues with React 19
// We'll use a workaround by patching findDOMNode
const ReactQuill = dynamic(
  async () => {
    if (typeof window === 'undefined') {
      return () => null;
    }
    
    console.log('[PageEditor] Loading ReactQuill module...');
    const ReactQuillModule = await import('react-quill');
    const RQ = ReactQuillModule.default;
    console.log('[PageEditor] ReactQuill module loaded');
    
    // Return the component as-is - the error might be from internal usage
    // which we can't easily fix, but the component should still work
    return RQ;
  },
  { 
    ssr: false,
    loading: () => {
      console.log('[PageEditor] ReactQuill loading...');
      return <div className="w-full h-[400px] border border-gray-300 rounded-lg flex items-center justify-center bg-gray-50">
        <div className="text-gray-500">Loading editor component...</div>
      </div>;
    }
  }
);

interface FAQItem {
  question: string;
  answer: string;
}

interface JobItem {
  title: string;
  department: string;
  location: string;
  type: string; // Full-time, Part-time, Contract, etc.
  description: string;
  requirements: string;
  isActive: boolean;
}

interface SizeGuideRow {
  sizeLabel: string;
  length: string;
  chest: string;
  sleeve: string;
  heightRange: string;
}

interface MeasureGuideItem {
  label: string;
  description: string;
}

interface StoreLocationItem {
  id?: string;
  name: string;
  address: string;
  city: string;
  state: string;
  country: string;
  zipCode: string;
  phone: string;
  email: string;
  latitude: number;
  longitude: number;
  description: string;
  isActive: boolean;
}

const PageEditor = () => {
  const params = useParams();
  const slug = params.slug as string;
  const pageTitle = PAGE_SLUGS[slug as keyof typeof PAGE_SLUGS] || 'Unknown Page';
  const { currentLanguage } = useLanguage();
  const [, setQuillInstance] = useState<{ root: { innerHTML: string } } | null>(null);
  const quillRef = React.useRef<{ root: { innerHTML: string }; clipboard?: { convert: (html: string) => unknown } } | null>(null);
  const [isClient, setIsClient] = useState(false);
  const isLoadingRef = React.useRef(false);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [page, setPage] = useState<Page | null>(null);
  const [languages, setLanguages] = useState<Language[]>([]);
  const [selectedLanguageCode, setSelectedLanguageCode] = useState<string>('en');
  
  // FAQ-specific state
  const [faqItems, setFaqItems] = useState<FAQItem[]>([]);
  
  // Careers-specific state
  const [jobItems, setJobItems] = useState<JobItem[]>([]);

  // Size Guide-specific state
  const [sizeRows, setSizeRows] = useState<SizeGuideRow[]>([
    { sizeLabel: '50 (XS)', length: '50"', chest: '20"', sleeve: '26"', heightRange: `4'10" - 5'0"` },
    { sizeLabel: '52 (S)', length: '52"', chest: '21"', sleeve: '27"', heightRange: `5'1" - 5'2"` },
    { sizeLabel: '54 (M)', length: '54"', chest: '22"', sleeve: '28"', heightRange: `5'3" - 5'4"` },
    { sizeLabel: '56 (L)', length: '56"', chest: '23"', sleeve: '29"', heightRange: `5'5" - 5'6"` },
    { sizeLabel: '58 (XL)', length: '58"', chest: '24"', sleeve: '30"', heightRange: `5'7" - 5'8"` },
    { sizeLabel: '60 (XXL)', length: '60"', chest: '25"', sleeve: '31"', heightRange: `5'9" +` },
  ]);

  const [measureItems, setMeasureItems] = useState<MeasureGuideItem[]>([
    { label: 'Length', description: 'Measure from the highest point of the shoulder down to the hem.' },
    { label: 'Bust', description: 'Measure across the fullest part of the chest, under the arms.' },
    { label: 'Sleeve', description: 'Measure from the shoulder seam down to the wrist.' },
    { label: 'Hips', description: 'Measure around the fullest part of the hips.' },
  ]);

  const [sizeFootnote, setSizeFootnote] = useState('* Sizes may vary slightly depending on the style and cut.');
  const [supportHeading, setSupportHeading] = useState('Still Unsure?');
  const [supportBody, setSupportBody] = useState("We're here to help you find the perfect fit.");
  const [supportEmail, setSupportEmail] = useState('support@pardah.com');
  
  // Store Locations-specific state
  const [storeLocations, setStoreLocations] = useState<StoreLocationItem[]>([]);
  const [loadingStores, setLoadingStores] = useState(false);
  
  const [formData, setFormData] = useState<PageContentTranslation>({
    languageCode: 'en',
    title: pageTitle,
    content: '',
    metaTitle: '',
    metaDescription: '',
    updatedAt: Timestamp.now(),
  });

  // Parse FAQ content from HTML
  const parseFAQContent = React.useCallback((htmlContent: string) => {
    if (!htmlContent) {
      setFaqItems([]);
      return;
    }
    
    try {
      const parser = new DOMParser();
      const doc = parser.parseFromString(htmlContent, 'text/html');
      const elements = Array.from(doc.body.children);
      const items: FAQItem[] = [];
      
      for (let i = 0; i < elements.length; i++) {
        const element = elements[i];
        const tagName = element.tagName.toLowerCase();
        
        if (tagName.match(/^h[2-6]$/)) {
          const question = element.textContent?.trim() || '';
          let answer = '';
          
          let nextSibling = element.nextElementSibling;
          while (nextSibling && !nextSibling.tagName.match(/^h[1-6]$/)) {
            answer += nextSibling.textContent?.trim() + ' ';
            nextSibling = nextSibling.nextElementSibling;
          }
          
          if (question) {
            items.push({ question, answer: answer.trim() || '' });
          }
        }
      }
      
      setFaqItems(items.length > 0 ? items : [{ question: '', answer: '' }]);
    } catch (error) {
      console.error('Error parsing FAQ content:', error);
      setFaqItems([{ question: '', answer: '' }]);
    }
  }, []);

  // Convert FAQ items to HTML
  const convertFAQToHTML = React.useCallback((items: FAQItem[]): string => {
    return items
      .filter(item => item.question.trim() && item.answer.trim())
      .map(item => `<h2>${item.question}</h2><p>${item.answer}</p>`)
      .join('');
  }, []);

  // Parse Job content from HTML
  const parseJobContent = React.useCallback((htmlContent: string) => {
    if (!htmlContent) {
      setJobItems([]);
      return;
    }
    
    try {
      const parser = new DOMParser();
      const doc = parser.parseFromString(htmlContent, 'text/html');
      const elements = Array.from(doc.body.children);
      const items: JobItem[] = [];
      
      // Look for job listings in the format: <div data-job="true">...</div>
      for (let i = 0; i < elements.length; i++) {
        const element = elements[i];
        if (element.tagName.toLowerCase() === 'div' && element.getAttribute('data-job') === 'true') {
          const title = element.querySelector('[data-field="title"]')?.textContent?.trim() || '';
          const department = element.querySelector('[data-field="department"]')?.textContent?.trim() || '';
          const location = element.querySelector('[data-field="location"]')?.textContent?.trim() || '';
          const type = element.querySelector('[data-field="type"]')?.textContent?.trim() || 'Full-time';
          const description = element.querySelector('[data-field="description"]')?.innerHTML || '';
          const requirements = element.querySelector('[data-field="requirements"]')?.innerHTML || '';
          const isActive = element.getAttribute('data-active') !== 'false';
          
          if (title) {
            items.push({ title, department, location, type, description, requirements, isActive });
          }
        }
      }
      
      setJobItems(items.length > 0 ? items : [{ title: '', department: '', location: '', type: 'Full-time', description: '', requirements: '', isActive: true }]);
    } catch (error) {
      console.error('Error parsing job content:', error);
      setJobItems([{ title: '', department: '', location: '', type: 'Full-time', description: '', requirements: '', isActive: true }]);
    }
  }, []);

  // Convert Job items to HTML
  const convertJobsToHTML = React.useCallback((items: JobItem[]): string => {
    return items
      .filter(item => item.title.trim())
      .map(item => `
        <div data-job="true" data-active="${item.isActive}">
          <h2 data-field="title">${item.title}</h2>
          <p data-field="department"><strong>Department:</strong> ${item.department}</p>
          <p data-field="location"><strong>Location:</strong> ${item.location}</p>
          <p data-field="type"><strong>Type:</strong> ${item.type}</p>
          <div data-field="description">${item.description}</div>
          <div data-field="requirements"><strong>Requirements:</strong> ${item.requirements}</div>
        </div>
      `)
      .join('');
  }, []);

  // Build Size Guide HTML from structured state
  const buildSizeGuideHTML = React.useCallback(
    (
      rows: SizeGuideRow[],
      measures: MeasureGuideItem[],
      footnote: string,
      sHeading: string,
      sBody: string,
      sEmail: string
    ): string => {
      const tableRows = rows
        .filter(r => r.sizeLabel.trim())
        .map(
          (r, idx) => `
            <tr class="hover:bg-gray-50 transition-colors${idx % 2 === 1 ? ' bg-gray-50/50' : ''}">
              <td class="py-4 px-6 font-medium">${r.sizeLabel}</td>
              <td class="py-4 px-6">${r.length}</td>
              <td class="py-4 px-6">${r.chest}</td>
              <td class="py-4 px-6">${r.sleeve}</td>
              <td class="py-4 px-6 text-gray-500">${r.heightRange}</td>
            </tr>`
        )
        .join('');

      const measureList = measures
        .filter(m => m.label.trim() && m.description.trim())
        .map(
          m => `
            <li class="flex gap-3">
              <span class="font-bold text-black min-w-[60px]">${m.label}:</span>
              <span>${m.description}</span>
            </li>`
        )
        .join('');

      return `
        <div class="bg-white min-h-screen pb-20">
          <div class="bg-gray-50 border-b border-gray-100 py-12 mb-10">
            <div class="page-container text-center">
              <h1 class="text-4xl md:text-5xl font-heading font-bold text-gray-900 mb-2">Size Guide</h1>
              <p class="text-gray-500">Find your perfect fit with our comprehensive measurement chart.</p>
            </div>
          </div>
          <div class="page-container max-w-5xl">
            <div class="grid lg:grid-cols-3 gap-12">
              <div class="lg:col-span-2">
                <div class="bg-white border border-gray-100 rounded-2xl overflow-hidden shadow-sm mb-8">
                  <div class="bg-gray-50 border-b border-gray-100 p-4">
                    <h2 class="text-lg font-heading font-bold uppercase tracking-widest text-center text-gray-900">Abaya Size Chart</h2>
                  </div>
                  <div class="overflow-x-auto">
                    <table class="min-w-full text-sm">
                      <thead class="bg-gray-50 text-gray-900">
                        <tr>
                          <th class="py-4 px-6 text-left font-bold uppercase text-xs tracking-wider">Size</th>
                          <th class="py-4 px-6 text-left font-bold uppercase text-xs tracking-wider">Length (in)</th>
                          <th class="py-4 px-6 text-left font-bold uppercase text-xs tracking-wider">Chest (in)</th>
                          <th class="py-4 px-6 text-left font-bold uppercase text-xs tracking-wider">Sleeve (in)</th>
                          <th class="py-4 px-6 text-left font-bold uppercase text-xs tracking-wider">Height</th>
                        </tr>
                      </thead>
                      <tbody class="divide-y divide-gray-100">
                        ${tableRows}
                      </tbody>
                    </table>
                  </div>
                </div>
                <p class="text-xs text-gray-400 italic text-center">
                  ${footnote}
                </p>
              </div>
              <div class="space-y-8">
                <div class="bg-gray-50 p-6 rounded-xl border border-gray-100">
                  <h3 class="font-bold font-heading text-xl mb-4">How to Measure</h3>
                  <ul class="space-y-4 text-sm text-gray-600">
                    ${measureList}
                  </ul>
                </div>
                <div class="bg-gray-50 border border-gray-100 p-6 rounded-2xl text-center">
                  <h3 class="font-heading font-bold text-xl text-gray-900 mb-2">${sHeading}</h3>
                  <p class="text-gray-600 text-sm mb-4">
                    ${sBody}
                  </p>
                  <a href="mailto:${sEmail}" class="inline-block bg-black text-white px-6 py-2 rounded-lg text-xs font-heading font-bold hover:bg-gray-800 transition-colors">
                    Contact Support
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      `;
    },
    []
  );

  // Store Locations management functions
  const loadStoreLocations = React.useCallback(async () => {
    if (slug !== 'store-locator') return;
    setLoadingStores(true);
    try {
      const stores = await getAllStoreLocations(false); // Get all stores, not just active
      setStoreLocations(stores.map(store => ({
        id: store.id,
        name: store.name,
        address: store.address,
        city: store.city,
        state: store.state,
        country: store.country,
        zipCode: store.zipCode || '',
        phone: store.phone || '',
        email: store.email || '',
        latitude: store.latitude,
        longitude: store.longitude,
        description: store.description || '',
        isActive: store.isActive,
      })));
    } catch (error) {
      console.error('Error loading store locations:', error);
      alert('Failed to load store locations.');
    } finally {
      setLoadingStores(false);
    }
  }, [slug]);

  const loadPageData = React.useCallback(async () => {
    // Prevent multiple simultaneous calls
    if (isLoadingRef.current) {
      console.log('[PageEditor] loadPageData already in progress, skipping');
      return;
    }
    
    console.log('[PageEditor] loadPageData called', { slug });
    isLoadingRef.current = true;
    setLoading(true);
    try {
      const [pageData, allLanguages] = await Promise.all([
        getPageBySlug(slug),
        getAllLanguages(false)
      ]);
      
      console.log('[PageEditor] Data loaded', { 
        hasPageData: !!pageData, 
        languagesCount: allLanguages.length,
        translationsCount: pageData?.translations?.length || 0
      });
      
      setLanguages(allLanguages);
      setPage(pageData);
      
      if (pageData) {
        // Ensure translations array exists
        const translations = pageData.translations || [];
        
        // Set default language to current language or first available
        const defaultLang = translations.find(t => t.languageCode === currentLanguage?.code) 
          || translations.find(t => t.languageCode === 'en')
          || translations[0];
        
        if (defaultLang) {
          console.log('[PageEditor] Setting default language', { 
            languageCode: defaultLang.languageCode,
            hasContent: !!defaultLang.content,
            contentLength: defaultLang.content?.length || 0
          });
          setSelectedLanguageCode(defaultLang.languageCode);
          // Ensure content is properly set
          const content = defaultLang.content || '';
          setFormData({
            ...defaultLang,
            content
          });
          
          // Parse FAQ items if this is FAQ page
          if (slug === 'faq') {
            if (content) {
              parseFAQContent(content);
            } else {
              setFaqItems([{ question: '', answer: '' }]);
            }
          }
          
          // Parse Job items if this is careers page
          if (slug === 'careers') {
            if (content) {
              parseJobContent(content);
            } else {
              setJobItems([{ title: '', department: '', location: '', type: 'Full-time', description: '', requirements: '', isActive: true }]);
            }
          }
          
          // Load store locations if this is store-locator page
          if (slug === 'store-locator') {
            loadStoreLocations();
          }
        } else {
          // No translations exist, create default
          setSelectedLanguageCode(currentLanguage?.code || 'en');
          setFormData({
            languageCode: currentLanguage?.code || 'en',
            title: pageTitle,
            content: '',
            metaTitle: '',
            metaDescription: '',
            updatedAt: Timestamp.now(),
          });
          
          if (slug === 'faq') {
            setFaqItems([{ question: '', answer: '' }]);
          }
          
          if (slug === 'careers') {
            setJobItems([{ title: '', department: '', location: '', type: 'Full-time', description: '', requirements: '', isActive: true }]);
          }
          
          // Load store locations if this is store-locator page
          if (slug === 'store-locator') {
            loadStoreLocations();
          }
        }
      } else {
        // Page doesn't exist, initialize with default language
        const langCode = currentLanguage?.code || 'en';
        setSelectedLanguageCode(langCode);
        setFormData({
          languageCode: langCode,
          title: pageTitle,
          content: '',
          metaTitle: '',
          metaDescription: '',
          updatedAt: Timestamp.now(),
        });
        
        if (slug === 'faq') {
          setFaqItems([{ question: '', answer: '' }]);
        }
        
        // Load store locations if this is store-locator page
        if (slug === 'store-locator') {
          loadStoreLocations();
        }
      }
    } catch (error) {
      console.error('[PageEditor] Error loading page data:', error);
    } finally {
      console.log('[PageEditor] loadPageData completed, setting loading to false');
      isLoadingRef.current = false;
      setLoading(false);
    }
  }, [slug, pageTitle, currentLanguage, parseFAQContent, parseJobContent, loadStoreLocations]);

  useEffect(() => {
    console.log('[PageEditor] Setting isClient to true');
    setIsClient(true);
  }, []);

  useEffect(() => {
    console.log('[PageEditor] Slug changed, loading data', { slug });
    if (slug) {
      loadPageData();
      if (slug === 'store-locator') {
        loadStoreLocations();
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slug]); // Removed loadPageData from dependencies to prevent infinite loop

  // Get Quill instance after ReactQuill mounts
  useEffect(() => {
    if (loading || !isClient) {
      return;
    }
    
    // Wait for ReactQuill to fully render
      const findQuillInstance = () => {
      // Try to find Quill instance from DOM
        const editor = document.querySelector('.ql-editor') as HTMLElement & { __quill?: { root: { innerHTML: string } } } | null;
        if (editor && editor.__quill) {
          console.log('[PageEditor] Quill instance found via .ql-editor');
        quillRef.current = editor.__quill;
          setQuillInstance(editor.__quill);
          return true;
        }
        
        const container = document.querySelector('.ql-container') as HTMLElement & { __quill?: { root: { innerHTML: string } } } | null;
        if (container && container.__quill) {
          console.log('[PageEditor] Quill instance found via .ql-container');
        quillRef.current = container.__quill;
          setQuillInstance(container.__quill);
          return true;
        }
        
        return false;
      };

      // Try immediately
      if (!findQuillInstance()) {
      // If not found, try after a short delay (ReactQuill needs time to mount)
      const timer = setTimeout(() => {
          if (!findQuillInstance()) {
          // One more try after longer delay
          setTimeout(() => {
              findQuillInstance();
          }, 300);
          }
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [selectedLanguageCode, loading, isClient]);


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      let latestContent = formData.content;
      
      // If FAQ page, convert FAQ items to HTML
      if (slug === 'faq') {
        latestContent = convertFAQToHTML(faqItems);
      } else if (slug === 'careers') {
        // If Careers page, convert Job items to HTML
        latestContent = convertJobsToHTML(jobItems);
      } else if (slug === 'size-guide') {
        // Size Guide page: build structured HTML from size/measure state
        latestContent = buildSizeGuideHTML(
          sizeRows,
          measureItems,
          sizeFootnote,
          supportHeading,
          supportBody,
          supportEmail
        );
      } else if (slug === 'store-locator') {
        // Store locator page - content is just a description, stores are managed separately
        // Get latest content directly from Quill editor if it exists
        const editor = document.querySelector('.ql-editor') as HTMLElement & { __quill?: { root: { innerHTML: string } } } | null;
        if (editor && editor.__quill) {
          latestContent = editor.__quill.root.innerHTML;
        }
      } else {
        // Get latest content directly from Quill editor before saving
        const editor = document.querySelector('.ql-editor') as HTMLElement & { __quill?: { root: { innerHTML: string } } } | null;
        if (editor && editor.__quill) {
          latestContent = editor.__quill.root.innerHTML;
        }
      }

      // Prepare data with latest content
      const dataToSave: Omit<PageContentTranslation, 'updatedAt'> = {
        ...formData,
        content: latestContent
      };

      await updatePageTranslation(slug, selectedLanguageCode, dataToSave);
      
      // Update local state with saved content
      setFormData(prev => ({ ...prev, content: latestContent }));
      
      // Reload page data to get updated translations
      await loadPageData();
      
      alert('Page translation updated successfully! The changes will be visible on the frontend.');
    } catch (error) {
      console.error('Error saving page:', error);
      alert('Failed to update page. Please check console for details.');
    } finally {
      setSaving(false);
    }
  };

  const handleChange = <TField extends keyof PageContentTranslation>(field: TField, value: PageContentTranslation[TField]) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Image upload handler for ReactQuill
  // Using useRef to store slug to avoid dependency issues
  const slugRef = React.useRef(slug);
  React.useEffect(() => {
    slugRef.current = slug;
  }, [slug]);

  const imageHandler = React.useCallback(() => {
    const input = document.createElement('input');
    input.setAttribute('type', 'file');
    input.setAttribute('accept', 'image/*');
    input.click();

    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;

      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        alert('Image size must be less than 5MB. Please compress the image and try again.');
        return;
      }

      // Show loading state
      const loadingMsg = document.createElement('div');
      loadingMsg.id = 'image-upload-loading';
      loadingMsg.textContent = 'Uploading image...';
      loadingMsg.style.cssText = 'position: fixed; top: 20px; right: 20px; background: #000; color: #fff; padding: 12px 20px; border-radius: 4px; z-index: 10000;';
      document.body.appendChild(loadingMsg);

      try {
        // Sanitize filename
        const sanitizedFileName = file.name.replace(/[^a-zA-Z0-9.-]/g, '_');
        const filePath = `pages/${slugRef.current}/${Date.now()}_${sanitizedFileName}`;
        
        // Upload to Firebase Storage
        const storageRef = ref(storage, filePath);
        const uploadResult = await uploadBytes(storageRef, file);
        
        // Get download URL using the upload result ref
        const url = await getDownloadURL(uploadResult.ref);

        // Get Quill instance - use ref first, then fallback to DOM
        let quill = quillRef.current;
        
        if (!quill) {
          const editor = document.querySelector('.ql-editor') as HTMLElement & { __quill?: { root: { innerHTML: string } } } | null;
          if (editor && editor.__quill) {
            quill = editor.__quill;
            // Update ref for next time
            quillRef.current = quill;
          }
        }
        
        if (!quill) {
          // Wait a bit and try again
          await new Promise(resolve => setTimeout(resolve, 300));
          quill = quillRef.current;
          if (!quill) {
          const editor = document.querySelector('.ql-editor') as HTMLElement & { __quill?: { root: { innerHTML: string } } } | null;
          if (editor && editor.__quill) {
            quill = editor.__quill;
              quillRef.current = quill;
            }
          }
        }
        
        if (!quill) {
          throw new Error('Quill editor not found. Please make sure the editor is loaded and try again.');
        }

        // Insert image into editor
        const quillInstance = quill as unknown as { getSelection: (focus?: boolean) => { index: number; length: number } | null; insertEmbed: (index: number, type: string, value: string) => void; setSelection: (index: number, length?: number) => void; getLength: () => number };
        const range = quillInstance.getSelection(true);
        if (range && range.index !== null) {
          quillInstance.insertEmbed(range.index, 'image', url);
          quillInstance.setSelection(range.index + 1);
        } else {
          // If no selection, insert at the end
          const length = quillInstance.getLength();
          quillInstance.insertEmbed(length - 1, 'image', url);
          quillInstance.setSelection(length, 0);
        }

        // Don't update formData immediately - let ReactQuill's onChange handle it
        // This prevents the editor from disappearing
        // The onChange handler will update formData when user types or makes changes

        // Remove loading message
        const loadingElement = document.getElementById('image-upload-loading');
        if (loadingElement) {
          loadingElement.textContent = 'Image uploaded successfully!';
          loadingElement.style.background = '#10b981';
          setTimeout(() => {
            if (loadingElement.parentNode) {
              loadingElement.parentNode.removeChild(loadingElement);
            }
          }, 2000);
        }
      } catch (error: unknown) {
        console.error('Error uploading image:', error);
        
        // Remove loading message
        const loadingElement = document.getElementById('image-upload-loading');
        if (loadingElement) {
          loadingElement.parentNode?.removeChild(loadingElement);
        }

        // Show detailed error message
        let errorMessage = 'Failed to upload image. ';
        const errorObj = error as { code?: string; message?: string };
        if (errorObj.code === 'storage/unauthorized') {
          errorMessage += 'You are not authorized to upload images. Please make sure you are logged in as an admin.';
        } else if (errorObj.code === 'storage/canceled') {
          errorMessage += 'Upload was canceled.';
        } else if (errorObj.code === 'storage/unknown') {
          errorMessage += 'An unknown error occurred. Please check your internet connection and try again.';
        } else if (errorObj.message) {
          errorMessage += errorObj.message;
        } else {
          errorMessage += 'Please try again.';
        }
        
        alert(errorMessage);
      }
    };
  }, []); // Empty dependencies - using refs instead

  // Memoize the modules and formats to prevent re-renders
  // imageHandler is stable (empty deps), so modules won't recreate unnecessarily
  const quillModules = React.useMemo(() => ({
    toolbar: {
      container: [
        [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
        [{ 'font': [] }],
        [{ 'size': ['small', false, 'large', 'huge'] }],
        ['bold', 'italic', 'underline', 'strike', 'blockquote'],
        [{ 'list': 'ordered'}, { 'list': 'bullet' }, { 'indent': '-1'}, { 'indent': '+1' }],
        [{ 'script': 'sub'}, { 'script': 'super' }],
        [{ 'align': [] }],
        ['link', 'image', 'video'],
        [{ 'color': [] }, { 'background': [] }],
        ['clean']
      ],
      handlers: {
        image: imageHandler
      }
    },
  }), [imageHandler]);
  
  const quillFormats = React.useMemo(() => [
    'header', 'font', 'size',
    'bold', 'italic', 'underline', 'strike', 'blockquote',
    'list', 'bullet', 'indent',
    'script',
    'align',
    'link', 'image', 'video',
    'color', 'background',
    'clean'
  ], []);

  const handleLanguageChange = (languageCode: string) => {
    setSelectedLanguageCode(languageCode);
    
    // Load translation for selected language
    if (page) {
      const translations = page.translations || [];
      const translation = translations.find(t => t.languageCode === languageCode);
      if (translation) {
        setFormData({
          ...translation,
          content: translation.content || ''
        });
        
        // Parse FAQ items if this is FAQ page
        if (slug === 'faq' && translation.content) {
          parseFAQContent(translation.content);
        } else if (slug === 'faq') {
          setFaqItems([{ question: '', answer: '' }]);
        }
      } else {
        // Create new translation for this language
        setFormData({
          languageCode,
          title: pageTitle,
          content: '',
          metaTitle: '',
          metaDescription: '',
          updatedAt: Timestamp.now(),
        });
        
        if (slug === 'faq') {
          setFaqItems([{ question: '', answer: '' }]);
        }
      }
    }
  };

  // FAQ management functions
  const addFAQItem = () => {
    setFaqItems([...faqItems, { question: '', answer: '' }]);
  };

  const removeFAQItem = (index: number) => {
    setFaqItems(faqItems.filter((_, i) => i !== index));
  };

  const updateFAQItem = (index: number, field: 'question' | 'answer', value: string) => {
    const updated = [...faqItems];
    updated[index] = { ...updated[index], [field]: value };
    setFaqItems(updated);
  };

  // Job management functions
  const addJobItem = () => {
    setJobItems([...jobItems, { title: '', department: '', location: '', type: 'Full-time', description: '', requirements: '', isActive: true }]);
  };

  const removeJobItem = (index: number) => {
    setJobItems(jobItems.filter((_, i) => i !== index));
  };

  const updateJobItem = (index: number, field: keyof JobItem, value: string | boolean) => {
    const updated = [...jobItems];
    updated[index] = { ...updated[index], [field]: value };
    setJobItems(updated);
  };

  const addStoreLocation = () => {
    setStoreLocations([...storeLocations, {
      name: '',
      address: '',
      city: '',
      state: '',
      country: '',
      zipCode: '',
      phone: '',
      email: '',
      latitude: 0,
      longitude: 0,
      description: '',
      isActive: true,
    }]);
  };

  const removeStoreLocation = async (index: number) => {
    const store = storeLocations[index];
    if (store.id) {
      if (!confirm('Are you sure you want to delete this store location?')) return;
      try {
        await deleteStoreLocation(store.id);
        setStoreLocations(storeLocations.filter((_, i) => i !== index));
      } catch (error) {
        console.error('Error deleting store location:', error);
        alert('Failed to delete store location.');
      }
    } else {
      setStoreLocations(storeLocations.filter((_, i) => i !== index));
    }
  };

  const updateStoreLocationItem = (index: number, field: keyof StoreLocationItem, value: string | number | boolean) => {
    const updated = [...storeLocations];
    updated[index] = { ...updated[index], [field]: value };
    setStoreLocations(updated);
  };

  const saveStoreLocation = async (index: number) => {
    const store = storeLocations[index];
    if (!store.name || !store.address || !store.city || !store.state) {
      alert('Please fill in all required fields (Name, Address, City, State).');
      return;
    }
    if (store.latitude === 0 && store.longitude === 0) {
      alert('Please set the location coordinates (Latitude and Longitude).');
      return;
    }

    try {
      // Build store data object, filtering out undefined values
      const storeData: Record<string, unknown> = {
        name: store.name,
        address: store.address,
        city: store.city,
        state: store.state,
        country: store.country,
        latitude: store.latitude,
        longitude: store.longitude,
        isActive: store.isActive,
      };

      // Only include optional fields if they have values
      if (store.zipCode) storeData.zipCode = store.zipCode;
      if (store.phone) storeData.phone = store.phone;
      if (store.email) storeData.email = store.email;
      if (store.description) storeData.description = store.description;
      // openingHours is optional, don't include if not set

      if (store.id) {
        await updateStoreLocation(store.id, storeData);
        alert('Store location updated successfully!');
        // Reload stores to get updated data
        loadStoreLocations();
      } else {
        const newId = await createStoreLocation(storeData as Omit<StoreLocation, 'id' | 'createdAt' | 'updatedAt'>);
        const updated = [...storeLocations];
        updated[index] = { ...store, id: newId };
        setStoreLocations(updated);
        alert('Store location created successfully!');
      }
    } catch (error: unknown) {
      console.error('Error saving store location:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      alert(`Failed to save store location: ${errorMessage}`);
    }
  };

  if (!PAGE_SLUGS[slug as keyof typeof PAGE_SLUGS]) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
          Page not found or invalid slug.
        </div>
      </div>
    );
  }

  // Reduced logging for production
  if (process.env.NODE_ENV === 'development') {
  console.log('[PageEditor] Render', { 
    loading, 
    isClient, 
    contentLength: formData?.content?.length || 0,
    selectedLanguageCode,
  });
  }

  if (loading) {
    console.log('[PageEditor] Showing loading state');
    return (
      <div className="p-6 flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{pageTitle}</h1>
          <p className="text-sm text-gray-500 mt-1">Manage multi-language content and SEO for {pageTitle}</p>
        </div>
        <div className="flex items-center gap-3">
          <a 
            href={`/${slug}`} 
            target="_blank" 
            rel="noopener noreferrer"
            className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            View Live
          </a>
          <button
            onClick={handleSubmit}
            disabled={saving}
            className={`px-6 py-2 bg-black text-white rounded-lg text-sm font-bold hover:bg-gray-800 transition-all shadow-sm flex items-center gap-2 ${saving ? 'opacity-70 cursor-not-allowed' : ''}`}
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>

      {/* Language Selector */}
      <div className="mb-6 bg-white p-4 rounded-xl shadow-sm border border-gray-200">
        <label className="block text-sm font-bold text-gray-700 mb-2">Select Language</label>
        <div className="flex flex-wrap gap-2">
          {languages.map((lang) => {
            const hasTranslation = page?.translations.some(t => t.languageCode === lang.code);
            const isSelected = selectedLanguageCode === lang.code;
            return (
              <button
                key={lang.code}
                type="button"
                onClick={() => handleLanguageChange(lang.code)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  isSelected
                    ? 'bg-black text-white'
                    : hasTranslation
                    ? 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    : 'bg-gray-50 text-gray-500 hover:bg-gray-100 border border-gray-200'
                }`}
              >
                {lang.name} {lang.nativeName && `(${lang.nativeName})`}
                {!hasTranslation && <span className="ml-2 text-xs">New</span>}
              </button>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content Editor, FAQ Form, or Careers Form */}
        <div className="lg:col-span-2 space-y-6">
          {slug === 'faq' ? (
            // FAQ Form Interface
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
              <div className="flex justify-between items-center mb-4">
                <label className="block text-sm font-bold text-gray-700">FAQ Questions & Answers</label>
                <button
                  type="button"
                  onClick={addFAQItem}
                  className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors"
                >
                  + Add FAQ
                </button>
              </div>
              
              <div className="space-y-4">
                {faqItems.map((item, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-xs font-semibold text-gray-500 uppercase">FAQ #{index + 1}</span>
                      {faqItems.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeFAQItem(index)}
                          className="text-red-600 hover:text-red-700 text-sm font-medium"
                        >
                          Remove
                        </button>
                      )}
                    </div>
                    
                    <div className="space-y-3">
                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-1">Question *</label>
                        <input
                          type="text"
                          value={item.question}
                          onChange={(e) => updateFAQItem(index, 'question', e.target.value)}
                          placeholder="Enter your question..."
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-1">Answer *</label>
                        <textarea
                          value={item.answer}
                          onChange={(e) => updateFAQItem(index, 'answer', e.target.value)}
                          placeholder="Enter your answer..."
                          rows={4}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none resize-none"
                        />
                      </div>
                    </div>
                  </div>
                ))}
                
                {faqItems.length === 0 && (
                  <div className="text-center py-8 border border-gray-200 rounded-lg bg-gray-50">
                    <p className="text-gray-500 mb-4">No FAQ items yet. Click &quot;Add FAQ&quot; to get started.</p>
                    <button
                      type="button"
                      onClick={addFAQItem}
                      className="px-6 py-2 bg-black text-white rounded-lg text-sm font-medium hover:bg-gray-800 transition-colors"
                    >
                      Add First FAQ
                    </button>
                  </div>
                )}
              </div>
            </div>
          ) : slug === 'careers' ? (
            // Careers Form Interface
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
              <div className="flex justify-between items-center mb-4">
                <label className="block text-sm font-bold text-gray-700">Job Listings</label>
                <button
                  type="button"
                  onClick={addJobItem}
                  className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors"
                >
                  + Add Job
                </button>
              </div>
              
              <div className="space-y-4">
                {jobItems.map((item, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-xs font-semibold text-gray-500 uppercase">Job #{index + 1}</span>
                      <div className="flex items-center gap-3">
                        <label className="flex items-center gap-2 text-sm">
                          <input
                            type="checkbox"
                            checked={item.isActive}
                            onChange={(e) => updateJobItem(index, 'isActive', e.target.checked)}
                            className="w-4 h-4 text-black border-gray-300 rounded focus:ring-black"
                          />
                          <span className="text-gray-700">Active</span>
                        </label>
                        {jobItems.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeJobItem(index)}
                            className="text-red-600 hover:text-red-700 text-sm font-medium"
                          >
                            Remove
                          </button>
                        )}
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-1">Job Title *</label>
                        <input
                          type="text"
                          value={item.title}
                          onChange={(e) => updateJobItem(index, 'title', e.target.value)}
                          placeholder="e.g., Senior Frontend Developer"
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                        />
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-1">Department *</label>
                          <input
                            type="text"
                            value={item.department}
                            onChange={(e) => updateJobItem(index, 'department', e.target.value)}
                            placeholder="e.g., Engineering, Marketing"
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-1">Location *</label>
                          <input
                            type="text"
                            value={item.location}
                            onChange={(e) => updateJobItem(index, 'location', e.target.value)}
                            placeholder="e.g., Lahore, Remote"
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                          />
                        </div>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-1">Job Type *</label>
                        <select
                          value={item.type}
                          onChange={(e) => updateJobItem(index, 'type', e.target.value)}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                        >
                          <option value="Full-time">Full-time</option>
                          <option value="Part-time">Part-time</option>
                          <option value="Contract">Contract</option>
                          <option value="Internship">Internship</option>
                          <option value="Freelance">Freelance</option>
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-1">Job Description *</label>
                        <textarea
                          value={item.description}
                          onChange={(e) => updateJobItem(index, 'description', e.target.value)}
                          placeholder="Describe the role, responsibilities, and what you're looking for..."
                          rows={5}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none resize-none"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-1">Requirements *</label>
                        <textarea
                          value={item.requirements}
                          onChange={(e) => updateJobItem(index, 'requirements', e.target.value)}
                          placeholder="List the required skills, experience, and qualifications..."
                          rows={4}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none resize-none"
                        />
                      </div>
                    </div>
                  </div>
                ))}
                
                {jobItems.length === 0 && (
                  <div className="text-center py-8 border border-gray-200 rounded-lg bg-gray-50">
                    <p className="text-gray-500 mb-4">No job listings yet. Click &quot;Add Job&quot; to get started.</p>
                    <button
                      type="button"
                      onClick={addJobItem}
                      className="px-6 py-2 bg-black text-white rounded-lg text-sm font-medium hover:bg-gray-800 transition-colors"
                    >
                      Add First Job
                    </button>
                  </div>
                )}
              </div>
            </div>
          ) : slug === 'store-locator' ? (
            // Store Locations Form Interface
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
              <div className="flex justify-between items-center mb-4">
                <label className="block text-sm font-bold text-gray-700">Store Locations</label>
                <button
                  type="button"
                  onClick={addStoreLocation}
                  className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors"
                >
                  + Add Store
                </button>
              </div>
              
              {loadingStores ? (
                <div className="text-center py-8">
                  <div className="text-gray-500">Loading store locations...</div>
                </div>
              ) : (
                <div className="space-y-4">
                  {storeLocations.map((store, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                      <div className="flex justify-between items-center mb-3">
                        <span className="text-xs font-semibold text-gray-500 uppercase">
                          Store #{index + 1} {store.id && <span className="text-green-600">(Saved)</span>}
                        </span>
                        <div className="flex items-center gap-3">
                          <label className="flex items-center gap-2 text-sm">
                            <input
                              type="checkbox"
                              checked={store.isActive}
                              onChange={(e) => updateStoreLocationItem(index, 'isActive', e.target.checked)}
                              className="w-4 h-4 text-black border-gray-300 rounded focus:ring-black"
                            />
                            <span className="text-gray-700">Active</span>
                          </label>
                          <button
                            type="button"
                            onClick={() => saveStoreLocation(index)}
                            className="px-4 py-1.5 bg-black text-white rounded-lg text-sm font-medium hover:bg-gray-800 transition-colors"
                          >
                            {store.id ? 'Update' : 'Save'}
                          </button>
                          <button
                            type="button"
                            onClick={() => removeStoreLocation(index)}
                            className="text-red-600 hover:text-red-700 text-sm font-medium"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-1">Store Name *</label>
                          <input
                            type="text"
                            value={store.name}
                            onChange={(e) => updateStoreLocationItem(index, 'name', e.target.value)}
                            placeholder="e.g., Main Store, Branch 1"
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-1">Address *</label>
                          <input
                            type="text"
                            value={store.address}
                            onChange={(e) => updateStoreLocationItem(index, 'address', e.target.value)}
                            placeholder="Street address"
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                          />
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-1">City *</label>
                            <input
                              type="text"
                              value={store.city}
                              onChange={(e) => updateStoreLocationItem(index, 'city', e.target.value)}
                              placeholder="City"
                              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                            />
                          </div>
                          
                          <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-1">State/Province *</label>
                            <input
                              type="text"
                              value={store.state}
                              onChange={(e) => updateStoreLocationItem(index, 'state', e.target.value)}
                              placeholder="State"
                              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                            />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-1">Country *</label>
                            <input
                              type="text"
                              value={store.country}
                              onChange={(e) => updateStoreLocationItem(index, 'country', e.target.value)}
                              placeholder="Country"
                              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                            />
                          </div>
                          
                          <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-1">Zip Code</label>
                            <input
                              type="text"
                              value={store.zipCode}
                              onChange={(e) => updateStoreLocationItem(index, 'zipCode', e.target.value)}
                              placeholder="Zip Code"
                              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                            />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-1">Phone</label>
                            <input
                              type="text"
                              value={store.phone}
                              onChange={(e) => updateStoreLocationItem(index, 'phone', e.target.value)}
                              placeholder="Phone number"
                              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                            />
                          </div>
                          
                          <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-1">Email</label>
                            <input
                              type="email"
                              value={store.email}
                              onChange={(e) => updateStoreLocationItem(index, 'email', e.target.value)}
                              placeholder="Email address"
                              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                            />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-1">Latitude *</label>
                            <input
                              type="number"
                              step="any"
                              value={store.latitude}
                              onChange={(e) => updateStoreLocationItem(index, 'latitude', parseFloat(e.target.value) || 0)}
                              placeholder="e.g., 31.5204"
                              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                            />
                          </div>
                          
                          <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-1">Longitude *</label>
                            <input
                              type="number"
                              step="any"
                              value={store.longitude}
                              onChange={(e) => updateStoreLocationItem(index, 'longitude', parseFloat(e.target.value) || 0)}
                              placeholder="e.g., 74.3587"
                              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                            />
                          </div>
                        </div>
                        
                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-1">Description</label>
                          <textarea
                            value={store.description}
                            onChange={(e) => updateStoreLocationItem(index, 'description', e.target.value)}
                            placeholder="Store description, special features, etc."
                            rows={3}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none resize-none"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  {storeLocations.length === 0 && (
                    <div className="text-center py-8 border border-gray-200 rounded-lg bg-gray-50">
                      <p className="text-gray-500 mb-4">No store locations yet. Click &quot;Add Store&quot; to get started.</p>
                      <button
                        type="button"
                        onClick={addStoreLocation}
                        className="px-6 py-2 bg-black text-white rounded-lg text-sm font-medium hover:bg-gray-800 transition-colors"
                      >
                        Add First Store
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : slug === 'size-guide' ? (
            // Size Guide structured editor
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 space-y-6">
              <div>
                <h2 className="text-lg font-bold text-gray-900 mb-2">Abaya Size Chart</h2>
                <p className="text-sm text-gray-500">
                  Manage size rows for your abaya size chart. These map to the table on the Size Guide page.
                </p>
              </div>
              <div className="space-y-4">
                {sizeRows.map((row, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-xs font-semibold text-gray-500 uppercase">
                        Row #{index + 1}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setSizeRows(prev => prev.filter((_, i) => i !== index));
                        }}
                        className="text-red-600 hover:text-red-700 text-xs font-medium"
                        disabled={sizeRows.length <= 1}
                      >
                        Remove
                      </button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-gray-700 mb-1">Size</label>
                        <input
                          type="text"
                          value={row.sizeLabel}
                          onChange={(e) => {
                            const updated = [...sizeRows];
                            updated[index] = { ...updated[index], sizeLabel: e.target.value };
                            setSizeRows(updated);
                          }}
                          placeholder="50 (XS)"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-gray-700 mb-1">Length (in)</label>
                        <input
                          type="text"
                          value={row.length}
                          onChange={(e) => {
                            const updated = [...sizeRows];
                            updated[index] = { ...updated[index], length: e.target.value };
                            setSizeRows(updated);
                          }}
                          placeholder='50"'
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-gray-700 mb-1">Chest (in)</label>
                        <input
                          type="text"
                          value={row.chest}
                          onChange={(e) => {
                            const updated = [...sizeRows];
                            updated[index] = { ...updated[index], chest: e.target.value };
                            setSizeRows(updated);
                          }}
                          placeholder='20"'
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-gray-700 mb-1">Sleeve (in)</label>
                        <input
                          type="text"
                          value={row.sleeve}
                          onChange={(e) => {
                            const updated = [...sizeRows];
                            updated[index] = { ...updated[index], sleeve: e.target.value };
                            setSizeRows(updated);
                          }}
                          placeholder='26"'
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-gray-700 mb-1">Height Range</label>
                        <input
                          type="text"
                          value={row.heightRange}
                          onChange={(e) => {
                            const updated = [...sizeRows];
                            updated[index] = { ...updated[index], heightRange: e.target.value };
                            setSizeRows(updated);
                          }}
                          placeholder={`4'10" - 5'0"`}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                        />
                      </div>
                    </div>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() =>
                    setSizeRows(prev => [
                      ...prev,
                      { sizeLabel: '', length: '', chest: '', sleeve: '', heightRange: '' },
                    ])
                  }
                  className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors"
                >
                  + Add Size Row
                </button>
              </div>

              <div className="border-t border-gray-200 pt-6 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Size Chart Footnote
                  </label>
                  <input
                    type="text"
                    value={sizeFootnote}
                    onChange={(e) => setSizeFootnote(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-semibold text-gray-800">How to Measure</h3>
                  </div>
                  <div className="space-y-3">
                    {measureItems.map((item, index) => (
                      <div key={index} className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <input
                          type="text"
                          value={item.label}
                          onChange={(e) => {
                            const updated = [...measureItems];
                            updated[index] = { ...updated[index], label: e.target.value };
                            setMeasureItems(updated);
                          }}
                          placeholder="Length"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                        />
                        <textarea
                          value={item.description}
                          onChange={(e) => {
                            const updated = [...measureItems];
                            updated[index] = { ...updated[index], description: e.target.value };
                            setMeasureItems(updated);
                          }}
                          placeholder="Description..."
                          rows={2}
                          className="md:col-span-2 w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-black focus:border-transparent outline-none resize-none"
                        />
                      </div>
                    ))}
                  </div>
                </div>

                <div className="border-t border-gray-200 pt-4 space-y-3">
                  <h3 className="text-sm font-semibold text-gray-800">Support Block</h3>
                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">
                        Heading
                      </label>
                      <input
                        type="text"
                        value={supportHeading}
                        onChange={(e) => setSupportHeading(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">
                        Body
                      </label>
                      <textarea
                        value={supportBody}
                        onChange={(e) => setSupportBody(e.target.value)}
                        rows={3}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-black focus:border-transparent outline-none resize-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">
                        Support Email
                      </label>
                      <input
                        type="email"
                        value={supportEmail}
                        onChange={(e) => setSupportEmail(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            // Regular Editor for other pages
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
              <label className="block text-sm font-bold text-gray-700 mb-3">Page Content</label>
              <div className="relative" id="editor-container">
                {(() => {
                  if (!isClient) {
                    return (
                      <div className="w-full h-[400px] border border-gray-300 rounded-lg flex items-center justify-center bg-gray-50">
                        <div className="text-gray-500">Initializing editor... (isClient: false)</div>
                      </div>
                    );
                  }

                  if (loading) {
                    return (
                      <div className="w-full h-[400px] border border-gray-300 rounded-lg flex items-center justify-center bg-gray-50">
                        <div className="text-gray-500">Loading page data...</div>
                      </div>
                    );
                  }

                  return (
                    <ReactQuill
                      key={`editor-${selectedLanguageCode}`}
                      theme="snow"
                      value={formData.content || ''}
                      onChange={(value: string) => {
                        // Update formData when content changes
                        // This will be called automatically when image is inserted
                        handleChange('content', value);
                      }}
                      placeholder="Start writing your content here..."
                      modules={quillModules}
                      formats={quillFormats}
                      style={{ minHeight: '400px' }}
                      className="bg-white"
                      preserveWhitespace={true}
                    />
                  );
                })()}
                <p className="text-xs text-gray-500 mt-2">
                  Use the toolbar above to format your content. You can add images, links, videos, and more.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Sidebar Settings */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <h3 className="text-lg font-bold text-gray-900 mb-4">General Settings</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Page Title ({selectedLanguageCode.toUpperCase()})</label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => handleChange('title', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                />
              </div>

              {page && (
                <div>
                  <label className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50">
                    <input
                      type="checkbox"
                      checked={page.isActive}
                      onChange={async (e) => {
                        const updatedPage = { ...page, isActive: e.target.checked };
                        setPage(updatedPage);
                        // Save page active status
                        try {
                          const { createOrUpdatePage } = await import('@/lib/firestore/pages_db');
                          await createOrUpdatePage(updatedPage);
                        } catch (error) {
                          console.error('Error updating page status:', error);
                        }
                      }}
                      className="w-5 h-5 text-black border-gray-300 rounded focus:ring-black"
                    />
                    <span className="text-sm font-medium text-gray-700">Page Active</span>
                  </label>
                </div>
              )}
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <h3 className="text-lg font-bold text-gray-900 mb-4">SEO Configuration ({selectedLanguageCode.toUpperCase()})</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Meta Title</label>
                <input
                  type="text"
                  value={formData.metaTitle || ''}
                  onChange={(e) => handleChange('metaTitle', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                  placeholder={formData.title}
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Meta Description</label>
                <textarea
                  value={formData.metaDescription || ''}
                  onChange={(e) => handleChange('metaDescription', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none h-24 resize-none"
                  placeholder="Brief description for search engines..."
                ></textarea>
              </div>
            </div>
          </div>

          {/* Translation Status */}
          {page && page.translations && page.translations.length > 0 && (
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Available Translations</h3>
              <div className="space-y-2">
                {page.translations.map((translation) => {
                  const lang = languages.find(l => l.code === translation.languageCode);
                  return (
                    <div key={translation.languageCode} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                      <span className="text-sm font-medium text-gray-700">
                        {lang?.name || translation.languageCode} {lang?.nativeName && `(${lang.nativeName})`}
                      </span>
                      <span className="text-xs text-gray-500">
                        {translation.updatedAt?.toDate?.() ? new Date(translation.updatedAt.toDate()).toLocaleDateString() : 'N/A'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PageEditor;
