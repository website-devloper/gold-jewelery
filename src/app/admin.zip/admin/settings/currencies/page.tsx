'use client';

import React, { useState, useEffect } from 'react';
import { getAllCurrencies, createCurrency, updateCurrency, deleteCurrency } from '@/lib/firestore/internationalization_db';
import { Currency } from '@/lib/firestore/internationalization';

const CurrenciesPage = () => {
  const [currencies, setCurrencies] = useState<Currency[]>([]);
  const [defaultCurrency, setDefaultCurrency] = useState<Currency | null>(null);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingCurrency, setEditingCurrency] = useState<Currency | null>(null);
  const [formData, setFormData] = useState({
    code: '',
    name: '',
    symbol: '',
    symbolPosition: 'left' as 'left' | 'right',
    decimalPlaces: 2,
    isActive: true,
    isDefault: false,
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const currenciesData = await getAllCurrencies();
      setCurrencies(currenciesData);
      const defaultCurrencyData = currenciesData.find(c => c.isDefault) || null;
      setDefaultCurrency(defaultCurrencyData);
    } catch (error) {
      console.error('Failed to fetch currencies:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // If setting as default currency, unset other default currencies
      if (formData.isDefault) {
        const otherDefaultCurrencies = currencies.filter(c => c.isDefault && c.id !== editingCurrency?.id);
        for (const currency of otherDefaultCurrencies) {
          await updateCurrency(currency.id!, { isDefault: false });
        }
      }

      if (editingCurrency) {
        await updateCurrency(editingCurrency.id!, formData);
      } else {
        await createCurrency(formData);
      }
      setShowForm(false);
      setEditingCurrency(null);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Failed to save currency:', error);
      alert('Failed to save currency');
    }
  };

  const handleEdit = (currency: Currency) => {
    setEditingCurrency(currency);
    setFormData({
      code: currency.code,
      name: currency.name,
      symbol: currency.symbol,
      symbolPosition: currency.symbolPosition,
      decimalPlaces: currency.decimalPlaces,
      isActive: currency.isActive,
      isDefault: currency.isDefault || false,
    });
    setShowForm(true);
  };

  const handleDelete = async (currency: Currency) => {
    if (!currency.id) {
      alert('Currency ID is missing');
      return;
    }
    
    if (currency.isDefault) {
      alert('Cannot delete default currency. Please set another currency as default first.');
      return;
    }
    
    if (!confirm(`Are you sure you want to delete ${currency.code} (${currency.name})?`)) return;
    
    try {
      await deleteCurrency(currency.id);
      alert('Currency deleted successfully');
      fetchData();
    } catch (error) {
      console.error('Failed to delete currency:', error);
      alert(`Failed to delete currency: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  };

  const resetForm = () => {
    setFormData({
      code: '',
      name: '',
      symbol: '',
      symbolPosition: 'left',
      decimalPlaces: 2,
      isActive: true,
      isDefault: false,
    });
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Currencies</h1>
          <p className="text-gray-500 mt-1">Manage currencies for your store</p>
          {defaultCurrency && (
            <p className="text-sm text-gray-600 mt-1">Default Currency: <strong>{defaultCurrency.code} ({defaultCurrency.symbol})</strong></p>
          )}
        </div>
        <button
          onClick={() => {
            resetForm();
            setEditingCurrency(null);
            setShowForm(true);
          }}
          className="bg-black text-white px-6 py-2 rounded-full text-sm font-bold uppercase tracking-widest hover:bg-gray-800 transition-colors"
        >
          + New Currency
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-bold mb-4">{editingCurrency ? 'Edit' : 'Create'} Currency</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Currency Code</label>
                <input
                  type="text"
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  placeholder="e.g., PKR, USD, EUR"
                  required
                  maxLength={3}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Currency Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  placeholder="e.g., Pakistani Rupee"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Symbol</label>
                <input
                  type="text"
                  value={formData.symbol}
                  onChange={(e) => setFormData({ ...formData, symbol: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  placeholder="e.g., Rs, $, €"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Symbol Position</label>
                <select
                  value={formData.symbolPosition}
                  onChange={(e) => setFormData({ ...formData, symbolPosition: e.target.value as 'left' | 'right' })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                >
                  <option value="left">Left</option>
                  <option value="right">Right</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Decimal Places</label>
                <input
                  type="number"
                  value={formData.decimalPlaces}
                  onChange={(e) => setFormData({ ...formData, decimalPlaces: parseInt(e.target.value) || 0 })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  min="0"
                  max="4"
                  required
                />
              </div>
            </div>
            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.isDefault}
                  onChange={(e) => setFormData({ ...formData, isDefault: e.target.checked })}
                  className="w-4 h-4 text-black border-gray-300 rounded focus:ring-black"
                />
                <span className="text-sm font-medium text-gray-700">Set as Default Currency</span>
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.isActive}
                  onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                  className="w-4 h-4 text-black border-gray-300 rounded focus:ring-black"
                />
                <span className="text-sm font-medium text-gray-700">Active</span>
              </label>
            </div>
            <div className="flex gap-3">
              <button
                type="submit"
                className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 transition-colors"
              >
                {editingCurrency ? 'Update' : 'Create'} Currency
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditingCurrency(null);
                  resetForm();
                }}
                className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Code</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Symbol</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Default</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {currencies.map((currency) => (
                <tr key={currency.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{currency.code}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{currency.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{currency.symbol}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {currency.isDefault && (
                      <span className="px-2 py-1 text-xs font-bold rounded-full bg-yellow-100 text-yellow-700">Default</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-bold rounded-full ${
                      currency.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {currency.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex gap-2 justify-end">
                      <button
                        onClick={() => handleEdit(currency)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(currency)}
                        className={`${currency.isDefault ? 'text-gray-400 cursor-not-allowed' : 'text-red-600 hover:text-red-900'}`}
                        disabled={currency.isDefault || !currency.id}
                        title={currency.isDefault ? 'Cannot delete default currency' : 'Delete currency'}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default CurrenciesPage;

