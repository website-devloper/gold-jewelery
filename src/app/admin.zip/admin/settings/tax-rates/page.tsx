'use client';

import React, { useState, useEffect } from 'react';
import { getAllTaxRates, createTaxRate, updateTaxRate, deleteTaxRate } from '@/lib/firestore/internationalization_db';
import { TaxRate } from '@/lib/firestore/internationalization';
import { getAllCategories } from '@/lib/firestore/categories_db';
import { Category } from '@/lib/firestore/categories';
import { getCountries, getStates, getCities } from '@/lib/firestore/geography_db';
import { Country, State, City } from '@/lib/firestore/geography';

const TaxRatesPage = () => {
  const [taxRates, setTaxRates] = useState<TaxRate[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [countries, setCountries] = useState<Country[]>([]);
  const [states, setStates] = useState<State[]>([]);
  const [cities, setCities] = useState<City[]>([]);
  const [selectedCountryIds, setSelectedCountryIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingTaxRate, setEditingTaxRate] = useState<TaxRate | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    rate: 0,
    type: 'percentage' as 'percentage' | 'fixed',
    region: '',
    countries: [] as string[],
    states: [] as string[],
    cities: [] as string[],
    applicableTo: 'all' as 'all' | 'products' | 'shipping' | 'both',
    productCategories: [] as string[],
    isActive: true,
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [taxRatesData, categoriesData, countriesData] = await Promise.all([
        getAllTaxRates(),
        getAllCategories(),
        getCountries(),
      ]);
      setTaxRates(taxRatesData);
      setCategories(categoriesData);
      setCountries(countriesData.filter(c => c.status === 'active'));
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Load states when countries are selected
  useEffect(() => {
    const loadStates = async () => {
      if (selectedCountryIds.length > 0) {
        try {
          const allStates: State[] = [];
          for (const countryId of selectedCountryIds) {
            const countryStates = await getStates(countryId);
            allStates.push(...countryStates);
          }
          setStates(allStates.filter((s, index, self) => 
            index === self.findIndex((st) => st.id === s.id)
          ));
        } catch (err) {
          console.error('Failed to load states:', err);
          setStates([]);
        }
      } else {
        setStates([]);
        setCities([]);
      }
    };
    loadStates();
  }, [selectedCountryIds]);

  // Load cities when states are selected
  useEffect(() => {
    const loadCities = async () => {
      if (formData.states && formData.states.length > 0) {
        try {
          const allCities: City[] = [];
          for (const stateId of formData.states) {
            const stateCities = await getCities(stateId);
            allCities.push(...stateCities);
          }
          setCities(allCities.filter((c, index, self) => 
            index === self.findIndex((ci) => ci.id === c.id)
          ));
        } catch (err) {
          console.error('Failed to load cities:', err);
          setCities([]);
        }
      } else {
        setCities([]);
      }
    };
    loadCities();
  }, [formData.states]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingTaxRate) {
        await updateTaxRate(editingTaxRate.id!, formData);
      } else {
        await createTaxRate(formData);
      }
      setShowForm(false);
      setEditingTaxRate(null);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Failed to save tax rate:', error);
      alert('Failed to save tax rate');
    }
  };

  const handleEdit = (taxRate: TaxRate) => {
    setEditingTaxRate(taxRate);
    setFormData({
      name: taxRate.name,
      rate: taxRate.rate,
      type: taxRate.type,
      region: taxRate.region || '',
      countries: taxRate.countries || [],
      states: taxRate.states || [],
      cities: taxRate.cities || [],
      applicableTo: taxRate.applicableTo,
      productCategories: taxRate.productCategories || [],
      isActive: taxRate.isActive,
    });
    setSelectedCountryIds(taxRate.countries || []);
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this tax rate?')) return;
    try {
      await deleteTaxRate(id);
      fetchData();
    } catch (error) {
      console.error('Failed to delete tax rate:', error);
      alert('Failed to delete tax rate');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      rate: 0,
      type: 'percentage',
      region: '',
      countries: [],
      states: [],
      cities: [],
      applicableTo: 'all',
      productCategories: [],
      isActive: true,
    });
    setSelectedCountryIds([]);
  };

  const handleCountryToggle = (countryId: string) => {
    const newCountries = formData.countries.includes(countryId)
      ? formData.countries.filter(id => id !== countryId)
      : [...formData.countries, countryId];
    
    setSelectedCountryIds(newCountries);
    setFormData(prev => ({
      ...prev,
      countries: newCountries,
      // Clear states and cities if country is removed
      states: prev.states.filter(s => {
        const state = states.find(st => st.id === s);
        if (!state) return false;
        return newCountries.includes(state.countryId || '');
      }),
      cities: prev.cities.filter(c => {
        const city = cities.find(ci => ci.id === c);
        if (!city) return false;
        const state = states.find(st => st.id === city.stateId);
        if (!state) return false;
        return newCountries.includes(state.countryId || '');
      }),
    }));
  };

  const handleStateToggle = (stateId: string) => {
    setFormData(prev => ({
      ...prev,
      states: prev.states.includes(stateId)
        ? prev.states.filter(id => id !== stateId)
        : [...prev.states, stateId],
      // Clear cities if state is removed
      cities: prev.cities.filter(c => {
        const city = cities.find(ci => ci.id === c);
        return city && city.stateId === stateId ? false : true;
      }),
    }));
  };

  const handleCityToggle = (cityId: string) => {
    setFormData(prev => ({
      ...prev,
      cities: prev.cities.includes(cityId)
        ? prev.cities.filter(id => id !== cityId)
        : [...prev.cities, cityId],
    }));
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Tax Rates</h1>
          <p className="text-gray-500 mt-1">Configure tax rates by region</p>
        </div>
        <button
          onClick={() => {
            resetForm();
            setEditingTaxRate(null);
            setShowForm(true);
          }}
          className="bg-black text-white px-6 py-2 rounded-full text-sm font-bold uppercase tracking-widest hover:bg-gray-800 transition-colors"
        >
          + New Tax Rate
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-bold mb-4">{editingTaxRate ? 'Edit' : 'Create'} Tax Rate</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tax Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  placeholder="e.g., GST, VAT, Sales Tax"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Region (Country Code) - For backward compatibility</label>
                <input
                  type="text"
                  value={formData.region}
                  onChange={(e) => setFormData({ ...formData, region: e.target.value.toUpperCase() })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  placeholder="e.g., PK, US, UK"
                />
                <p className="text-xs text-gray-500 mt-1">Optional: Use countries below for better control</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tax Type</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value as 'percentage' | 'fixed' })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                >
                  <option value="percentage">Percentage (%)</option>
                  <option value="fixed">Fixed Amount</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {formData.type === 'percentage' ? 'Tax Rate (%)' : 'Tax Amount'}
                </label>
                <input
                  type="number"
                  step={formData.type === 'percentage' ? '0.01' : '0.01'}
                  value={formData.rate}
                  onChange={(e) => setFormData({ ...formData, rate: parseFloat(e.target.value) || 0 })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  required
                  min="0"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Applicable To</label>
                <select
                  value={formData.applicableTo}
                  onChange={(e) => setFormData({ ...formData, applicableTo: e.target.value as 'all' | 'products' | 'shipping' | 'both' })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                >
                  <option value="all">All</option>
                  <option value="products">Products Only</option>
                  <option value="shipping">Shipping Only</option>
                  <option value="both">Products & Shipping</option>
                </select>
              </div>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">Countries (Optional - Leave empty for all countries)</label>
              <div className="border border-gray-300 rounded-lg p-4 max-h-64 overflow-y-auto">
                {countries.length === 0 ? (
                  <p className="text-gray-500 text-sm">Loading countries...</p>
                ) : (
                  <div className="space-y-2">
                    {countries.map(country => (
                      <label key={country.id} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-2 rounded">
                        <input
                          type="checkbox"
                          checked={country.id ? formData.countries.includes(country.id) : false}
                          onChange={() => country.id && handleCountryToggle(country.id)}
                          className="w-4 h-4"
                        />
                        <span className="text-sm text-gray-700">{country.name}</span>
                      </label>
                    ))}
                  </div>
                )}
              </div>
              <p className="text-xs text-gray-500 mt-2">
                Selected: {formData.countries.length} {formData.countries.length === 1 ? 'country' : 'countries'} 
                {formData.countries.length === 0 && ' (All countries)'}
              </p>
            </div>

            {formData.countries.length > 0 && states.length > 0 && (
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">States (Optional - Leave empty for all states)</label>
                <div className="border border-gray-300 rounded-lg p-4 max-h-64 overflow-y-auto">
                  <div className="space-y-2">
                    {states.map(state => (
                      <label key={state.id} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-2 rounded">
                        <input
                          type="checkbox"
                          checked={state.id ? formData.states.includes(state.id) || false : false}
                          onChange={() => state.id && handleStateToggle(state.id)}
                          className="w-4 h-4"
                        />
                        <span className="text-sm text-gray-700">{state.name}</span>
                      </label>
                    ))}
                  </div>
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  Selected: {formData.states.length} {formData.states.length === 1 ? 'state' : 'states'} 
                  {formData.states.length === 0 && ' (All states in selected countries)'}
                </p>
              </div>
            )}

            {formData.states && formData.states.length > 0 && cities.length > 0 && (
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Cities (Optional - Leave empty for all cities)</label>
                <div className="border border-gray-300 rounded-lg p-4 max-h-64 overflow-y-auto">
                  <div className="space-y-2">
                    {cities.map(city => (
                      <label key={city.id} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-2 rounded">
                        <input
                          type="checkbox"
                          checked={city.id ? formData.cities.includes(city.id) || false : false}
                          onChange={() => city.id && handleCityToggle(city.id)}
                          className="w-4 h-4"
                        />
                        <span className="text-sm text-gray-700">{city.name}</span>
                      </label>
                    ))}
                  </div>
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  Selected: {formData.cities.length} {formData.cities.length === 1 ? 'city' : 'cities'}
                  {formData.cities.length === 0 && ' (All cities in selected states)'}
                </p>
              </div>
            )}

            {formData.applicableTo === 'products' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Product Categories (optional)</label>
                <div className="max-h-40 overflow-y-auto border border-gray-300 rounded-lg p-2">
                  {categories.map(category => (
                    <label key={category.id} className="flex items-center gap-2 p-2 hover:bg-gray-50 rounded">
                      <input
                        type="checkbox"
                        checked={formData.productCategories.includes(category.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setFormData({ ...formData, productCategories: [...formData.productCategories, category.id] });
                          } else {
                            setFormData({ ...formData, productCategories: formData.productCategories.filter(id => id !== category.id) });
                          }
                        }}
                        className="w-4 h-4 text-black border-gray-300 rounded focus:ring-black"
                      />
                      <span className="text-sm text-gray-700">{category.name}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={formData.isActive}
                onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                className="w-4 h-4 text-black border-gray-300 rounded focus:ring-black"
              />
              <span className="text-sm font-medium text-gray-700">Active</span>
            </div>
            <div className="flex gap-3">
              <button
                type="submit"
                className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 transition-colors"
              >
                {editingTaxRate ? 'Update' : 'Create'} Tax Rate
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditingTaxRate(null);
                  resetForm();
                }}
                className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Region</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Rate</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Type</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Applicable To</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {taxRates.map((taxRate) => (
                <tr key={taxRate.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{taxRate.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{taxRate.region}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {taxRate.type === 'percentage' ? `${taxRate.rate}%` : `PKR ${taxRate.rate}`}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 capitalize">{taxRate.type}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 capitalize">{taxRate.applicableTo}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-bold rounded-full ${
                      taxRate.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {taxRate.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex gap-2 justify-end">
                      <button
                        onClick={() => handleEdit(taxRate)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(taxRate.id!)}
                        className="text-red-600 hover:text-red-900"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default TaxRatesPage;

