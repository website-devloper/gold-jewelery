'use client';

import React, { useState, useEffect } from 'react';
import { getAllPaymentGateways, createPaymentGateway, updatePaymentGateway, deletePaymentGateway } from '@/lib/firestore/payment_gateways_db';
import { PaymentGateway, PaymentGatewayType } from '@/lib/firestore/payment_gateways';

const PaymentGatewaysPage = () => {
  const [gateways, setGateways] = useState<PaymentGateway[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingGateway, setEditingGateway] = useState<PaymentGateway | null>(null);
  const [formData, setFormData] = useState({
    type: 'stripe' as PaymentGatewayType,
    name: '',
    isActive: true,
    isTestMode: true,
    config: {
      publishableKey: '',
      secretKey: '',
      clientId: '',
      clientSecret: '',
      merchantId: '',
      environment: 'sandbox' as 'sandbox' | 'production',
      publicKey: '',
      keyId: '',
      keySecret: '',
      encryptionKey: '',
    },
    supportedRegions: [] as string[],
    minAmount: 0,
    maxAmount: 0,
    processingFee: 0,
    processingFeeType: 'fixed' as 'fixed' | 'percentage',
    icon: '',
    description: '',
  });

  useEffect(() => {
    fetchGateways();
  }, []);

  const fetchGateways = async () => {
    try {
      const data = await getAllPaymentGateways();
      setGateways(data);
    } catch (error) {
      console.error('Failed to fetch payment gateways:', error);
    } finally {
      setLoading(false);
    }
  };

  const getGatewayDefaults = (type: PaymentGatewayType) => {
    const defaults: Record<PaymentGatewayType, { name: string; icon: string; description: string }> = {
      stripe: { name: 'Stripe', icon: '💳', description: 'Accept payments via credit/debit cards' },
      paypal: { name: 'PayPal', icon: '🅿️', description: 'Pay with PayPal account' },
      paystack: { name: 'Paystack', icon: '💰', description: 'Paystack payment gateway' },
      razorpay: { name: 'Razorpay', icon: '💵', description: 'Razorpay payment gateway' },
      flutterwave: { name: 'Flutterwave', icon: '🌍', description: 'Flutterwave payment gateway' },
    };
    return defaults[type];
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const defaults = getGatewayDefaults(formData.type);
      const gatewayData: Omit<PaymentGateway, 'id' | 'createdAt' | 'updatedAt'> = {
        type: formData.type,
        name: formData.name || defaults.name,
        isActive: formData.isActive,
        isTestMode: formData.isTestMode,
        config: {
          ...(formData.type === 'stripe' && {
            publishableKey: formData.config.publishableKey,
            secretKey: formData.config.secretKey,
          }),
          ...(formData.type === 'paypal' && {
            clientId: formData.config.clientId,
            clientSecret: formData.config.clientSecret,
            merchantId: formData.config.merchantId,
            environment: formData.config.environment,
          }),
          ...(formData.type === 'paystack' && {
            publicKey: formData.config.publicKey,
            secretKey: formData.config.secretKey,
          }),
          ...(formData.type === 'razorpay' && {
            keyId: formData.config.keyId,
            keySecret: formData.config.keySecret,
          }),
          ...(formData.type === 'flutterwave' && {
            publicKey: formData.config.publicKey,
            secretKey: formData.config.secretKey,
            encryptionKey: formData.config.encryptionKey,
          }),
        },
        supportedRegions: formData.supportedRegions.length > 0 ? formData.supportedRegions : undefined,
        minAmount: formData.minAmount || undefined,
        maxAmount: formData.maxAmount || undefined,
        processingFee: formData.processingFee || undefined,
        processingFeeType: formData.processingFeeType,
        icon: formData.icon || defaults.icon,
        description: formData.description || defaults.description,
      };

      if (editingGateway) {
        await updatePaymentGateway(editingGateway.id!, gatewayData);
      } else {
        await createPaymentGateway(gatewayData);
      }
      setShowForm(false);
      setEditingGateway(null);
      resetForm();
      fetchGateways();
    } catch (error) {
      console.error('Failed to save payment gateway:', error);
      alert('Failed to save payment gateway');
    }
  };

  const handleEdit = (gateway: PaymentGateway) => {
    setEditingGateway(gateway);
    setFormData({
      type: gateway.type,
      name: gateway.name,
      isActive: gateway.isActive,
      isTestMode: gateway.isTestMode,
      config: {
        publishableKey: gateway.config.publishableKey || '',
        secretKey: '', // Don't show secret key
        clientId: gateway.config.clientId || '',
        clientSecret: '', // Don't show secret
        merchantId: gateway.config.merchantId || '',
        environment: gateway.config.environment || 'sandbox',
        publicKey: gateway.config.publicKey || '',
        keyId: gateway.config.keyId || '',
        keySecret: '', // Don't show secret
        encryptionKey: '', // Don't show secret
      },
      supportedRegions: gateway.supportedRegions || [],
      minAmount: gateway.minAmount || 0,
      maxAmount: gateway.maxAmount || 0,
      processingFee: gateway.processingFee || 0,
      processingFeeType: gateway.processingFeeType || 'fixed',
      icon: gateway.icon || '',
      description: gateway.description || '',
    });
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this payment gateway?')) return;
    try {
      await deletePaymentGateway(id);
      fetchGateways();
    } catch (error) {
      console.error('Failed to delete payment gateway:', error);
      alert('Failed to delete payment gateway');
    }
  };

  const resetForm = () => {
    setFormData({
      type: 'stripe',
      name: '',
      isActive: true,
      isTestMode: true,
      config: {
        publishableKey: '',
        secretKey: '',
        clientId: '',
        clientSecret: '',
        merchantId: '',
        environment: 'sandbox',
        publicKey: '',
        keyId: '',
        keySecret: '',
        encryptionKey: '',
      },
      supportedRegions: [],
      minAmount: 0,
      maxAmount: 0,
      processingFee: 0,
      processingFeeType: 'fixed',
      icon: '',
      description: '',
    });
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Payment Gateways</h1>
          <p className="text-gray-500 mt-1">Configure payment gateways (Stripe, PayPal, Paystack, Razorpay, Flutterwave)</p>
        </div>
        <button
          onClick={() => {
            resetForm();
            setEditingGateway(null);
            setShowForm(true);
          }}
          className="bg-black text-white px-6 py-2 rounded-full text-sm font-bold uppercase tracking-widest hover:bg-gray-800 transition-colors"
        >
          + New Gateway
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-bold mb-4">{editingGateway ? 'Edit' : 'Create'} Payment Gateway</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Gateway Type</label>
                <select
                  value={formData.type}
                  onChange={(e) => {
                    const type = e.target.value as PaymentGatewayType;
                    const defaults = getGatewayDefaults(type);
                    setFormData({
                      ...formData,
                      type,
                      name: defaults.name,
                      icon: defaults.icon,
                      description: defaults.description,
                    });
                  }}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  required
                >
                  <option value="stripe">Stripe</option>
                  <option value="paypal">PayPal</option>
                  <option value="paystack">Paystack</option>
                  <option value="razorpay">Razorpay</option>
                  <option value="flutterwave">Flutterwave</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Icon (Emoji or URL)</label>
                <input
                  type="text"
                  value={formData.icon}
                  onChange={(e) => setFormData({ ...formData, icon: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  placeholder="💳"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <input
                  type="text"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                />
              </div>
            </div>

            {/* Gateway-specific configuration */}
            <div className="border-t pt-4">
              <h3 className="font-bold text-gray-900 mb-3">Configuration</h3>
              
              {formData.type === 'stripe' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Publishable Key</label>
                    <input
                      type="text"
                      value={formData.config.publishableKey}
                      onChange={(e) => setFormData({ ...formData, config: { ...formData.config, publishableKey: e.target.value } })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Secret Key</label>
                    <input
                      type="password"
                      value={formData.config.secretKey}
                      onChange={(e) => setFormData({ ...formData, config: { ...formData.config, secretKey: e.target.value } })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                      placeholder={editingGateway ? 'Leave blank to keep existing' : ''}
                      required={!editingGateway}
                    />
                  </div>
                </div>
              )}

              {formData.type === 'paypal' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Client ID</label>
                    <input
                      type="text"
                      value={formData.config.clientId}
                      onChange={(e) => setFormData({ ...formData, config: { ...formData.config, clientId: e.target.value } })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Client Secret</label>
                    <input
                      type="password"
                      value={formData.config.clientSecret}
                      onChange={(e) => setFormData({ ...formData, config: { ...formData.config, clientSecret: e.target.value } })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                      placeholder={editingGateway ? 'Leave blank to keep existing' : ''}
                      required={!editingGateway}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Merchant ID</label>
                    <input
                      type="text"
                      value={formData.config.merchantId}
                      onChange={(e) => setFormData({ ...formData, config: { ...formData.config, merchantId: e.target.value } })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Environment</label>
                    <select
                      value={formData.config.environment}
                      onChange={(e) => setFormData({ ...formData, config: { ...formData.config, environment: e.target.value as 'sandbox' | 'production' } })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                    >
                      <option value="sandbox">Sandbox</option>
                      <option value="production">Production</option>
                    </select>
                  </div>
                </div>
              )}

              {formData.type === 'paystack' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Public Key</label>
                    <input
                      type="text"
                      value={formData.config.publicKey}
                      onChange={(e) => setFormData({ ...formData, config: { ...formData.config, publicKey: e.target.value } })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Secret Key</label>
                    <input
                      type="password"
                      value={formData.config.secretKey}
                      onChange={(e) => setFormData({ ...formData, config: { ...formData.config, secretKey: e.target.value } })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                      placeholder={editingGateway ? 'Leave blank to keep existing' : ''}
                      required={!editingGateway}
                    />
                  </div>
                </div>
              )}

              {formData.type === 'razorpay' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Key ID</label>
                    <input
                      type="text"
                      value={formData.config.keyId}
                      onChange={(e) => setFormData({ ...formData, config: { ...formData.config, keyId: e.target.value } })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Key Secret</label>
                    <input
                      type="password"
                      value={formData.config.keySecret}
                      onChange={(e) => setFormData({ ...formData, config: { ...formData.config, keySecret: e.target.value } })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                      placeholder={editingGateway ? 'Leave blank to keep existing' : ''}
                      required={!editingGateway}
                    />
                  </div>
                </div>
              )}

              {formData.type === 'flutterwave' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Public Key</label>
                    <input
                      type="text"
                      value={formData.config.publicKey}
                      onChange={(e) => setFormData({ ...formData, config: { ...formData.config, publicKey: e.target.value } })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Secret Key</label>
                    <input
                      type="password"
                      value={formData.config.secretKey}
                      onChange={(e) => setFormData({ ...formData, config: { ...formData.config, secretKey: e.target.value } })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                      placeholder={editingGateway ? 'Leave blank to keep existing' : ''}
                      required={!editingGateway}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Encryption Key</label>
                    <input
                      type="password"
                      value={formData.config.encryptionKey}
                      onChange={(e) => setFormData({ ...formData, config: { ...formData.config, encryptionKey: e.target.value } })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                      placeholder={editingGateway ? 'Leave blank to keep existing' : ''}
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Min Amount</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.minAmount}
                  onChange={(e) => setFormData({ ...formData, minAmount: parseFloat(e.target.value) || 0 })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  min="0"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Max Amount</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.maxAmount}
                  onChange={(e) => setFormData({ ...formData, maxAmount: parseFloat(e.target.value) || 0 })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  min="0"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Processing Fee</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.processingFee}
                  onChange={(e) => setFormData({ ...formData, processingFee: parseFloat(e.target.value) || 0 })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  min="0"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Processing Fee Type</label>
                <select
                  value={formData.processingFeeType}
                  onChange={(e) => setFormData({ ...formData, processingFeeType: e.target.value as 'fixed' | 'percentage' })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                >
                  <option value="fixed">Fixed</option>
                  <option value="percentage">Percentage</option>
                </select>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.isActive}
                  onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                  className="w-4 h-4 text-black border-gray-300 rounded focus:ring-black"
                />
                <span className="text-sm font-medium text-gray-700">Active</span>
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.isTestMode}
                  onChange={(e) => setFormData({ ...formData, isTestMode: e.target.checked })}
                  className="w-4 h-4 text-black border-gray-300 rounded focus:ring-black"
                />
                <span className="text-sm font-medium text-gray-700">Test Mode</span>
              </label>
            </div>

            <div className="flex gap-3">
              <button
                type="submit"
                className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 transition-colors"
              >
                {editingGateway ? 'Update' : 'Create'} Gateway
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditingGateway(null);
                  resetForm();
                }}
                className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Icon</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Type</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Mode</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {gateways.map((gateway) => (
                <tr key={gateway.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-2xl">{gateway.icon || '💳'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{gateway.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 capitalize">{gateway.type}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <span className={`px-2 py-1 text-xs font-bold rounded-full ${
                      gateway.isTestMode ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'
                    }`}>
                      {gateway.isTestMode ? 'Test' : 'Live'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-bold rounded-full ${
                      gateway.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {gateway.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex gap-2 justify-end">
                      <button
                        onClick={() => handleEdit(gateway)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(gateway.id!)}
                        className="text-red-600 hover:text-red-900"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PaymentGatewaysPage;

