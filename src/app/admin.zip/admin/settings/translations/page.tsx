'use client';

import React, { useState, useEffect } from 'react';
import { getAllLanguages } from '@/lib/firestore/internationalization_db';
import { getAllTranslations, createTranslation, updateTranslation, deleteTranslation, bulkCreateTranslations } from '@/lib/firestore/translations_db';
import { Language } from '@/lib/firestore/internationalization';
import { Translation } from '@/lib/firestore/translations';
import { DEFAULT_TRANSLATION_KEYS } from '@/lib/firestore/translations';

const TranslationsPage = () => {
  const [languages, setLanguages] = useState<Language[]>([]);
  const [selectedLanguage, setSelectedLanguage] = useState<string>('');
  const [translations, setTranslations] = useState<Translation[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingTranslation, setEditingTranslation] = useState<Translation | null>(null);
  const [formData, setFormData] = useState({
    key: '',
    value: '',
    namespace: 'common',
  });
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchLanguages();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (selectedLanguage) {
      fetchTranslations();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedLanguage]);

  const fetchLanguages = async () => {
    try {
      const data = await getAllLanguages(false); // Get all languages, not just active
      setLanguages(data);
      if (data.length > 0 && !selectedLanguage) {
        setSelectedLanguage(data[0].code);
      } else if (data.length === 0) {
        console.warn('No languages found. Please add languages first from Settings > Languages');
      }
    } catch (error) {
      console.error('Failed to fetch languages:', error);
      alert('Failed to load languages. Please check if languages are added in Settings > Languages');
    } finally {
      setLoading(false);
    }
  };

  const fetchTranslations = async () => {
    if (!selectedLanguage) return;
    try {
      const data = await getAllTranslations(selectedLanguage);
      setTranslations(data);
    } catch (error) {
      console.error('Failed to fetch translations:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLanguage) {
      alert('Please select a language first');
      return;
    }

    try {
      if (editingTranslation) {
        await updateTranslation(editingTranslation.id!, {
          key: formData.key,
          value: formData.value,
          namespace: formData.namespace,
        });
      } else {
        await createTranslation({
          key: formData.key,
          value: formData.value,
          languageCode: selectedLanguage,
          namespace: formData.namespace,
        });
      }
      setShowForm(false);
      setEditingTranslation(null);
      resetForm();
      fetchTranslations();
    } catch (error) {
      console.error('Failed to save translation:', error);
      alert('Failed to save translation');
    }
  };

  const handleEdit = (translation: Translation) => {
    setEditingTranslation(translation);
    setFormData({
      key: translation.key,
      value: translation.value,
      namespace: translation.namespace || 'common',
    });
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this translation?')) {
      try {
        await deleteTranslation(id);
        fetchTranslations();
      } catch (error) {
        console.error('Failed to delete translation:', error);
        alert('Failed to delete translation');
      }
    }
  };

  const handleBulkImport = async () => {
    if (!selectedLanguage) {
      alert('Please select a language first');
      return;
    }

    const translationsToImport = Object.entries(DEFAULT_TRANSLATION_KEYS).map(([key, value]) => ({
      key,
      value,
      languageCode: selectedLanguage,
      namespace: key.split('.')[0] || 'common',
    }));

    try {
      await bulkCreateTranslations(translationsToImport);
      alert('Default translations imported successfully!');
      fetchTranslations();
    } catch (error) {
      console.error('Failed to import translations:', error);
      alert('Failed to import translations');
    }
  };

  const resetForm = () => {
    setFormData({
      key: '',
      value: '',
      namespace: 'common',
    });
  };

  const filteredTranslations = translations.filter(t =>
    t.key.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.value.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // const namespaces = Array.from(new Set(translations.map(t => t.namespace || 'common'))); // Currently unused but may be needed for future filtering

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Translations</h1>
        <div className="flex gap-2">
          <select
            value={selectedLanguage}
            onChange={(e) => setSelectedLanguage(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
            disabled={languages.length === 0}
          >
            <option value="">
              {languages.length === 0 ? 'No languages available - Add languages first' : 'Select Language'}
            </option>
            {languages.map(lang => (
              <option key={lang.id || lang.code} value={lang.code}>
                {lang.flag ? `${lang.flag} ` : ''}{lang.nativeName} ({lang.name}) {!lang.isActive ? '(Inactive)' : ''}
              </option>
            ))}
          </select>
          <button
            onClick={() => {
              resetForm();
              setShowForm(true);
              setEditingTranslation(null);
            }}
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
            disabled={!selectedLanguage}
          >
            Add Translation
          </button>
          <button
            onClick={handleBulkImport}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            disabled={!selectedLanguage}
          >
            Import Defaults
          </button>
        </div>
      </div>

      {selectedLanguage && (
        <>
          <div className="mb-4">
            <input
              type="text"
              placeholder="Search translations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full md:w-1/3 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            {filteredTranslations.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                {translations.length === 0
                  ? 'No translations found. Click "Import Defaults" to get started.'
                  : 'No translations match your search.'}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Key</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Translation</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Namespace</th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredTranslations.map((translation) => (
                      <tr key={translation.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {translation.key}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-500">
                          {translation.value}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {translation.namespace || 'common'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <button
                            onClick={() => handleEdit(translation)}
                            className="text-blue-600 hover:text-blue-900 mr-4"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => handleDelete(translation.id!)}
                            className="text-red-600 hover:text-red-900"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}

      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-2xl w-full mx-4">
            <h2 className="text-xl font-bold mb-4">
              {editingTranslation ? 'Edit Translation' : 'Add Translation'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Key</label>
                <input
                  type="text"
                  value={formData.key}
                  onChange={(e) => setFormData({ ...formData, key: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder="e.g., products.add_to_cart"
                  required
                  disabled={!!editingTranslation}
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Translation</label>
                <textarea
                  value={formData.value}
                  onChange={(e) => setFormData({ ...formData, value: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none h-24"
                  placeholder="Enter translated text"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Namespace</label>
                <select
                  value={formData.namespace}
                  onChange={(e) => setFormData({ ...formData, namespace: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  <option value="common">Common</option>
                  <option value="products">Products</option>
                  <option value="cart">Cart</option>
                  <option value="checkout">Checkout</option>
                  <option value="nav">Navigation</option>
                  <option value="footer">Footer</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
              <div className="flex gap-2 justify-end">
                <button
                  type="button"
                  onClick={() => {
                    setShowForm(false);
                    setEditingTranslation(null);
                    resetForm();
                  }}
                  className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  {editingTranslation ? 'Update' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default TranslationsPage;

