'use client';

import React, { useState, useEffect } from 'react';
import { getSettings, updateSettings } from '@/lib/firestore/settings_db';
import { Settings, defaultSettings } from '@/lib/firestore/settings';
import Switch from '@/components/Switch';

const PaymentSettingsPage = () => {
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const data = await getSettings();
      if (data) {
        setSettings({ ...defaultSettings, ...data });
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
      alert('Failed to load settings');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateSettings(settings);
      alert('Payment settings saved successfully!');
    } catch (error) {
      console.error('Error saving settings:', error);
      alert('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const handleInputChange = (field: string, value: unknown) => {
    setSettings((prev) => ({
      ...prev,
      payment: {
        ...prev.payment,
        [field]: value,
      },
    }));
  };

  const handleSwitchChange = (field: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
    handleInputChange(field, e.target.checked);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Payment Settings</h1>
        <p className="text-gray-500 text-sm mt-1">Configure payment methods and options</p>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 p-6 space-y-6">
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-1">Payment Methods</h2>
          <p className="text-gray-500 text-sm">Enable or disable payment methods for your store</p>
        </div>

        <div className="space-y-6">
          {/* COD */}
          <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-gray-900 mb-1">Cash on Delivery (COD)</h3>
              <p className="text-sm text-gray-500">Allow customers to pay when they receive their order</p>
            </div>
            <Switch
              label=""
              checked={settings.payment.enableCOD}
              onChange={handleSwitchChange('enableCOD')}
            />
          </div>

          {/* Local Payment */}
          <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-gray-900 mb-1">Local Payment</h3>
              <p className="text-sm text-gray-500">Enable local payment methods (bank transfer, etc.)</p>
            </div>
            <Switch
              label=""
              checked={settings.payment.enableLocalPayment}
              onChange={handleSwitchChange('enableLocalPayment')}
            />
          </div>

          {/* Online Payment */}
          <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-gray-900 mb-1">Online Payment</h3>
              <p className="text-sm text-gray-500">Enable online payment gateways (Stripe, PayPal, etc.)</p>
            </div>
            <Switch
              label=""
              checked={settings.payment.enableOnlinePayment}
              onChange={handleSwitchChange('enableOnlinePayment')}
            />
          </div>

          {/* Advance Payment */}
          <div className="p-4 border border-gray-200 rounded-lg space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h3 className="text-sm font-semibold text-gray-900 mb-1">Advance Payment</h3>
                <p className="text-sm text-gray-500">Allow customers to make advance/partial payments</p>
              </div>
              <Switch
                label=""
                checked={settings.payment.enableAdvancePayment}
                onChange={handleSwitchChange('enableAdvancePayment')}
              />
            </div>
            
            {settings.payment.enableAdvancePayment && (
              <div className="pt-4 border-t border-gray-200 space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Payment Type
                  </label>
                  <select
                    value={settings.payment.advancePaymentType}
                    onChange={(e) => handleInputChange('advancePaymentType', e.target.value as 'percentage' | 'fixed')}
                    className="w-full max-w-xs px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                  >
                    <option value="percentage">Percentage</option>
                    <option value="fixed">Fixed Amount</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    {settings.payment.advancePaymentType === 'percentage' ? 'Percentage (%)' : 'Fixed Amount (PKR)'}
                  </label>
                  <input
                    type="number"
                    step={settings.payment.advancePaymentType === 'percentage' ? '1' : '0.01'}
                    min="0"
                    max={settings.payment.advancePaymentType === 'percentage' ? '100' : undefined}
                    value={settings.payment.advancePaymentValue}
                    onChange={(e) => handleInputChange('advancePaymentValue', parseFloat(e.target.value) || 0)}
                    className="w-full max-w-xs px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                    placeholder={settings.payment.advancePaymentType === 'percentage' ? '50' : '1000'}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    {settings.payment.advancePaymentType === 'percentage' 
                      ? 'Enter percentage (0-100) of total order amount'
                      : 'Enter fixed amount in PKR'}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Wallet */}
          <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-gray-900 mb-1">Wallet</h3>
              <p className="text-sm text-gray-500">Enable wallet feature for customers to store and use balance</p>
            </div>
            <Switch
              label=""
              checked={settings.payment.enableWallet}
              onChange={handleSwitchChange('enableWallet')}
            />
          </div>

          {/* Loyalty Points */}
          <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-gray-900 mb-1">Loyalty Points</h3>
              <p className="text-sm text-gray-500">Enable loyalty points system for customer rewards</p>
            </div>
            <Switch
              label=""
              checked={settings.payment.enableLoyaltyPoint}
              onChange={handleSwitchChange('enableLoyaltyPoint')}
            />
          </div>
        </div>

        {/* Loyalty Point Value */}
        {settings.payment.enableLoyaltyPoint && (
          <div className="mt-8 pt-6 border-t border-gray-200">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Loyalty Point Value
              </label>
              <p className="text-sm text-gray-500 mb-4">
                Conversion rate: 1 point = X amount (e.g., 1 point = 1 PKR)
              </p>
              <input
                type="number"
                step="0.01"
                min="0"
                value={settings.payment.loyaltyPointValue}
                onChange={(e) => handleInputChange('loyaltyPointValue', parseFloat(e.target.value) || 0)}
                className="w-full max-w-xs px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                placeholder="1.00"
              />
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="mt-8 pt-6 border-t border-gray-200 flex items-center justify-end gap-4">
          <button
            type="button"
            onClick={fetchSettings}
            className="px-6 py-2.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 hover:text-black transition-colors"
            disabled={saving}
          >
            Discard Changes
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={saving}
            className={`px-6 py-2.5 bg-black text-white rounded-lg text-sm font-bold hover:bg-gray-800 transition-all shadow-lg flex items-center ${saving ? 'opacity-70 cursor-not-allowed' : ''}`}
          >
            {saving ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Saving...
              </>
            ) : (
              'Save Settings'
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default PaymentSettingsPage;

