'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { useSearchParams } from 'next/navigation';
import { getSettings, updateSettings } from '@/lib/firestore/settings_db';
import { Settings, defaultSettings } from '@/lib/firestore/settings';
import { storage } from '@/lib/firebase';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { useLanguage } from '@/context/LanguageContext';

const ThemePage = () => {
  const { t } = useLanguage();
  const searchParams = useSearchParams();
  const [activeTab, setActiveTab] = useState('logo');
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState<{ [key: string]: boolean }>({});

  useEffect(() => {
    const tab = searchParams.get('tab');
    if (tab) {
      setActiveTab(tab);
    }
  }, [searchParams]);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const data = await getSettings();
      if (data) {
        setSettings({ ...defaultSettings, ...data });
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
      alert('Failed to load settings');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateSettings(settings);
      alert('Theme settings saved successfully!');
    } catch (error) {
      console.error('Error saving settings:', error);
      alert('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const handleInputChange = (
    section: 'colors' | 'fonts' | 'topBar',
    field: string,
    value: unknown
  ) => {
    setSettings((prev) => {
      const currentTheme = prev.theme || defaultSettings.theme;
      if (section === 'colors') {
        return {
          ...prev,
          theme: {
            ...currentTheme,
            colors: {
              ...(currentTheme.colors || defaultSettings.theme.colors),
              [field]: value,
            },
          },
        };
      }
      if (section === 'fonts') {
        return {
          ...prev,
          theme: {
            ...currentTheme,
            fonts: {
              ...(currentTheme.fonts || defaultSettings.theme.fonts),
              [field]: value,
            },
          },
        };
      }
      if (section === 'topBar') {
        return {
          ...prev,
          theme: {
            ...currentTheme,
            topBar: {
              ...(currentTheme.topBar || defaultSettings.theme.topBar),
              [field]: value,
            },
          },
        };
      }
      return prev;
    });
  };

  const handleFileUpload = async (
    file: File,
    field: 'logoUrl' | 'faviconUrl' | 'loginImageUrl'
  ) => {
    if (!file) return;

    setUploading((prev) => ({ ...prev, [field]: true }));
    try {
      const storageRef = ref(storage, `theme/${field}_${Date.now()}_${file.name}`);
      await uploadBytes(storageRef, file);
      const url = await getDownloadURL(storageRef);
      
      setSettings((prev) => ({
        ...prev,
        theme: {
          ...prev.theme,
          [field]: url,
        },
      }));
    } catch (error) {
      console.error(`Error uploading ${field}:`, error);
      alert('Failed to upload image');
    } finally {
      setUploading((prev) => ({ ...prev, [field]: false }));
    }
  };

  const tabs = [
    { id: 'logo', label: 'App Logo & Favicon' },
    { id: 'login', label: 'Login Image' },
    { id: 'colors', label: 'Website Colors' },
    { id: 'fonts', label: 'Website Fonts' },
    { id: 'topbar', label: 'Top Bar' },
  ];

  const fontOptions = [
    { value: 'Inter', label: 'Inter' },
    { value: 'Poppins', label: 'Poppins' },
    { value: 'Roboto', label: 'Roboto' },
    { value: 'Open Sans', label: 'Open Sans' },
    { value: 'Montserrat', label: 'Montserrat' },
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-8">
        {t('admin.theme') || 'Theme Settings'}
      </h1>
      
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="flex border-b border-gray-200 flex-wrap">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`whitespace-nowrap py-4 px-6 border-b-2 font-medium text-sm transition-all focus:outline-none ${
                activeTab === tab.id
                  ? 'border-black text-black bg-gray-50'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="p-8">
          {/* App Logo & Favicon */}
          {activeTab === 'logo' && (
            <div className="space-y-8 animate-fadeIn">
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-1">App Logo & Favicon</h3>
                <p className="text-gray-500 text-sm">Update your brand assets and visual identity.</p>
              </div>
              
              <div className="grid grid-cols-1 gap-8">
                {/* Logo Upload */}
                <div className="bg-gray-50 p-6 rounded-xl border border-gray-200">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <label className="block text-base font-bold text-gray-900 mb-1">Website Logo</label>
                      <p className="text-sm text-gray-500">Displayed in the header. Recommended size: 200x60px (PNG/SVG).</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="h-16 w-40 bg-white border border-gray-200 border-dashed rounded-lg flex items-center justify-center text-gray-400 text-xs font-medium overflow-hidden relative">
                        {settings.theme.logoUrl ? (
                          <Image src={settings.theme.logoUrl} alt="Logo" fill className="object-contain" unoptimized />
                        ) : (
                          "Preview"
                        )}
                        {uploading.logoUrl && (
                          <div className="absolute inset-0 bg-black/50 flex items-center justify-center text-white text-xs">Uploading...</div>
                        )}
                      </div>
                      <label className="cursor-pointer px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 hover:text-black transition-colors shadow-sm">
                        Change
                        <input 
                          type="file" 
                          className="hidden" 
                          accept="image/*"
                          onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'logoUrl')}
                        />
                      </label>
                    </div>
                  </div>
                </div>

                {/* Favicon Upload */}
                <div className="bg-gray-50 p-6 rounded-xl border border-gray-200">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <label className="block text-base font-bold text-gray-900 mb-1">Favicon</label>
                      <p className="text-sm text-gray-500">Browser tab icon. Recommended size: 32x32px (ICO/PNG).</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 bg-white border border-gray-200 border-dashed rounded-lg flex items-center justify-center text-gray-400 text-xs font-medium overflow-hidden relative">
                        {settings.theme.faviconUrl ? (
                          <Image src={settings.theme.faviconUrl} alt="Favicon" fill className="object-contain" unoptimized />
                        ) : (
                          "32x32"
                        )}
                        {uploading.faviconUrl && (
                          <div className="absolute inset-0 bg-black/50 flex items-center justify-center text-white text-xs">Uploading...</div>
                        )}
                      </div>
                      <label className="cursor-pointer px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 hover:text-black transition-colors shadow-sm">
                        Change
                        <input 
                          type="file" 
                          className="hidden" 
                          accept="image/*"
                          onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'faviconUrl')}
                        />
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Login Image */}
          {activeTab === 'login' && (
            <div className="space-y-8 animate-fadeIn">
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-1">Login Image</h3>
                <p className="text-gray-500 text-sm">Upload an image to display on the login page.</p>
              </div>
              
              <div className="bg-gray-50 p-6 rounded-xl border border-gray-200">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <label className="block text-base font-bold text-gray-900 mb-1">Login Page Image</label>
                    <p className="text-sm text-gray-500">Recommended size: 800x600px (JPG/PNG).</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="h-32 w-48 bg-white border border-gray-200 border-dashed rounded-lg flex items-center justify-center text-gray-400 text-xs font-medium overflow-hidden relative">
                      {settings.theme.loginImageUrl ? (
                        <Image src={settings.theme.loginImageUrl} alt="Login Image" fill className="object-cover" unoptimized />
                      ) : (
                        "Preview"
                      )}
                      {uploading.loginImageUrl && (
                        <div className="absolute inset-0 bg-black/50 flex items-center justify-center text-white text-xs">Uploading...</div>
                      )}
                    </div>
                    <label className="cursor-pointer px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 hover:text-black transition-colors shadow-sm">
                      {settings.theme.loginImageUrl ? 'Change' : 'Upload'}
                      <input 
                        type="file" 
                        className="hidden" 
                        accept="image/*"
                        onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'loginImageUrl')}
                      />
                    </label>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Website Colors */}
          {activeTab === 'colors' && (
            <div className="space-y-8 animate-fadeIn">
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-1">Website Colors</h3>
                <p className="text-gray-500 text-sm">Customize the color scheme of your website.</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Header Background</label>
                  <div className="flex gap-2">
                    <input 
                      type="color" 
                      value={settings.theme.colors?.headerBackground || '#ffffff'}
                      onChange={(e) => handleInputChange('colors', 'headerBackground', e.target.value)}
                      className="h-10 w-16 p-1 border border-gray-300 rounded cursor-pointer"
                    />
                    <input 
                      type="text" 
                      value={settings.theme.colors?.headerBackground || '#ffffff'}
                      onChange={(e) => handleInputChange('colors', 'headerBackground', e.target.value)}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Header Text</label>
                  <div className="flex gap-2">
                    <input 
                      type="color" 
                      value={settings.theme.colors?.headerText || '#000000'}
                      onChange={(e) => handleInputChange('colors', 'headerText', e.target.value)}
                      className="h-10 w-16 p-1 border border-gray-300 rounded cursor-pointer"
                    />
                    <input 
                      type="text" 
                      value={settings.theme.colors?.headerText || '#000000'}
                      onChange={(e) => handleInputChange('colors', 'headerText', e.target.value)}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Footer Background</label>
                  <div className="flex gap-2">
                    <input 
                      type="color" 
                      value={settings.theme.colors?.footerBackground || '#1f2937'}
                      onChange={(e) => handleInputChange('colors', 'footerBackground', e.target.value)}
                      className="h-10 w-16 p-1 border border-gray-300 rounded cursor-pointer"
                    />
                    <input 
                      type="text" 
                      value={settings.theme.colors?.footerBackground || '#1f2937'}
                      onChange={(e) => handleInputChange('colors', 'footerBackground', e.target.value)}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Footer Text</label>
                  <div className="flex gap-2">
                    <input 
                      type="color" 
                      value={settings.theme.colors?.footerText || '#ffffff'}
                      onChange={(e) => handleInputChange('colors', 'footerText', e.target.value)}
                      className="h-10 w-16 p-1 border border-gray-300 rounded cursor-pointer"
                    />
                    <input 
                      type="text" 
                      value={settings.theme.colors?.footerText || '#ffffff'}
                      onChange={(e) => handleInputChange('colors', 'footerText', e.target.value)}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Primary Button</label>
                  <div className="flex gap-2">
                    <input 
                      type="color" 
                      value={settings.theme.colors?.primaryButton || '#000000'}
                      onChange={(e) => handleInputChange('colors', 'primaryButton', e.target.value)}
                      className="h-10 w-16 p-1 border border-gray-300 rounded cursor-pointer"
                    />
                    <input 
                      type="text" 
                      value={settings.theme.colors?.primaryButton || '#000000'}
                      onChange={(e) => handleInputChange('colors', 'primaryButton', e.target.value)}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Primary Button Text</label>
                  <div className="flex gap-2">
                    <input 
                      type="color" 
                      value={settings.theme.colors?.primaryButtonText || '#ffffff'}
                      onChange={(e) => handleInputChange('colors', 'primaryButtonText', e.target.value)}
                      className="h-10 w-16 p-1 border border-gray-300 rounded cursor-pointer"
                    />
                    <input 
                      type="text" 
                      value={settings.theme.colors?.primaryButtonText || '#ffffff'}
                      onChange={(e) => handleInputChange('colors', 'primaryButtonText', e.target.value)}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Secondary Button</label>
                  <div className="flex gap-2">
                    <input 
                      type="color" 
                      value={settings.theme.colors?.secondaryButton || '#f3f4f6'}
                      onChange={(e) => handleInputChange('colors', 'secondaryButton', e.target.value)}
                      className="h-10 w-16 p-1 border border-gray-300 rounded cursor-pointer"
                    />
                    <input 
                      type="text" 
                      value={settings.theme.colors?.secondaryButton || '#f3f4f6'}
                      onChange={(e) => handleInputChange('colors', 'secondaryButton', e.target.value)}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Secondary Button Text</label>
                  <div className="flex gap-2">
                    <input 
                      type="color" 
                      value={settings.theme.colors?.secondaryButtonText || '#000000'}
                      onChange={(e) => handleInputChange('colors', 'secondaryButtonText', e.target.value)}
                      className="h-10 w-16 p-1 border border-gray-300 rounded cursor-pointer"
                    />
                    <input 
                      type="text" 
                      value={settings.theme.colors?.secondaryButtonText || '#000000'}
                      onChange={(e) => handleInputChange('colors', 'secondaryButtonText', e.target.value)}
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Website Fonts */}
          {activeTab === 'fonts' && (
            <div className="space-y-8 animate-fadeIn">
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-1">Website Fonts</h3>
                <p className="text-gray-500 text-sm">Choose fonts for headings and body text.</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Heading Font</label>
                  <select 
                    value={settings.theme.fonts?.heading || 'Inter'}
                    onChange={(e) => handleInputChange('fonts', 'heading', e.target.value)}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none transition-all bg-white"
                  >
                    {fontOptions.map(font => (
                      <option key={font.value} value={font.value}>{font.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Body Font</label>
                  <select 
                    value={settings.theme.fonts?.body || 'Inter'}
                    onChange={(e) => handleInputChange('fonts', 'body', e.target.value)}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none transition-all bg-white"
                  >
                    {fontOptions.map(font => (
                      <option key={font.value} value={font.value}>{font.label}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Top Bar */}
          {activeTab === 'topbar' && (
            <div className="space-y-8 animate-fadeIn">
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-1">Top Bar</h3>
                <p className="text-gray-500 text-sm">Configure the promotional banner at the top of your website.</p>
              </div>
              
              <div className="space-y-6">
                <div className="flex items-center p-4 border border-gray-200 rounded-lg">
                  <input 
                    type="checkbox" 
                    checked={settings.theme.topBar?.enabled || false}
                    onChange={(e) => handleInputChange('topBar', 'enabled', e.target.checked)}
                    className="w-5 h-5 text-black border-gray-300 rounded focus:ring-black" 
                  />
                  <div className="ml-3">
                    <span className="block text-sm font-medium text-gray-900">Enable Top Bar</span>
                    <span className="block text-sm text-gray-500">Show promotional message at the top of the website</span>
                  </div>
                </div>

                {settings.theme.topBar?.enabled && (
                  <>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">Message Text</label>
                      <input 
                        type="text" 
                        value={settings.theme.topBar?.text || ''}
                        onChange={(e) => handleInputChange('topBar', 'text', e.target.value)}
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none transition-all" 
                        placeholder="FREE SHIPPING ON ORDERS OVER PKR 5000"
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">Background Color</label>
                        <div className="flex gap-2">
                          <input 
                            type="color" 
                            value={settings.theme.topBar?.backgroundColor || '#000000'}
                            onChange={(e) => handleInputChange('topBar', 'backgroundColor', e.target.value)}
                            className="h-10 w-16 p-1 border border-gray-300 rounded cursor-pointer"
                          />
                          <input 
                            type="text" 
                            value={settings.theme.topBar?.backgroundColor || '#000000'}
                            onChange={(e) => handleInputChange('topBar', 'backgroundColor', e.target.value)}
                            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none font-mono"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">Text Color</label>
                        <div className="flex gap-2">
                          <input 
                            type="color" 
                            value={settings.theme.topBar?.textColor || '#ffffff'}
                            onChange={(e) => handleInputChange('topBar', 'textColor', e.target.value)}
                            className="h-10 w-16 p-1 border border-gray-300 rounded cursor-pointer"
                          />
                          <input 
                            type="text" 
                            value={settings.theme.topBar?.textColor || '#ffffff'}
                            onChange={(e) => handleInputChange('topBar', 'textColor', e.target.value)}
                            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none font-mono"
                          />
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="mt-12 pt-6 border-t border-gray-200 flex items-center justify-end gap-4">
            <button
              type="button"
              onClick={fetchSettings}
              className="px-6 py-2.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 hover:text-black transition-colors"
              disabled={saving}
            >
              Discard Changes
            </button>
            <button
              type="button"
              onClick={handleSave}
              disabled={saving}
              className={`px-6 py-2.5 bg-black text-white rounded-lg text-sm font-bold hover:bg-gray-800 transition-all shadow-lg transform hover:-translate-y-0.5 flex items-center ${saving ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              {saving ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Saving...
                </>
              ) : (
                'Save Theme Settings'
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ThemePage;

