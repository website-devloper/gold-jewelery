'use client';

import React, { useState, useEffect } from 'react';
import { getAllLocalPaymentMethods, createLocalPaymentMethod, updateLocalPaymentMethod, deleteLocalPaymentMethod } from '@/lib/firestore/internationalization_db';
import { LocalPaymentMethod } from '@/lib/firestore/internationalization';

const PaymentMethodsPage = () => {
  const [methods, setMethods] = useState<LocalPaymentMethod[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingMethod, setEditingMethod] = useState<LocalPaymentMethod | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    type: 'manual' as 'wallet' | 'bank' | 'card' | 'manual',
    icon: '',
    isActive: true,
    accountNumber: '',
    accountTitle: '',
    bankName: '',
    iban: '',
    swiftCode: '',
    instructions: '',
    apiKey: '',
    merchantId: '',
    apiUrl: '',
    supportedRegions: [] as string[],
    minAmount: 0,
    maxAmount: 0,
    processingFee: 0,
    processingFeeType: 'fixed' as 'fixed' | 'percentage',
  });

  useEffect(() => {
    fetchMethods();
  }, []);

  const fetchMethods = async () => {
    try {
      const data = await getAllLocalPaymentMethods();
      setMethods(data);
    } catch (error) {
      console.error('Failed to fetch payment methods:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const methodData: Omit<LocalPaymentMethod, 'id' | 'createdAt' | 'updatedAt'> = {
        name: formData.name,
        code: formData.code,
        type: formData.type,
        icon: formData.icon || undefined,
        isActive: formData.isActive,
        config: {
          accountNumber: formData.accountNumber || undefined,
          accountTitle: formData.accountTitle || undefined,
          bankName: formData.bankName || undefined,
          iban: formData.iban || undefined,
          swiftCode: formData.swiftCode || undefined,
          instructions: formData.instructions || undefined,
          apiKey: formData.apiKey || undefined,
          merchantId: formData.merchantId || undefined,
          apiUrl: formData.apiUrl || undefined,
        },
        supportedRegions: formData.supportedRegions.length > 0 ? formData.supportedRegions : undefined,
        minAmount: formData.minAmount || undefined,
        maxAmount: formData.maxAmount || undefined,
        processingFee: formData.processingFee || undefined,
        processingFeeType: formData.processingFeeType,
      };

      if (editingMethod) {
        await updateLocalPaymentMethod(editingMethod.id!, methodData);
      } else {
        await createLocalPaymentMethod(methodData);
      }
      setShowForm(false);
      setEditingMethod(null);
      resetForm();
      fetchMethods();
    } catch (error) {
      console.error('Failed to save payment method:', error);
      alert('Failed to save payment method');
    }
  };

  const handleEdit = (method: LocalPaymentMethod) => {
    setEditingMethod(method);
    setFormData({
      name: method.name,
      code: method.code,
      type: method.type,
      icon: method.icon || '',
      isActive: method.isActive,
      accountNumber: method.config?.accountNumber || '',
      accountTitle: method.config?.accountTitle || '',
      bankName: method.config?.bankName || '',
      iban: method.config?.iban || '',
      swiftCode: method.config?.swiftCode || '',
      instructions: method.config?.instructions || '',
      apiKey: method.config?.apiKey || '',
      merchantId: method.config?.merchantId || '',
      apiUrl: method.config?.apiUrl || '',
      supportedRegions: method.supportedRegions || [],
      minAmount: method.minAmount || 0,
      maxAmount: method.maxAmount || 0,
      processingFee: method.processingFee || 0,
      processingFeeType: method.processingFeeType || 'fixed',
    });
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this payment method?')) return;
    try {
      await deleteLocalPaymentMethod(id);
      fetchMethods();
    } catch (error) {
      console.error('Failed to delete payment method:', error);
      alert('Failed to delete payment method');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      code: '',
      type: 'manual',
      icon: '',
      isActive: true,
      accountNumber: '',
      accountTitle: '',
      bankName: '',
      iban: '',
      swiftCode: '',
      instructions: '',
      apiKey: '',
      merchantId: '',
      apiUrl: '',
      supportedRegions: [],
      minAmount: 0,
      maxAmount: 0,
      processingFee: 0,
      processingFeeType: 'fixed',
    });
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Local Payment Methods</h1>
          <p className="text-gray-500 mt-1">Configure local payment gateways (JazzCash, EasyPaisa, Bank Transfer, etc.)</p>
        </div>
        <button
          onClick={() => {
            resetForm();
            setEditingMethod(null);
            setShowForm(true);
          }}
          className="bg-black text-white px-6 py-2 rounded-full text-sm font-bold uppercase tracking-widest hover:bg-gray-800 transition-colors"
        >
          + New Payment Method
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-bold mb-4">{editingMethod ? 'Edit' : 'Create'} Payment Method</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  placeholder="e.g., JazzCash, EasyPaisa"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Code</label>
                <input
                  type="text"
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value.toLowerCase().replace(/\s+/g, '_') })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  placeholder="e.g., jazzcash, easypaisa"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
                <select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value as 'wallet' | 'bank' | 'card' | 'manual' })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                >
                  <option value="wallet">Wallet</option>
                  <option value="bank">Bank Transfer</option>
                  <option value="card">Card</option>
                  <option value="manual">Manual</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Icon (Emoji or URL)</label>
                <input
                  type="text"
                  value={formData.icon}
                  onChange={(e) => setFormData({ ...formData, icon: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  placeholder="💳 or URL"
                />
              </div>
            </div>
            
            {(formData.type === 'bank' || formData.type === 'manual') && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Account Number</label>
                  <input
                    type="text"
                    value={formData.accountNumber}
                    onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Account Title</label>
                  <input
                    type="text"
                    value={formData.accountTitle}
                    onChange={(e) => setFormData({ ...formData, accountTitle: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Bank Name</label>
                  <input
                    type="text"
                    value={formData.bankName}
                    onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">IBAN</label>
                  <input
                    type="text"
                    value={formData.iban}
                    onChange={(e) => setFormData({ ...formData, iban: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">SWIFT Code</label>
                  <input
                    type="text"
                    value={formData.swiftCode}
                    onChange={(e) => setFormData({ ...formData, swiftCode: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  />
                </div>
                {formData.type === 'manual' && (
                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Instructions</label>
                    <textarea
                      value={formData.instructions}
                      onChange={(e) => setFormData({ ...formData, instructions: e.target.value })}
                      rows={3}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                      placeholder="Payment instructions for customers..."
                    />
                  </div>
                )}
              </div>
            )}

            {(formData.type === 'wallet' || formData.type === 'card') && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">API Key</label>
                  <input
                    type="text"
                    value={formData.apiKey}
                    onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Merchant ID</label>
                  <input
                    type="text"
                    value={formData.merchantId}
                    onChange={(e) => setFormData({ ...formData, merchantId: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">API URL</label>
                  <input
                    type="text"
                    value={formData.apiUrl}
                    onChange={(e) => setFormData({ ...formData, apiUrl: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                    placeholder="https://api.example.com"
                  />
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Min Amount</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.minAmount}
                  onChange={(e) => setFormData({ ...formData, minAmount: parseFloat(e.target.value) || 0 })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  min="0"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Max Amount</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.maxAmount}
                  onChange={(e) => setFormData({ ...formData, maxAmount: parseFloat(e.target.value) || 0 })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  min="0"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Processing Fee</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.processingFee}
                  onChange={(e) => setFormData({ ...formData, processingFee: parseFloat(e.target.value) || 0 })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  min="0"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Processing Fee Type</label>
                <select
                  value={formData.processingFeeType}
                  onChange={(e) => setFormData({ ...formData, processingFeeType: e.target.value as 'fixed' | 'percentage' })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                >
                  <option value="fixed">Fixed</option>
                  <option value="percentage">Percentage</option>
                </select>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={formData.isActive}
                onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                className="w-4 h-4 text-black border-gray-300 rounded focus:ring-black"
              />
              <span className="text-sm font-medium text-gray-700">Active</span>
            </div>

            <div className="flex gap-3">
              <button
                type="submit"
                className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 transition-colors"
              >
                {editingMethod ? 'Update' : 'Create'} Payment Method
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditingMethod(null);
                  resetForm();
                }}
                className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Icon</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Code</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Type</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {methods.map((method) => (
                <tr key={method.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-2xl">{method.icon || '💳'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{method.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{method.code}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 capitalize">{method.type}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-bold rounded-full ${
                      method.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {method.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex gap-2 justify-end">
                      <button
                        onClick={() => handleEdit(method)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(method.id!)}
                        className="text-red-600 hover:text-red-900"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PaymentMethodsPage;

