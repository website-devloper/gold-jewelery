'use client';

import React, { useState, useEffect } from 'react';
import { getAllOrders, updateOrder } from '@/lib/firestore/orders_db';
import { Order, OrderStatus } from '@/lib/firestore/orders';
const BatchProcessingPage = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedOrders, setSelectedOrders] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [action, setAction] = useState<'status' | 'carrier' | 'tracking'>('status');
  const [status, setStatus] = useState<OrderStatus>(OrderStatus.Processing);
  const [carrierId, setCarrierId] = useState('');
  const [trackingNumber, setTrackingNumber] = useState('');

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const data = await getAllOrders();
      setOrders(data);
    } catch (error) {
      console.error('Failed to fetch orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedOrders(orders.map(o => o.id!));
    } else {
      setSelectedOrders([]);
    }
  };

  const handleSelectOrder = (orderId: string, checked: boolean) => {
    if (checked) {
      setSelectedOrders([...selectedOrders, orderId]);
    } else {
      setSelectedOrders(selectedOrders.filter(id => id !== orderId));
    }
  };

  const handleBatchProcess = async () => {
    if (selectedOrders.length === 0) {
      alert('Please select at least one order');
      return;
    }

    setProcessing(true);
    try {
      const updates: Partial<Pick<Order, 'status' | 'carrierId' | 'trackingNumber'>> = {};
      
      if (action === 'status') {
        updates.status = status;
      } else if (action === 'carrier') {
        updates.carrierId = carrierId;
      } else if (action === 'tracking') {
        updates.trackingNumber = trackingNumber;
      }

      await Promise.all(
        selectedOrders.map(orderId => updateOrder(orderId, updates))
      );

      alert(`Successfully updated ${selectedOrders.length} orders`);
      setSelectedOrders([]);
      fetchOrders();
    } catch (error) {
      console.error('Failed to process orders:', error);
      alert('Failed to process orders');
    } finally {
      setProcessing(false);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Batch Order Processing</h1>
          <p className="text-gray-500 mt-1">Process multiple orders at once</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Action</label>
            <select
              value={action}
              onChange={(e) => setAction(e.target.value as 'status' | 'carrier' | 'tracking')}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
            >
              <option value="status">Update Status</option>
              <option value="carrier">Update Carrier</option>
              <option value="tracking">Update Tracking Number</option>
            </select>
          </div>
          {action === 'status' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">New Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as OrderStatus)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
              >
                <option value={OrderStatus.Pending}>Pending</option>
                <option value={OrderStatus.Processing}>Processing</option>
                <option value={OrderStatus.Shipped}>Shipped</option>
                <option value={OrderStatus.Delivered}>Delivered</option>
                <option value={OrderStatus.Cancelled}>Cancelled</option>
              </select>
            </div>
          )}
          {action === 'carrier' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Carrier ID</label>
              <input
                type="text"
                value={carrierId}
                onChange={(e) => setCarrierId(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                placeholder="Enter carrier ID"
              />
            </div>
          )}
          {action === 'tracking' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Tracking Number</label>
              <input
                type="text"
                value={trackingNumber}
                onChange={(e) => setTrackingNumber(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                placeholder="Enter tracking number"
              />
            </div>
          )}
          <button
            onClick={handleBatchProcess}
            disabled={processing || selectedOrders.length === 0}
            className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {processing ? 'Processing...' : `Process ${selectedOrders.length} Selected Orders`}
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={selectedOrders.length === orders.length && orders.length > 0}
              onChange={(e) => handleSelectAll(e.target.checked)}
              className="w-4 h-4 text-black border-gray-300 rounded focus:ring-black"
            />
            <span className="text-sm font-medium text-gray-700">
              Select All ({selectedOrders.length} selected)
            </span>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider w-12"></th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Order ID</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Customer</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Items</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Total</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {orders.map((order) => (
                <tr key={order.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <input
                      type="checkbox"
                      checked={selectedOrders.includes(order.id!)}
                      onChange={(e) => handleSelectOrder(order.id!, e.target.checked)}
                      className="w-4 h-4 text-black border-gray-300 rounded focus:ring-black"
                    />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{order.id?.slice(0, 8)}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{order.shippingAddress.fullName}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{order.items.length} items</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">PKR {order.totalAmount.toLocaleString()}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-bold rounded-full ${
                      order.status === 'delivered' ? 'bg-green-100 text-green-700' :
                      order.status === 'shipped' ? 'bg-blue-100 text-blue-700' :
                      order.status === 'processing' ? 'bg-yellow-100 text-yellow-700' :
                      order.status === 'cancelled' ? 'bg-red-100 text-red-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {order.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default BatchProcessingPage;

