'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { getOrderReturns, updateOrderReturn } from '@/lib/firestore/order_management_db';
import { OrderReturn } from '@/lib/firestore/order_management';
import { Timestamp } from 'firebase/firestore';
import { useAuth } from '../../../../context/AuthContext';

const ReturnsPage = () => {
  const { user } = useAuth();
  const [returns, setReturns] = useState<OrderReturn[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<OrderReturn['status'] | 'all'>('all');

  useEffect(() => {
    fetchReturns();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  const fetchReturns = async () => {
    try {
      const data = await getOrderReturns();
      setReturns(filter === 'all' ? data : data.filter(r => r.status === filter));
    } catch (error) {
      console.error('Failed to fetch returns:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (returnId: string, status: OrderReturn['status']) => {
    if (!user) return;

    try {
      const updates: Partial<Pick<OrderReturn, 'status' | 'approvedBy' | 'approvedAt' | 'receivedAt' | 'processedAt'>> = { status };
      
      if (status === 'approved') {
        updates.approvedBy = user.uid;
        updates.approvedAt = Timestamp.now();
      } else if (status === 'received') {
        updates.receivedAt = Timestamp.now();
      } else if (status === 'processed') {
        updates.processedAt = Timestamp.now();
      }

      await updateOrderReturn(returnId, updates);
      fetchReturns();
    } catch (error) {
      console.error('Failed to update return:', error);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Order Returns</h1>
          <p className="text-gray-500 mt-1">Manage return and exchange requests</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === 'all' ? 'bg-black text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter('requested')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === 'requested' ? 'bg-black text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Requested
          </button>
          <button
            onClick={() => setFilter('approved')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === 'approved' ? 'bg-black text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Approved
          </button>
          <button
            onClick={() => setFilter('received')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === 'received' ? 'bg-black text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Received
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Return #</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Order ID</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Items</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Type</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Reason</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Requested</th>
                <th className="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {returns.map((returnOrder) => (
                <tr key={returnOrder.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">{returnOrder.returnNumber}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <Link href={`/admin/orders/${returnOrder.orderId}`} className="text-blue-600 hover:text-blue-900">
                      {returnOrder.orderId.slice(0, 8)}
                    </Link>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">{returnOrder.items.length} items</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 capitalize">{returnOrder.items[0]?.returnType || 'return'}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{returnOrder.reason}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-bold rounded-full ${
                      returnOrder.status === 'refunded' || returnOrder.status === 'exchanged' ? 'bg-green-100 text-green-700' :
                      returnOrder.status === 'approved' ? 'bg-blue-100 text-blue-700' :
                      returnOrder.status === 'received' ? 'bg-purple-100 text-purple-700' :
                      returnOrder.status === 'rejected' ? 'bg-red-100 text-red-700' :
                      'bg-yellow-100 text-yellow-700'
                    }`}>
                      {returnOrder.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {returnOrder.requestedAt?.toDate ? new Date(returnOrder.requestedAt.toDate()).toLocaleDateString() : 'N/A'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    {returnOrder.status === 'requested' && (
                      <div className="flex gap-2 justify-end">
                        <button
                          onClick={() => handleUpdateStatus(returnOrder.id!, 'approved')}
                          className="text-green-600 hover:text-green-900"
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => handleUpdateStatus(returnOrder.id!, 'rejected')}
                          className="text-red-600 hover:text-red-900"
                        >
                          Reject
                        </button>
                      </div>
                    )}
                    {returnOrder.status === 'approved' && (
                      <button
                        onClick={() => handleUpdateStatus(returnOrder.id!, 'received')}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        Mark Received
                      </button>
                    )}
                    {returnOrder.status === 'received' && (
                      <button
                        onClick={() => handleUpdateStatus(returnOrder.id!, 'processed')}
                        className="text-purple-600 hover:text-purple-900"
                      >
                        Process
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ReturnsPage;

