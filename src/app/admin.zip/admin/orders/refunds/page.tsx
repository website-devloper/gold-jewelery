'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { getOrderRefunds, updateOrderRefund } from '@/lib/firestore/order_management_db';
import { OrderRefund } from '@/lib/firestore/order_management';
import { Timestamp } from 'firebase/firestore';
import { useAuth } from '../../../../context/AuthContext';

const RefundsPage = () => {
  const { user } = useAuth();
  const [refunds, setRefunds] = useState<OrderRefund[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<OrderRefund['status'] | 'all'>('all');

  useEffect(() => {
    fetchRefunds();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  const fetchRefunds = async () => {
    try {
      const data = await getOrderRefunds();
      setRefunds(filter === 'all' ? data : data.filter(r => r.status === filter));
    } catch (error) {
      console.error('Failed to fetch refunds:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (refundId: string, status: OrderRefund['status']) => {
    if (!user) return;

    try {
      const updates: Partial<Pick<OrderRefund, 'status' | 'processedBy' | 'processedAt' | 'completedAt' | 'transactionId'>> = { status };
      
      if (status === 'processing') {
        updates.processedBy = user.uid;
        updates.processedAt = Timestamp.now();
      } else if (status === 'completed') {
        updates.completedAt = Timestamp.now();
      }

      await updateOrderRefund(refundId, updates);
      fetchRefunds();
    } catch (error) {
      console.error('Failed to update refund:', error);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Order Refunds</h1>
          <p className="text-gray-500 mt-1">Process and manage refunds</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === 'all' ? 'bg-black text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter('pending')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === 'pending' ? 'bg-black text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Pending
          </button>
          <button
            onClick={() => setFilter('processing')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === 'processing' ? 'bg-black text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Processing
          </button>
          <button
            onClick={() => setFilter('completed')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === 'completed' ? 'bg-black text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Completed
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Refund #</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Order ID</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Amount</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Method</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Reason</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Created</th>
                <th className="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {refunds.map((refund) => (
                <tr key={refund.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">{refund.refundNumber}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <Link href={`/admin/orders/${refund.orderId}`} className="text-blue-600 hover:text-blue-900">
                      {refund.orderId.slice(0, 8)}
                    </Link>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">PKR {refund.amount.toLocaleString()}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 capitalize">{refund.method.replace('_', ' ')}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{refund.reason}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-bold rounded-full ${
                      refund.status === 'completed' ? 'bg-green-100 text-green-700' :
                      refund.status === 'processing' ? 'bg-blue-100 text-blue-700' :
                      refund.status === 'failed' ? 'bg-red-100 text-red-700' :
                      'bg-yellow-100 text-yellow-700'
                    }`}>
                      {refund.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {refund.createdAt?.toDate ? new Date(refund.createdAt.toDate()).toLocaleDateString() : 'N/A'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    {refund.status === 'pending' && (
                      <button
                        onClick={() => handleUpdateStatus(refund.id!, 'processing')}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        Start Processing
                      </button>
                    )}
                    {refund.status === 'processing' && (
                      <button
                        onClick={() => handleUpdateStatus(refund.id!, 'completed')}
                        className="text-green-600 hover:text-green-900"
                      >
                        Complete
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default RefundsPage;

