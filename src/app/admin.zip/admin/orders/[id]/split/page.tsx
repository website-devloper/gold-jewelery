'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { getOrder } from '@/lib/firestore/orders_db';
import { Order } from '@/lib/firestore/orders';
import { createOrderShipment, addOrderHistoryLog } from '@/lib/firestore/order_management_db';
import { useAuth } from '../../../../../context/AuthContext';

const OrderSplitPage = () => {
  const params = useParams();
  const router = useRouter();
  const { user } = useAuth();
  const orderId = params.id as string;
  
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [shipments, setShipments] = useState<{ [key: number]: { quantity: number; items: number[] } }>({});

  useEffect(() => {
    fetchOrder();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orderId]);

  const fetchOrder = async () => {
    try {
      const orderData = await getOrder(orderId);
      setOrder(orderData);
      
      // Initialize shipments - each item can be split
      const initialShipments: { [key: number]: { quantity: number; items: number[] } } = {};
      if (orderData) {
        orderData.items.forEach((_, idx) => {
          initialShipments[idx] = { quantity: orderData.items[idx].quantity, items: [idx] };
        });
      }
      setShipments(initialShipments);
    } catch (error) {
      console.error('Failed to fetch order:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateShipments = async () => {
    if (!order || !user) return;

    try {
      const shipmentGroups: { [key: string]: { items: Array<{ itemId: string; productId: string; productName: string; quantity: number }> } } = {};
      
      // Group items by shipment
      Object.entries(shipments).forEach(([itemIdx, shipment]) => {
        const shipmentKey = shipment.items.join(',');
        if (!shipmentGroups[shipmentKey]) {
          shipmentGroups[shipmentKey] = { items: [] };
        }
        shipmentGroups[shipmentKey].items.push({
          itemId: itemIdx,
          productId: order.items[parseInt(itemIdx)].productId,
          productName: order.items[parseInt(itemIdx)].productName,
          quantity: shipment.quantity,
        });
      });

      // Create shipments
      for (const [, group] of Object.entries(shipmentGroups)) {
        if (group.items.length > 0) {
          await createOrderShipment({
            orderId: order.id!,
            items: group.items,
          });
        }
      }

      await addOrderHistoryLog({
        orderId: order.id!,
        action: 'order_split',
        description: `Order split into ${Object.keys(shipmentGroups).length} shipments`,
        performedBy: user.uid,
        performedByName: user.displayName || user.email || 'Admin',
      });

      alert(`Order split into ${Object.keys(shipmentGroups).length} shipments successfully!`);
      router.push(`/admin/orders/${orderId}`);
    } catch (error) {
      console.error('Failed to split order:', error);
      alert('Failed to split order');
    }
  };

  const handleItemShipmentChange = (itemIdx: number, shipmentKey: string) => {
    const newShipments = { ...shipments };
    const currentShipment = newShipments[itemIdx];
    
    // Remove from current shipment
    currentShipment.items.forEach(idx => {
      if (newShipments[idx]) {
        newShipments[idx] = {
          ...newShipments[idx],
          items: newShipments[idx].items.filter(i => i !== itemIdx),
        };
      }
    });

    // Add to new shipment
    const targetShipmentItems = shipmentKey.split(',').map(i => parseInt(i));
    targetShipmentItems.forEach(idx => {
      if (!newShipments[idx].items.includes(itemIdx)) {
        newShipments[idx].items.push(itemIdx);
      }
    });

    newShipments[itemIdx] = {
      ...currentShipment,
      items: targetShipmentItems,
    };

    setShipments(newShipments);
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }

  if (!order) {
    return <div className="text-center py-12">Order not found</div>;
  }

  // Get unique shipment groups
  const shipmentGroups = Array.from(new Set(
    Object.values(shipments).map(s => s.items.sort().join(','))
  ));

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <button onClick={() => router.back()} className="text-blue-600 hover:text-blue-900 mb-2">← Back to Orders</button>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Split Order</h1>
          <p className="text-gray-500 mt-1">Order #{order.id?.slice(0, 8)} - Split into multiple shipments</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <div className="space-y-4">
          {order.items.map((item, idx) => (
            <div key={idx} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex-1">
                  <div className="font-medium text-gray-900">{item.productName}</div>
                  <div className="text-sm text-gray-500">Quantity: {item.quantity}</div>
                </div>
                <div className="flex items-center gap-2">
                  <label className="text-sm font-medium text-gray-700">Shipment Group:</label>
                  <select
                    value={shipments[idx]?.items.sort().join(',') || ''}
                    onChange={(e) => handleItemShipmentChange(idx, e.target.value)}
                    className="px-3 py-1 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  >
                    {shipmentGroups.map((group, gIdx) => (
                      <option key={gIdx} value={group}>
                        Shipment {gIdx + 1} {group.split(',').map(i => `Item ${parseInt(i) + 1}`).join(', ')}
                      </option>
                    ))}
                    <option value={idx.toString()}>New Shipment</option>
                  </select>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-6 flex gap-3">
          <button
            onClick={handleCreateShipments}
            className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 transition-colors"
          >
            Create {shipmentGroups.length} Shipment(s)
          </button>
          <button
            onClick={() => router.back()}
            className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default OrderSplitPage;

