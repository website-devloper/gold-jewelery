'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { getOrder } from '@/lib/firestore/orders_db';
import { Order } from '@/lib/firestore/orders';
import { addOrderNote, getOrderNotes } from '@/lib/firestore/order_management_db';
import { OrderNote } from '@/lib/firestore/order_management';
import { useAuth } from '../../../../../context/AuthContext';

const OrderNotesPage = () => {
  const params = useParams();
  const router = useRouter();
  const { user } = useAuth();
  const orderId = params.id as string;
  
  const [order, setOrder] = useState<Order | null>(null);
  const [notes, setNotes] = useState<OrderNote[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [noteText, setNoteText] = useState('');
  const [isInternal, setIsInternal] = useState(true);
  const [filter, setFilter] = useState<'all' | 'internal' | 'external'>('all');

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orderId, filter]);

  const fetchData = async () => {
    try {
      const [orderData, notesData] = await Promise.all([
        getOrder(orderId),
        getOrderNotes(orderId, filter === 'internal' ? true : filter === 'external' ? false : undefined),
      ]);
      setOrder(orderData);
      setNotes(notesData);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !noteText.trim()) return;

    try {
      await addOrderNote({
        orderId: order!.id!,
        note: noteText,
        isInternal,
        createdBy: user.uid,
        createdByName: user.displayName || user.email || 'Admin',
      });

      setNoteText('');
      setShowForm(false);
      fetchData();
    } catch (error) {
      console.error('Failed to add note:', error);
      alert('Failed to add note');
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }

  if (!order) {
    return <div className="text-center py-12">Order not found</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <button onClick={() => router.back()} className="text-blue-600 hover:text-blue-900 mb-2">← Back to Orders</button>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Order Notes</h1>
          <p className="text-gray-500 mt-1">Order #{order.id?.slice(0, 8)}</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === 'all' ? 'bg-black text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter('internal')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === 'internal' ? 'bg-black text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Internal
          </button>
          <button
            onClick={() => setFilter('external')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === 'external' ? 'bg-black text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Customer
          </button>
          <button
            onClick={() => setShowForm(true)}
            className="bg-black text-white px-6 py-2 rounded-full text-sm font-bold uppercase tracking-widest hover:bg-gray-800 transition-colors"
          >
            + Add Note
          </button>
        </div>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-bold mb-4">Add Note</h2>
          <form onSubmit={handleAddNote} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Note</label>
              <textarea
                value={noteText}
                onChange={(e) => setNoteText(e.target.value)}
                rows={4}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                required
                placeholder="Enter note..."
              />
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="isInternal"
                checked={isInternal}
                onChange={(e) => setIsInternal(e.target.checked)}
                className="w-4 h-4 text-black border-gray-300 rounded focus:ring-black"
              />
              <label htmlFor="isInternal" className="text-sm font-medium text-gray-700">
                Internal note (not visible to customer)
              </label>
            </div>
            <div className="flex gap-3">
              <button
                type="submit"
                className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 transition-colors"
              >
                Add Note
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setNoteText('');
                }}
                className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="divide-y divide-gray-100">
          {notes.length === 0 ? (
            <div className="p-8 text-center text-gray-500">No notes found</div>
          ) : (
            notes.map((note) => (
              <div key={note.id} className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className="font-medium text-gray-900">{note.createdByName || 'System'}</div>
                    <div className="text-sm text-gray-500">
                      {note.createdAt?.toDate ? new Date(note.createdAt.toDate()).toLocaleString() : 'N/A'}
                    </div>
                  </div>
                  <span className={`px-2 py-1 text-xs font-bold rounded-full ${
                    note.isInternal ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'
                  }`}>
                    {note.isInternal ? 'Internal' : 'Customer'}
                  </span>
                </div>
                <div className="text-gray-700 mt-2">{note.note}</div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default OrderNotesPage;

