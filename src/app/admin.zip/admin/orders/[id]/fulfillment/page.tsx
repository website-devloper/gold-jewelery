'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { getOrder } from '@/lib/firestore/orders_db';
import { Order, OrderItem } from '@/lib/firestore/orders';
import { createOrderFulfillment, getOrderFulfillments, updateOrderFulfillment, addOrderHistoryLog } from '@/lib/firestore/order_management_db';
import { OrderFulfillment } from '@/lib/firestore/order_management';
import { Timestamp } from 'firebase/firestore';
import { getAllWarehouses } from '@/lib/firestore/warehouses_db';
import { Warehouse } from '@/lib/firestore/warehouses';
import { useAuth } from '../../../../../context/AuthContext';

const OrderFulfillmentPage = () => {
  const params = useParams();
  const router = useRouter();
  const { user } = useAuth();
  const orderId = params.id as string;
  
  const [order, setOrder] = useState<Order | null>(null);
  const [fulfillments, setFulfillments] = useState<OrderFulfillment[]>([]);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [selectedItems, setSelectedItems] = useState<{ [key: number]: number }>({});

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orderId]);

  const fetchData = async () => {
    try {
      const [orderData, fulfillmentsData, warehousesData] = await Promise.all([
        getOrder(orderId),
        getOrderFulfillments(orderId),
        getAllWarehouses(true),
      ]);
      setOrder(orderData);
      setFulfillments(fulfillmentsData);
      setWarehouses(warehousesData);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateFulfillment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!order || !user) return;

    const formData = new FormData(e.target as HTMLFormElement);
    const warehouseId = formData.get('warehouseId') as string;

    const items = order.items
      .map((item: OrderItem, idx: number) => ({
        itemId: idx.toString(),
        productId: item.productId,
        productName: item.productName,
        quantity: item.quantity,
        fulfilledQuantity: selectedItems[idx] || item.quantity,
      }))
      .filter((_, idx: number) => selectedItems[idx] !== undefined && selectedItems[idx] > 0);

    if (items.length === 0) {
      alert('Please select at least one item to fulfill');
      return;
    }

    try {
      const warehouse = warehouses.find(w => w.id === warehouseId);
      await createOrderFulfillment({
        orderId: order.id!,
        items,
        warehouseId,
        warehouseName: warehouse?.name || '',
      });

      await addOrderHistoryLog({
        orderId: order.id!,
        action: 'fulfillment_created',
        description: `Fulfillment created for ${items.length} items`,
        performedBy: user.uid,
        performedByName: user.displayName || user.email || 'Admin',
      });

      setShowForm(false);
      setSelectedItems({});
      fetchData();
    } catch (error) {
      console.error('Failed to create fulfillment:', error);
      alert('Failed to create fulfillment');
    }
  };

  const handleUpdateStatus = async (fulfillmentId: string, status: OrderFulfillment['status']) => {
    if (!user) return;

    try {
      const updates: Partial<Omit<OrderFulfillment, 'id' | 'orderId' | 'fulfillmentNumber' | 'items' | 'createdAt' | 'updatedAt'>> = { status };
      
      if (status === 'picked') {
        updates.pickedBy = user.uid;
        updates.pickedByName = user.displayName || user.email || 'Admin';
        updates.pickedAt = Timestamp.now();
      } else if (status === 'packed') {
        updates.packedBy = user.uid;
        updates.packedByName = user.displayName || user.email || 'Admin';
        updates.packedAt = Timestamp.now();
      } else if (status === 'shipped') {
        updates.shippedBy = user.uid;
        updates.shippedByName = user.displayName || user.email || 'Admin';
        updates.shippedAt = Timestamp.now();
      }

      await updateOrderFulfillment(fulfillmentId, updates);

      await addOrderHistoryLog({
        orderId: order!.id!,
        action: 'fulfillment_status_changed',
        description: `Fulfillment status changed to ${status}`,
        previousValue: fulfillments.find(f => f.id === fulfillmentId)?.status,
        newValue: status,
        performedBy: user.uid,
        performedByName: user.displayName || user.email || 'Admin',
      });

      fetchData();
    } catch (error) {
      console.error('Failed to update fulfillment:', error);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }

  if (!order) {
    return <div className="text-center py-12">Order not found</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <button onClick={() => router.back()} className="text-blue-600 hover:text-blue-900 mb-2">← Back to Orders</button>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Order Fulfillment</h1>
          <p className="text-gray-500 mt-1">Order #{order.id?.slice(0, 8)}</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="bg-black text-white px-6 py-2 rounded-full text-sm font-bold uppercase tracking-widest hover:bg-gray-800 transition-colors"
        >
          + New Fulfillment
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-bold mb-4">Create Fulfillment</h2>
          <form onSubmit={handleCreateFulfillment} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Warehouse</label>
              <select
                name="warehouseId"
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
              >
                <option value="">Select warehouse</option>
                {warehouses.map(warehouse => (
                  <option key={warehouse.id} value={warehouse.id}>{warehouse.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Select Items to Fulfill</label>
              <div className="space-y-2">
                {order.items.map((item: OrderItem, idx: number) => {
                  const fulfilledQty = fulfillments.reduce((sum, f) => {
                    const fulfillmentItem = f.items.find((i: { itemId: string; fulfilledQuantity: number }) => i.itemId === idx.toString());
                    return sum + (fulfillmentItem?.fulfilledQuantity || 0);
                  }, 0);
                  const remainingQty = item.quantity - fulfilledQty;
                  
                  return (
                    <div key={idx} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                      <div className="flex-1">
                        <div className="font-medium">{item.productName}</div>
                        <div className="text-sm text-gray-500">Ordered: {item.quantity} | Fulfilled: {fulfilledQty} | Remaining: {remainingQty}</div>
                      </div>
                      {remainingQty > 0 && (
                        <input
                          type="number"
                          min="1"
                          max={remainingQty}
                          value={selectedItems[idx] || ''}
                          onChange={(e) => setSelectedItems({ ...selectedItems, [idx]: parseInt(e.target.value) || 0 })}
                          className="w-20 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                          placeholder="Qty"
                        />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="flex gap-3">
              <button
                type="submit"
                className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 transition-colors"
              >
                Create Fulfillment
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setSelectedItems({});
                }}
                className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Fulfillment #</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Items</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Warehouse</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {fulfillments.map((fulfillment) => (
                <tr key={fulfillment.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">{fulfillment.fulfillmentNumber}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{fulfillment.items.length} items</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{fulfillment.warehouseName || 'N/A'}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-bold rounded-full ${
                      fulfillment.status === 'delivered' ? 'bg-green-100 text-green-700' :
                      fulfillment.status === 'shipped' ? 'bg-blue-100 text-blue-700' :
                      fulfillment.status === 'packed' ? 'bg-purple-100 text-purple-700' :
                      fulfillment.status === 'picked' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {fulfillment.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex gap-2">
                      {fulfillment.status === 'pending' && (
                        <button
                          onClick={() => handleUpdateStatus(fulfillment.id!, 'processing')}
                          className="text-blue-600 hover:text-blue-900"
                        >
                          Start Processing
                        </button>
                      )}
                      {fulfillment.status === 'processing' && (
                        <button
                          onClick={() => handleUpdateStatus(fulfillment.id!, 'picked')}
                          className="text-yellow-600 hover:text-yellow-900"
                        >
                          Mark Picked
                        </button>
                      )}
                      {fulfillment.status === 'picked' && (
                        <button
                          onClick={() => handleUpdateStatus(fulfillment.id!, 'packed')}
                          className="text-purple-600 hover:text-purple-900"
                        >
                          Mark Packed
                        </button>
                      )}
                      {fulfillment.status === 'packed' && (
                        <button
                          onClick={() => handleUpdateStatus(fulfillment.id!, 'shipped')}
                          className="text-blue-600 hover:text-blue-900"
                        >
                          Mark Shipped
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default OrderFulfillmentPage;

