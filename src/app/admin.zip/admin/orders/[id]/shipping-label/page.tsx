'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { getOrder } from '@/lib/firestore/orders_db';
import { Order } from '@/lib/firestore/orders';
import { getOrderShipments } from '@/lib/firestore/order_management_db';
import { OrderShipment } from '@/lib/firestore/order_management';
import { getFunctions, httpsCallable } from 'firebase/functions';
import { app } from '@/lib/firebase';

const ShippingLabelPage = () => {
  const params = useParams();
  const router = useRouter();
  const orderId = params.id as string;
  
  const [order, setOrder] = useState<Order | null>(null);
  const [shipments, setShipments] = useState<OrderShipment[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState<string | null>(null);

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orderId]);

  const fetchData = async () => {
    try {
      const [orderData, shipmentsData] = await Promise.all([
        getOrder(orderId),
        getOrderShipments(orderId),
      ]);
      setOrder(orderData);
      setShipments(shipmentsData);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateLabel = async (shipmentId: string, format: 'pdf' | 'png' | 'html') => {
    setGenerating(shipmentId);
    try {
      const functions = getFunctions(app);
      const generateLabel = httpsCallable(functions, 'generateShippingLabel');
      
      const result = await generateLabel({ shipmentId, format });
      const data = result.data as { success: boolean; label?: string; url?: string; error?: string };

      if (data.success && data.label) {
        if (format === 'html') {
          // Open in new window for HTML
          const newWindow = window.open();
          if (newWindow) {
            newWindow.document.write(data.label);
            newWindow.document.close();
          }
        } else {
          // For PDF/PNG, open in new window and allow print to PDF
          const newWindow = window.open();
          if (newWindow) {
            newWindow.document.write(data.label);
            newWindow.document.close();
            // User can print to PDF from browser
            setTimeout(() => {
              newWindow.print();
            }, 500);
          }
        }
      }
    } catch (error) {
      console.error('Failed to generate label:', error);
      alert('Failed to generate shipping label');
    } finally {
      setGenerating(null);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }

  if (!order) {
    return <div className="text-center py-12">Order not found</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <button onClick={() => router.back()} className="text-blue-600 hover:text-blue-900 mb-2">← Back to Orders</button>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Shipping Labels</h1>
          <p className="text-gray-500 mt-1">Order #{order.id?.slice(0, 8)}</p>
        </div>
      </div>

      {shipments.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 text-center">
          <p className="text-gray-500">No shipments found for this order. Create a shipment first.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {shipments.map((shipment) => (
            <div key={shipment.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-bold text-gray-900">{shipment.shipmentNumber}</h3>
                  <p className="text-sm text-gray-500">{shipment.items.length} items</p>
                  {shipment.trackingNumber && (
                    <p className="text-sm text-gray-500 mt-1">Tracking: {shipment.trackingNumber}</p>
                  )}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleGenerateLabel(shipment.id!, 'html')}
                    disabled={generating === shipment.id}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 text-sm"
                  >
                    {generating === shipment.id ? 'Generating...' : 'View HTML'}
                  </button>
                  <button
                    onClick={() => handleGenerateLabel(shipment.id!, 'pdf')}
                    disabled={generating === shipment.id}
                    className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50 text-sm"
                  >
                    {generating === shipment.id ? 'Generating...' : 'Download PDF'}
                  </button>
                  <button
                    onClick={() => handleGenerateLabel(shipment.id!, 'png')}
                    disabled={generating === shipment.id}
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 text-sm"
                  >
                    {generating === shipment.id ? 'Generating...' : 'Download PNG'}
                  </button>
                </div>
              </div>
              <div className="border-t border-gray-100 pt-4">
                <div className="text-sm text-gray-600">
                  <strong>Items:</strong>
                  <ul className="mt-2 space-y-1">
                    {shipment.items.map((item, idx) => (
                      <li key={idx}>• {item.productName} x {item.quantity}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ShippingLabelPage;

