'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { getOrder } from '@/lib/firestore/orders_db';
import { Order } from '@/lib/firestore/orders';
import { getOrderHistory } from '@/lib/firestore/order_management_db';
import { OrderHistoryLog } from '@/lib/firestore/order_management';

const OrderHistoryPage = () => {
  const params = useParams();
  const router = useRouter();
  const orderId = params.id as string;
  
  const [order, setOrder] = useState<Order | null>(null);
  const [history, setHistory] = useState<OrderHistoryLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orderId]);

  const fetchData = async () => {
    try {
      const [orderData, historyData] = await Promise.all([
        getOrder(orderId),
        getOrderHistory(orderId),
      ]);
      setOrder(orderData);
      setHistory(historyData);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }

  if (!order) {
    return <div className="text-center py-12">Order not found</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <button onClick={() => router.back()} className="text-blue-600 hover:text-blue-900 mb-2">← Back to Orders</button>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Order History</h1>
          <p className="text-gray-500 mt-1">Complete activity log for Order #{order.id?.slice(0, 8)}</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="divide-y divide-gray-100">
          {history.length === 0 ? (
            <div className="p-8 text-center text-gray-500">No history found</div>
          ) : (
            history.map((log) => (
              <div key={log.id} className="p-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className={`px-2 py-1 text-xs font-bold rounded-full ${
                        log.action.includes('status_change') ? 'bg-blue-100 text-blue-700' :
                        log.action.includes('fulfillment') ? 'bg-purple-100 text-purple-700' :
                        log.action.includes('shipment') ? 'bg-green-100 text-green-700' :
                        log.action.includes('note') ? 'bg-yellow-100 text-yellow-700' :
                        'bg-gray-100 text-gray-700'
                      }`}>
                        {log.action.replace(/_/g, ' ')}
                      </span>
                      <span className="text-sm text-gray-500">
                        {log.createdAt?.toDate ? new Date(log.createdAt.toDate()).toLocaleString() : 'N/A'}
                      </span>
                    </div>
                    <div className="text-gray-900 font-medium mb-1">{log.description}</div>
                    {log.performedByName && (
                      <div className="text-sm text-gray-500">By: {log.performedByName}</div>
                    )}
                    {log.previousValue !== undefined && log.newValue !== undefined && (
                      <div className="mt-2 text-sm text-gray-600">
                        <span className="line-through text-red-600">{String(log.previousValue)}</span>
                        {' → '}
                        <span className="text-green-600 font-medium">{String(log.newValue)}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default OrderHistoryPage;

