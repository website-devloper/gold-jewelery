'use client';

import React, { useEffect, useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Order } from '@/lib/firestore/orders';
import { getAllOrders, updateOrder } from '@/lib/firestore/orders_db';
import { updateTrackingNumber, getOrderTracking } from '@/lib/firestore/shipping_db';
import { getAllShippingCarriers } from '@/lib/firestore/shipping_db';
import { ShippingCarrier } from '@/lib/firestore/shipping';

const OrderList = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  
  // Modal State
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [carriers, setCarriers] = useState<ShippingCarrier[]>([]);
  const [trackingNumber, setTrackingNumber] = useState('');
  const [selectedCarrierId, setSelectedCarrierId] = useState('');
  const [updatingTracking, setUpdatingTracking] = useState(false);

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const handleExportOrders = async () => {
    try {
      // Convert orders to CSV
      const csvHeaders = ['Order ID', 'Customer Name', 'Email', 'Phone', 'Date', 'Items', 'Total', 'Status', 'Payment Method', 'Tracking Number'];
      const csvRows = orders.map(order => [
        order.id?.slice(0, 8) || '',
        order.shippingAddress?.fullName || '',
        order.shippingAddress?.email || '',
        order.shippingAddress?.phone || '',
        order.createdAt?.toDate ? new Date(order.createdAt.toDate()).toLocaleDateString() : '',
        order.items.map(i => `${i.productName} x${i.quantity}`).join('; '),
        order.totalAmount.toString(),
        order.status,
        order.paymentMethod,
        order.trackingNumber || '',
      ]);

      const csvContent = [
        csvHeaders.join(','),
        ...csvRows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      ].join('\n');

      // Download CSV
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `orders_export_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error('Failed to export orders:', error);
      alert('Failed to export orders');
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [fetchedOrders, fetchedCarriers] = await Promise.all([
          getAllOrders(),
          getAllShippingCarriers(true),
        ]);
        setOrders(fetchedOrders);
        setCarriers(fetchedCarriers);
      } catch (err) {
        setError('Failed to fetch orders.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    const loadTrackingInfo = async () => {
      if (selectedOrder?.id) {
        try {
          const tracking = await getOrderTracking(selectedOrder.id);
          if (tracking) {
            setTrackingNumber(tracking.trackingNumber || '');
            setSelectedCarrierId(tracking.carrierId || '');
          } else {
            setTrackingNumber(selectedOrder.trackingNumber || '');
            setSelectedCarrierId(selectedOrder.carrierId || '');
          }
        } catch (err) {
          console.error('Failed to load tracking info:', err);
          setTrackingNumber(selectedOrder.trackingNumber || '');
          setSelectedCarrierId(selectedOrder.carrierId || '');
        }
      }
    };
    loadTrackingInfo();
  }, [selectedOrder]);

  const handleStatusChange = async (orderId: string, newStatus: Order['status']) => {
    try {
      await updateOrder(orderId, { status: newStatus });
      setOrders(prevOrders =>
        prevOrders.map(order =>
          order.id === orderId ? { ...order, status: newStatus } : order
        )
      );
      if (selectedOrder && selectedOrder.id === orderId) {
        setSelectedOrder({ ...selectedOrder, status: newStatus });
      }
    } catch (err) {
      setError('Failed to update order status.');
      console.error(err);
    }
  };

  const handleViewDetails = (order: Order) => {
    setSelectedOrder(order);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedOrder(null);
    setTrackingNumber('');
    setSelectedCarrierId('');
  };

  const handleUpdateTracking = async () => {
    if (!selectedOrder?.id) return;
    
    if (!trackingNumber.trim()) {
      alert('Please enter a tracking number');
      return;
    }

    setUpdatingTracking(true);
    try {
      const carrier = carriers.find(c => c.id === selectedCarrierId);
      await updateTrackingNumber(
        selectedOrder.id,
        trackingNumber.trim(),
        carrier?.id,
        carrier?.name,
        carrier?.code
      );
      
      // Update order with tracking info
      await updateOrder(selectedOrder.id, {
        trackingNumber: trackingNumber.trim(),
        carrierId: carrier?.id,
        carrierName: carrier?.name,
        status: 'shipped' as Order['status'],
      });
      
      // Update local state
      setOrders(prevOrders =>
        prevOrders.map(order =>
          order.id === selectedOrder.id
            ? {
                ...order,
                trackingNumber: trackingNumber.trim(),
                carrierId: carrier?.id,
                carrierName: carrier?.name,
                status: 'shipped' as Order['status'],
              }
            : order
        )
      );
      
      if (selectedOrder) {
        setSelectedOrder({
          ...selectedOrder,
          trackingNumber: trackingNumber.trim(),
          carrierId: carrier?.id,
          carrierName: carrier?.name,
          status: 'shipped' as Order['status'],
        });
      }
      
      alert('Tracking number updated successfully!');
    } catch (err) {
      console.error('Failed to update tracking:', err);
      alert('Failed to update tracking number.');
    } finally {
      setUpdatingTracking(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Orders</h1>
          <p className="text-gray-500 text-sm mt-1">Manage and track customer orders.</p>
        </div>
      </div>

      {error && <div className="text-red-600 bg-red-50 border border-red-100 p-4 rounded-lg mb-6 text-sm">{error}</div>}

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        {orders.length === 0 ? (
          <div className="p-12 text-center text-gray-500">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 mx-auto mb-4 text-gray-300">
              <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 0 0-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 0 0-16.536-1.84M7.5 14.25 5.106 5.272M6 20.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Zm12.75 0a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Z" />
            </svg>
            <p>No orders found yet.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-100">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Order ID</th>
                  <th scope="col" className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Customer</th>
                  <th scope="col" className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Date</th>
                  <th scope="col" className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Total</th>
                  <th scope="col" className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Payment</th>
                  <th scope="col" className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                  <th scope="col" className="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-100">
                {orders.map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-gray-500">#{order.id?.slice(0, 8)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {order.shippingAddress?.fullName || 'Guest User'}
                      <div className="text-xs text-gray-500 font-normal">{order.shippingAddress?.phone}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{order.createdAt.toDate().toLocaleDateString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">PKR {order.totalAmount.toLocaleString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize ${
                        order.paymentMethod === 'stripe' ? 'bg-purple-100 text-purple-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {order.paymentMethod === 'cod' ? 'Cash on Delivery' : order.paymentMethod}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <select
                        value={order.status}
                        onChange={(e) => handleStatusChange(order.id!, e.target.value as Order['status'])}
                        className={`block w-full py-1.5 px-3 border-0 rounded-lg text-xs font-bold uppercase tracking-wide cursor-pointer focus:ring-2 focus:ring-black/10 transition-all
                          ${order.status === 'delivered' ? 'bg-green-100 text-green-700' : 
                            order.status === 'pending' ? 'bg-yellow-100 text-yellow-700' : 
                            order.status === 'processing' ? 'bg-blue-100 text-blue-700' :
                            order.status === 'shipped' ? 'bg-indigo-100 text-indigo-700' :
                            'bg-red-100 text-red-700'}
                        `}
                      >
                        <option value="pending">Pending</option>
                        <option value="processing">Processing</option>
                        <option value="shipped">Shipped</option>
                        <option value="delivered">Delivered</option>
                        <option value="cancelled">Cancelled</option>
                      </select>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex items-center justify-end gap-2">
                        <Link
                          href={`/admin/orders/${order.id}/fulfillment`}
                          className="text-blue-600 hover:text-blue-900"
                          title="Fulfillment"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5M10 11.25h4M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z" />
                          </svg>
                        </Link>
                        <Link
                          href={`/admin/orders/${order.id}/notes`}
                          className="text-yellow-600 hover:text-yellow-900"
                          title="Notes"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" />
                          </svg>
                        </Link>
                        <Link
                          href={`/admin/orders/${order.id}/history`}
                          className="text-purple-600 hover:text-purple-900"
                          title="History"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </Link>
                        <Link
                          href={`/admin/orders/${order.id}/split`}
                          className="text-indigo-600 hover:text-indigo-900"
                          title="Split Order"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                          </svg>
                        </Link>
                        <Link
                          href={`/admin/orders/${order.id}/shipping-label`}
                          className="text-teal-600 hover:text-teal-900"
                          title="Shipping Label"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                          </svg>
                        </Link>
                        <button 
                          onClick={() => handleViewDetails(order)}
                          className="text-gray-400 hover:text-black transition-colors"
                          title="View Details"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 0 1 0-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178Z" />
                            <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                          </svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Order Details Modal */}
      {isModalOpen && selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center sticky top-0 bg-white z-10">
              <div>
                <h2 className="text-xl font-bold text-gray-900">Order Details</h2>
                <p className="text-sm text-gray-500 font-mono mt-1">#{selectedOrder.id}</p>
              </div>
              <button onClick={closeModal} className="text-gray-400 hover:text-gray-600 p-2 rounded-full hover:bg-gray-100 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="p-6 space-y-8">
              {/* Status Bar */}
              <div className="flex items-center justify-between bg-gray-50 p-4 rounded-xl">
                <div>
                  <p className="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">Current Status</p>
                  <select
                    value={selectedOrder.status}
                    onChange={(e) => handleStatusChange(selectedOrder.id!, e.target.value as Order['status'])}
                    className="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-black focus:border-black block w-full p-2.5"
                  >
                    <option value="pending">Pending</option>
                    <option value="processing">Processing</option>
                    <option value="shipped">Shipped</option>
                    <option value="delivered">Delivered</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
                <div className="text-right">
                  <p className="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">Order Date</p>
                  <p className="text-sm font-medium text-gray-900">{selectedOrder.createdAt.toDate().toLocaleString()}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Customer Info */}
                <div>
                  <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-4 border-b pb-2">Customer Information</h3>
                  <div className="space-y-3 text-sm text-gray-600">
                    <p><span className="font-medium text-gray-900 w-24 inline-block">Name:</span> {selectedOrder.shippingAddress?.fullName}</p>
                    <p><span className="font-medium text-gray-900 w-24 inline-block">Email:</span> {selectedOrder.shippingAddress?.email}</p>
                    <p><span className="font-medium text-gray-900 w-24 inline-block">Phone:</span> {selectedOrder.shippingAddress?.phone}</p>
                  </div>
                </div>

                {/* Shipping Info */}
                <div>
                  <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-4 border-b pb-2">Shipping Address</h3>
                  <div className="space-y-1 text-sm text-gray-600">
                    <p>{selectedOrder.shippingAddress?.address}</p>
                    <p>{selectedOrder.shippingAddress?.city}, {selectedOrder.shippingAddress?.state} {selectedOrder.shippingAddress?.zipCode}</p>
                  </div>
                </div>
              </div>

              {/* Order Items */}
              <div>
                <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-4 border-b pb-2">Order Items</h3>
                <div className="space-y-4">
                  {selectedOrder.items.map((item, index) => (
                    <div key={index} className="flex items-center gap-4 bg-white border border-gray-100 p-3 rounded-lg">
                      <div className="w-16 h-16 bg-gray-100 rounded-md overflow-hidden relative flex-shrink-0">
                        {/* Use actual image if available, fallback for now */}
                        {item.productImage ? (
                           <Image src={item.productImage} alt={item.productName} fill className="object-cover" unoptimized />
                        ) : (
                           <div className="w-full h-full flex items-center justify-center text-gray-400 text-xs">No Img</div>
                        )}
                      </div>
                      <div className="flex-1">
                        <h4 className="text-sm font-bold text-gray-900">{item.productName}</h4>
                        {item.variant && (
                          <p className="text-xs text-gray-500 mt-0.5">
                            <span className="capitalize">{item.variant.name}</span>: {item.variant.value}
                          </p>
                        )}
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-gray-900">PKR {item.price.toLocaleString()}</p>
                        <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tracking Information */}
              <div>
                <h3 className="text-sm font-bold text-gray-900 uppercase tracking-wider mb-4 border-b pb-2">Tracking Information</h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs text-gray-500 uppercase font-bold mb-2">Tracking Number</label>
                      <input
                        type="text"
                        value={trackingNumber}
                        onChange={(e) => setTrackingNumber(e.target.value)}
                        placeholder="Enter tracking number"
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-500 uppercase font-bold mb-2">Carrier</label>
                      <select
                        value={selectedCarrierId}
                        onChange={(e) => setSelectedCarrierId(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
                      >
                        <option value="">Select Carrier</option>
                        {carriers.map(carrier => (
                          <option key={carrier.id} value={carrier.id}>{carrier.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  {selectedOrder.trackingNumber && (
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                      <p className="text-xs text-blue-600 font-medium mb-1">Current Tracking Number</p>
                      <p className="text-sm font-mono text-blue-900">{selectedOrder.trackingNumber}</p>
                      {selectedOrder.carrierName && (
                        <p className="text-xs text-blue-600 mt-1">Carrier: {selectedOrder.carrierName}</p>
                      )}
                    </div>
                  )}
                  <button
                    onClick={handleUpdateTracking}
                    disabled={updatingTracking || !trackingNumber.trim()}
                    className="w-full bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-medium"
                  >
                    {updatingTracking ? 'Updating...' : 'Update Tracking Number'}
                  </button>
                </div>
              </div>

              {/* Order Summary */}
              <div className="bg-gray-50 p-6 rounded-xl space-y-3">
                <div className="flex justify-between text-sm text-gray-600">
                  <span>Subtotal</span>
                  <span>PKR {selectedOrder.items.reduce((sum, item) => sum + (item.price * item.quantity), 0).toLocaleString()}</span>
                </div>
                {selectedOrder.shippingCost && selectedOrder.shippingCost > 0 && (
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>Shipping</span>
                    <span>PKR {selectedOrder.shippingCost.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between text-lg font-bold text-gray-900 pt-3 border-t border-gray-200">
                  <span>Total Amount</span>
                  <span>PKR {selectedOrder.totalAmount.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default OrderList;
