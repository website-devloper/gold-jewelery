'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import ShippingRateForm from '../../../../../components/admin/ShippingRateForm';

const NewShippingRatePage = () => {
  const router = useRouter();

  const handleSuccess = () => {
    router.push('/admin/shipping/rates');
  };

  const handleCancel = () => {
    router.push('/admin/shipping/rates');
  };

  return (
    <div>
      <div className="mb-6">
        <button
          onClick={handleCancel}
          className="text-gray-500 hover:text-gray-700 flex items-center gap-1 text-sm font-medium"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
            <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
          </svg>
          Back to Shipping Rates
        </button>
      </div>
      <ShippingRateForm onSuccess={handleSuccess} onCancel={handleCancel} />
    </div>
  );
};

export default NewShippingRatePage;

