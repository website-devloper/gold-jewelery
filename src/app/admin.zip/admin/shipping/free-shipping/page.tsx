'use client';

import React, { useState, useEffect } from 'react';
import { getAllFreeShippingRules, createFreeShippingRule, updateFreeShippingRule, deleteFreeShippingRule } from '@/lib/firestore/campaigns_db';
import { FreeShippingRule } from '@/lib/firestore/campaigns';
import { getAllShippingZones } from '@/lib/firestore/shipping_db';
import { ShippingZone } from '@/lib/firestore/shipping';
import { useAuth } from '../../../../context/AuthContext';
import { Timestamp } from 'firebase/firestore';

const FreeShippingPage = () => {
  const { user } = useAuth();
  const [rules, setRules] = useState<FreeShippingRule[]>([]);
  const [zones, setZones] = useState<ShippingZone[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingRule, setEditingRule] = useState<FreeShippingRule | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    threshold: 0,
    zoneIds: [] as string[],
    validFrom: '',
    validUntil: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [rulesData, zonesData] = await Promise.all([
        getAllFreeShippingRules(),
        getAllShippingZones(),
      ]);
      setRules(rulesData);
      setZones(zonesData);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      const ruleData: Omit<FreeShippingRule, 'id' | 'createdAt' | 'updatedAt'> = {
        name: formData.name,
        threshold: formData.threshold,
        isActive: editingRule ? editingRule.isActive : true,
        createdBy: editingRule ? editingRule.createdBy : user.uid,
        ...(formData.description && formData.description.trim() !== '' && { description: formData.description }),
        ...(formData.zoneIds.length > 0 && { zoneIds: formData.zoneIds }),
        ...(formData.validFrom && { validFrom: Timestamp.fromDate(new Date(formData.validFrom)) }),
        ...(formData.validUntil && { validUntil: Timestamp.fromDate(new Date(formData.validUntil)) }),
      };

      if (editingRule) {
        await updateFreeShippingRule(editingRule.id!, ruleData);
      } else {
        await createFreeShippingRule(ruleData);
      }

      setShowForm(false);
      setEditingRule(null);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Failed to save rule:', error);
      alert('Failed to save rule');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      threshold: 0,
      zoneIds: [],
      validFrom: '',
      validUntil: '',
    });
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this rule?')) return;
    try {
      await deleteFreeShippingRule(id);
      fetchData();
    } catch (error) {
      console.error('Failed to delete rule:', error);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Free Shipping Rules</h1>
          <p className="text-gray-500 mt-1">Create dynamic free shipping thresholds</p>
        </div>
        <button
          onClick={() => {
            setShowForm(true);
            setEditingRule(null);
            resetForm();
          }}
          className="bg-black text-white px-6 py-2 rounded-full text-sm font-bold uppercase tracking-widest hover:bg-gray-800 transition-colors"
        >
          + New Rule
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-bold mb-4">{editingRule ? 'Edit Rule' : 'New Free Shipping Rule'}</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Rule Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Minimum Order Amount (PKR)</label>
              <input
                type="number"
                value={formData.threshold}
                onChange={(e) => setFormData({ ...formData, threshold: parseFloat(e.target.value) || 0 })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                required
                min="0"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Shipping Zones (Optional - Leave empty for all zones)</label>
              <select
                multiple
                value={formData.zoneIds}
                onChange={(e) => setFormData({ ...formData, zoneIds: Array.from(e.target.selectedOptions, option => option.value) })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent h-32"
              >
                {zones.map(zone => (
                  <option key={zone.id} value={zone.id}>{zone.name}</option>
                ))}
              </select>
              <p className="text-xs text-gray-500 mt-1">Hold Ctrl/Cmd to select multiple zones</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Valid From (Optional)</label>
                <input
                  type="date"
                  value={formData.validFrom}
                  onChange={(e) => setFormData({ ...formData, validFrom: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Valid Until (Optional)</label>
                <input
                  type="date"
                  value={formData.validUntil}
                  onChange={(e) => setFormData({ ...formData, validUntil: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                />
              </div>
            </div>
            <div className="flex gap-3">
              <button
                type="submit"
                className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 transition-colors"
              >
                {editingRule ? 'Update' : 'Create'} Rule
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditingRule(null);
                  resetForm();
                }}
                className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Threshold</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Zones</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Valid Period</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {rules.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center">
                    <div className="text-gray-500">
                      <svg className="mx-auto h-12 w-12 text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
                      </svg>
                      <p className="text-lg font-medium text-gray-900 mb-1">No free shipping rules found</p>
                      <p className="text-sm">Create your first free shipping rule to get started.</p>
                    </div>
                  </td>
                </tr>
              ) : (
                rules.map((rule) => (
                <tr key={rule.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{rule.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">PKR {rule.threshold.toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {rule.zoneIds && rule.zoneIds.length > 0 ? `${rule.zoneIds.length} zones` : 'All zones'}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {rule.validFrom?.toDate ? new Date(rule.validFrom.toDate()).toLocaleDateString() : 'Always'} - {rule.validUntil?.toDate ? new Date(rule.validUntil.toDate()).toLocaleDateString() : 'Always'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-bold rounded-full ${
                      rule.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {rule.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={async () => {
                          try {
                            await updateFreeShippingRule(rule.id!, { isActive: !rule.isActive });
                            fetchData();
                          } catch (error) {
                            console.error('Failed to update rule:', error);
                            alert('Failed to update rule');
                          }
                        }}
                        className="text-gray-600 hover:text-gray-900"
                        title={rule.isActive ? 'Deactivate' : 'Activate'}
                      >
                        {rule.isActive ? '⏸️' : '▶️'}
                      </button>
                      <button
                        onClick={() => {
                          setEditingRule(rule);
                          setFormData({
                            name: rule.name,
                            description: rule.description || '',
                            threshold: rule.threshold,
                            zoneIds: rule.zoneIds || [],
                            validFrom: rule.validFrom?.toDate ? new Date(rule.validFrom.toDate()).toISOString().split('T')[0] : '',
                            validUntil: rule.validUntil?.toDate ? new Date(rule.validUntil.toDate()).toISOString().split('T')[0] : '',
                          });
                          setShowForm(true);
                        }}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(rule.id!)}
                        className="text-red-600 hover:text-red-900"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              )))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default FreeShippingPage;

