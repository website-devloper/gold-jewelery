'use client';

import React, { useState, useEffect } from 'react';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { app } from '@/lib/firebase';
import { getSalesFunnel } from '@/lib/firestore/analytics_db';
import { SalesFunnelStage } from '@/lib/firestore/analytics';
import { useRouter } from 'next/navigation';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { useLanguage } from '@/context/LanguageContext';

const SalesFunnelPage = () => {
  const { t } = useLanguage();
  const [funnel, setFunnel] = useState<SalesFunnelStage[]>([]);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState('30');
  const router = useRouter();
  const auth = getAuth(app);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        await fetchFunnel();
      } else {
        router.push('/login');
      }
    });

    return () => unsubscribe();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auth, router, dateRange]);

  const fetchFunnel = async () => {
    try {
      setLoading(true);
      const end = new Date();
      const start = new Date();
      start.setDate(end.getDate() - parseInt(dateRange));
      start.setHours(0, 0, 0, 0);
      end.setHours(23, 59, 59, 999);

      const funnelData = await getSalesFunnel(start, end);
      setFunnel(funnelData);
    } catch (error) {
      console.error('Error fetching funnel:', error);
    } finally {
      setLoading(false);
    }
  };


  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 max-w-7xl py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-serif font-bold">
          {t('admin.sales_funnel_analysis') || t('admin.sales_funnel') || 'Sales Funnel Analysis'}
        </h1>
        <select
          value={dateRange}
          onChange={(e) => setDateRange(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
        >
          <option value="7">Last 7 Days</option>
          <option value="30">Last 30 Days</option>
          <option value="90">Last 3 Months</option>
          <option value="365">Last Year</option>
        </select>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 mb-6">
        <h2 className="text-xl font-bold mb-4">Funnel Overview</h2>
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={funnel}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="stage" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="count" fill="#8884d8" name="Count" />
            <Bar dataKey="percentage" fill="#82ca9d" name="Percentage (%)" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Stage</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Count</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Percentage</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Drop-off Rate</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {funnel.map((stage) => (
              <tr key={stage.stage} className="hover:bg-gray-50">
                <td className="px-6 py-4">
                  <span className="font-medium text-gray-900 capitalize">{stage.stage}</span>
                </td>
                <td className="px-6 py-4 text-gray-600">{stage.count.toLocaleString()}</td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <div className="flex-1 bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full"
                        style={{ width: `${stage.percentage}%` }}
                      />
                    </div>
                    <span className="text-sm font-medium">{stage.percentage.toFixed(1)}%</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  {stage.dropoffRate !== undefined ? (
                    <span className="text-red-600 font-medium">{stage.dropoffRate.toFixed(1)}%</span>
                  ) : (
                    <span className="text-gray-400">-</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SalesFunnelPage;

