'use client';

import React, { useState, useEffect } from 'react';
import { getAuth, onAuthStateChanged, User } from 'firebase/auth';
import { app } from '@/lib/firebase';
import { getInventoryReport } from '@/lib/firestore/analytics_db';
import { InventoryReport } from '@/lib/firestore/analytics';
import { useRouter } from 'next/navigation';
import { useLanguage } from '@/context/LanguageContext';

const InventoryReportsPage = () => {
  const { t } = useLanguage();
  const [, setUser] = useState<User | null>(null);
  const [reports, setReports] = useState<InventoryReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState('30');
  const router = useRouter();
  const auth = getAuth(app);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        await fetchReports();
      } else {
        router.push('/login');
      }
    });

    return () => unsubscribe();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auth, router, dateRange]);

  const fetchReports = async () => {
    try {
      setLoading(true);
      const end = new Date();
      const start = new Date();
      start.setDate(end.getDate() - parseInt(dateRange));
      start.setHours(0, 0, 0, 0);
      end.setHours(23, 59, 59, 999);

      const data = await getInventoryReport(start, end);
      setReports(data);
    } catch (error) {
      console.error('Error fetching inventory reports:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 max-w-7xl py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-serif font-bold">
          {t('admin.inventory_reports') || 'Inventory Reports'}
        </h1>
        <select
          value={dateRange}
          onChange={(e) => setDateRange(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
        >
          <option value="7">Last 7 Days</option>
          <option value="30">Last 30 Days</option>
          <option value="90">Last 3 Months</option>
          <option value="365">Last Year</option>
        </select>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Product</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Current Stock</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Units Sold</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Stock Value</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Sales Value</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Turnover Rate</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Days of Stock</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {reports.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-center text-gray-500">
                    No inventory data available.
                  </td>
                </tr>
              ) : (
                reports.map((report) => (
                  <tr key={report.productId} className="hover:bg-gray-50">
                    <td className="px-6 py-4 font-medium text-gray-900">{report.productName}</td>
                    <td className="px-6 py-4 text-gray-600">{report.currentStock}</td>
                    <td className="px-6 py-4 text-gray-600">{report.unitsSold}</td>
                    <td className="px-6 py-4 text-gray-900 font-medium">
                      PKR {report.stockValue.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-gray-900 font-medium">
                      PKR {report.salesValue.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-gray-600">{report.turnoverRate.toFixed(1)}%</td>
                    <td className="px-6 py-4 text-gray-600">
                      {report.daysOfStock < 999 ? report.daysOfStock.toFixed(0) : 'N/A'}
                    </td>
                    <td className="px-6 py-4">
                      {report.lowStockAlert ? (
                        <span className="px-2 py-1 bg-red-100 text-red-800 text-xs font-medium rounded">
                          Low Stock
                        </span>
                      ) : (
                        <span className="px-2 py-1 bg-green-100 text-green-800 text-xs font-medium rounded">
                          In Stock
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default InventoryReportsPage;

