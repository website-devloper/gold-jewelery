'use client';

import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { getScheduledReport, updateScheduledReport, getAllCustomReportTemplates } from '@/lib/firestore/analytics_db';
import { ScheduledReport, CustomReportTemplate } from '@/lib/firestore/analytics';
import { Timestamp } from 'firebase/firestore';

const EditScheduledReportPage = () => {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;

  const [templates, setTemplates] = useState<CustomReportTemplate[]>([]);
  const [formData, setFormData] = useState({
    templateId: '',
    templateName: '',
    frequency: 'daily' as 'daily' | 'weekly' | 'monthly' | 'custom',
    dayOfWeek: 1,
    dayOfMonth: 1,
    time: '09:00',
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    recipients: [] as string[],
    recipientEmail: '',
    format: 'pdf' as 'pdf' | 'excel' | 'csv' | 'html',
    enabled: true,
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [report, templateList] = await Promise.all([
          getScheduledReport(id),
          getAllCustomReportTemplates(),
        ]);

        if (!report) {
          alert('Scheduled report not found');
          router.push('/admin/analytics/scheduled-reports');
          return;
        }

        setTemplates(templateList);

        setFormData({
          templateId: report.templateId,
          templateName: report.templateName,
          frequency: report.schedule.frequency,
          dayOfWeek: report.schedule.dayOfWeek || 1,
          dayOfMonth: report.schedule.dayOfMonth || 1,
          time: report.schedule.time,
          timezone: report.schedule.timezone,
          recipients: report.recipients,
          format: report.format,
          enabled: report.enabled,
        });
      } catch (error) {
        console.error('Error loading scheduled report:', error);
        alert('Failed to load scheduled report');
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      loadData();
    }
  }, [id, router]);

  const handleAddRecipient = () => {
    if (formData.recipientEmail && !formData.recipients.includes(formData.recipientEmail)) {
      setFormData({
        ...formData,
        recipients: [...formData.recipients, formData.recipientEmail],
        recipientEmail: '',
      });
    }
  };

  const handleRemoveRecipient = (email: string) => {
    setFormData({
      ...formData,
      recipients: formData.recipients.filter(e => e !== email),
    });
  };

  const calculateNextRun = React.useCallback((): Date => {
    const now = new Date();
    const [hours, minutes] = formData.time.split(':').map(Number);
    const nextRun = new Date();
    nextRun.setHours(hours, minutes, 0, 0);

    if (formData.frequency === 'daily') {
      if (nextRun <= now) {
        nextRun.setDate(nextRun.getDate() + 1);
      }
    } else if (formData.frequency === 'weekly') {
      const currentDay = now.getDay();
      const targetDay = formData.dayOfWeek;
      const daysUntilTarget = (targetDay - currentDay + 7) % 7;
      nextRun.setDate(now.getDate() + (daysUntilTarget || 7));
    } else if (formData.frequency === 'monthly') {
      nextRun.setDate(formData.dayOfMonth);
      if (nextRun <= now) {
        nextRun.setMonth(nextRun.getMonth() + 1);
      }
    }

    return nextRun;
  }, [formData.dayOfMonth, formData.dayOfWeek, formData.frequency, formData.time]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.templateId) {
      alert('Please select a report template.');
      return;
    }

    if (formData.recipients.length === 0) {
      alert('Please add at least one recipient email.');
      return;
    }

    setSaving(true);
    try {
      const nextRun = calculateNextRun();
      const updates: Partial<Omit<ScheduledReport, 'id' | 'createdAt'>> = {
        templateId: formData.templateId,
        templateName: formData.templateName,
        schedule: {
          frequency: formData.frequency,
          ...(formData.frequency === 'weekly' && { dayOfWeek: formData.dayOfWeek }),
          ...(formData.frequency === 'monthly' && { dayOfMonth: formData.dayOfMonth }),
          time: formData.time,
          timezone: formData.timezone,
        },
        recipients: formData.recipients,
        format: formData.format,
        enabled: formData.enabled,
        nextRun: Timestamp.fromDate(nextRun),
      };

      await updateScheduledReport(id, updates);
      router.push('/admin/analytics/scheduled-reports');
    } catch (error) {
      console.error('Error updating scheduled report:', error);
      alert('Failed to update scheduled report.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 max-w-4xl py-12">
      <div className="mb-8">
        <h1 className="text-4xl font-serif font-bold mb-2">Edit Scheduled Report</h1>
        <p className="text-gray-600">Update your scheduled report settings</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-6">
        {/* Same form fields as new page */}
        <div>
          <label className="block text-sm font-semibold text-gray-900 mb-2">Report Template *</label>
          <select
            value={formData.templateId}
            onChange={(e) => {
              const template = templates.find(t => t.id === e.target.value);
              setFormData({
                ...formData,
                templateId: e.target.value,
                templateName: template?.name || '',
              });
            }}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
          >
            <option value="">Select a template...</option>
            {templates.map((template) => (
              <option key={template.id} value={template.id}>
                {template.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-900 mb-2">Frequency *</label>
          <select
            value={formData.frequency}
            onChange={(e) => setFormData({ ...formData, frequency: e.target.value as ScheduledReport['schedule']['frequency'] })}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
          >
            <option value="daily">Daily</option>
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
          </select>
        </div>

        {formData.frequency === 'weekly' && (
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">Day of Week *</label>
            <select
              value={formData.dayOfWeek}
              onChange={(e) => setFormData({ ...formData, dayOfWeek: parseInt(e.target.value) })}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
            >
              <option value={0}>Sunday</option>
              <option value={1}>Monday</option>
              <option value={2}>Tuesday</option>
              <option value={3}>Wednesday</option>
              <option value={4}>Thursday</option>
              <option value={5}>Friday</option>
              <option value={6}>Saturday</option>
            </select>
          </div>
        )}

        {formData.frequency === 'monthly' && (
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">Day of Month *</label>
            <select
              value={formData.dayOfMonth}
              onChange={(e) => setFormData({ ...formData, dayOfMonth: parseInt(e.target.value) })}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
            >
              {Array.from({ length: 28 }, (_, i) => i + 1).map(day => (
                <option key={day} value={day}>{day}</option>
              ))}
            </select>
          </div>
        )}

        <div>
          <label className="block text-sm font-semibold text-gray-900 mb-2">Time *</label>
          <input
            type="time"
            value={formData.time}
            onChange={(e) => setFormData({ ...formData, time: e.target.value })}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-900 mb-2">Report Format *</label>
          <select
            value={formData.format}
            onChange={(e) => setFormData({ ...formData, format: e.target.value as ScheduledReport['format'] })}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
          >
            <option value="pdf">PDF</option>
            <option value="excel">Excel</option>
            <option value="csv">CSV</option>
            <option value="html">HTML</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-900 mb-2">Recipients *</label>
          <div className="flex gap-2 mb-2">
            <input
              type="email"
              value={formData.recipientEmail}
              onChange={(e) => setFormData({ ...formData, recipientEmail: e.target.value })}
              onKeyPress={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAddRecipient();
                }
              }}
              placeholder="Enter email address"
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
            />
            <button
              type="button"
              onClick={handleAddRecipient}
              className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors"
            >
              Add
            </button>
          </div>
          {formData.recipients.length > 0 && (
            <div className="space-y-2">
              {formData.recipients.map((email) => (
                <div key={email} className="flex items-center justify-between px-4 py-2 bg-gray-50 rounded-lg">
                  <span className="text-sm text-gray-700">{email}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveRecipient(email)}
                    className="text-red-600 hover:text-red-800 text-sm font-medium"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            id="enabled"
            checked={formData.enabled}
            onChange={(e) => setFormData({ ...formData, enabled: e.target.checked })}
            className="w-4 h-4 text-black border-gray-300 rounded focus:ring-black"
          />
          <label htmlFor="enabled" className="text-sm font-medium text-gray-700">
            Enable this scheduled report
          </label>
        </div>

        <div className="flex gap-4 pt-4 border-t border-gray-200">
          <button
            type="button"
            onClick={() => router.back()}
            className="px-6 py-3 border border-gray-300 rounded-lg font-bold text-gray-700 hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving || !formData.templateId || formData.recipients.length === 0}
            className="flex-1 bg-black text-white py-3 rounded-lg font-bold hover:bg-gray-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditScheduledReportPage;

