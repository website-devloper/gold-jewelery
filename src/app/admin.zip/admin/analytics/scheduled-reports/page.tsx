'use client';

import React, { useState, useEffect } from 'react';
import { getAuth, onAuthStateChanged, User } from 'firebase/auth';
import { app } from '@/lib/firebase';
import { getAllScheduledReports, updateScheduledReport, deleteScheduledReport } from '@/lib/firestore/analytics_db';
import { ScheduledReport } from '@/lib/firestore/analytics';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useLanguage } from '@/context/LanguageContext';

const ScheduledReportsPage = () => {
  const { t } = useLanguage();
  const [, setUser] = useState<User | null>(null);
  const [reports, setReports] = useState<ScheduledReport[]>([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const auth = getAuth(app);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        try {
          const data = await getAllScheduledReports();
          setReports(data);
        } catch (error) {
          console.error('Error fetching scheduled reports:', error);
        }
      } else {
        router.push('/login');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [auth, router]);

  const handleToggle = async (id: string, currentStatus: boolean) => {
    try {
      await updateScheduledReport(id, { enabled: !currentStatus });
      setReports(reports.map(r => r.id === id ? { ...r, enabled: !currentStatus } : r));
    } catch (error) {
      console.error('Error updating report:', error);
      alert('Failed to update report.');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this scheduled report?')) return;
    try {
      await deleteScheduledReport(id);
      setReports(reports.filter(r => r.id !== id));
    } catch (error) {
      console.error('Error deleting report:', error);
      alert('Failed to delete report.');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 max-w-7xl py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-serif font-bold">
          {t('admin.scheduled_reports') || 'Scheduled Reports'}
        </h1>
        <Link
          href="/admin/analytics/scheduled-reports/new"
          className="bg-black text-white px-6 py-3 rounded-xl font-bold hover:bg-gray-800 transition-colors"
        >
          Schedule New Report
        </Link>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Report Name</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Schedule</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Recipients</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Format</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Status</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Last Run</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Next Run</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {reports.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-center text-gray-500">
                    No scheduled reports found. Schedule your first report to get started.
                  </td>
                </tr>
              ) : (
                reports.map((report) => (
                  <tr key={report.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 font-medium text-gray-900">{report.templateName}</td>
                    <td className="px-6 py-4 text-gray-600 capitalize">
                      {report.schedule.frequency}
                      {report.schedule.dayOfWeek !== undefined && ` (Day ${report.schedule.dayOfWeek})`}
                      {report.schedule.dayOfMonth !== undefined && ` (Day ${report.schedule.dayOfMonth})`}
                      {' '}at {report.schedule.time}
                    </td>
                    <td className="px-6 py-4 text-gray-600">{report.recipients.length} recipients</td>
                    <td className="px-6 py-4 text-gray-600 uppercase">{report.format}</td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                        report.enabled ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {report.enabled ? 'Enabled' : 'Disabled'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-gray-600 text-sm">
                      {report.lastRun 
                        ? new Date(report.lastRun.seconds * 1000).toLocaleString()
                        : 'Never'
                      }
                    </td>
                    <td className="px-6 py-4 text-gray-600 text-sm">
                      {report.nextRun 
                        ? new Date(report.nextRun.seconds * 1000).toLocaleString()
                        : '-'
                      }
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        <button
                          onClick={() => report.id && handleToggle(report.id, report.enabled)}
                          className={`text-sm font-medium ${
                            report.enabled ? 'text-orange-600 hover:text-orange-800' : 'text-green-600 hover:text-green-800'
                          }`}
                        >
                          {report.enabled ? 'Disable' : 'Enable'}
                        </button>
                        <Link
                          href={`/admin/analytics/scheduled-reports/edit/${report.id}`}
                          className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                        >
                          Edit
                        </Link>
                        <button
                          onClick={() => report.id && handleDelete(report.id)}
                          className="text-red-600 hover:text-red-800 text-sm font-medium"
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ScheduledReportsPage;

