'use client';

import React, { useState, useEffect } from 'react';
import { getAuth, onAuthStateChanged, User } from 'firebase/auth';
import { app } from '@/lib/firebase';
import { getAllCustomReportTemplates, deleteCustomReportTemplate } from '@/lib/firestore/analytics_db';
import { CustomReportTemplate } from '@/lib/firestore/analytics';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useLanguage } from '@/context/LanguageContext';

const CustomReportsPage = () => {
  const { t } = useLanguage();
  const [, setUser] = useState<User | null>(null);
  const [templates, setTemplates] = useState<CustomReportTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const auth = getAuth(app);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        try {
          const data = await getAllCustomReportTemplates();
          setTemplates(data);
        } catch (error) {
          console.error('Error fetching templates:', error);
        }
      } else {
        router.push('/login');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [auth, router]);

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this report template?')) return;
    try {
      await deleteCustomReportTemplate(id);
      setTemplates(templates.filter(t => t.id !== id));
    } catch (error) {
      console.error('Error deleting template:', error);
      alert('Failed to delete template.');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 max-w-7xl py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-serif font-bold">
          {t('admin.custom_reports') || 'Custom Reports'}
        </h1>
        <Link
          href="/admin/analytics/custom-reports/new"
          className="bg-black text-white px-6 py-3 rounded-xl font-bold hover:bg-gray-800 transition-colors"
        >
          Create Report Template
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {templates.length === 0 ? (
          <div className="col-span-full text-center py-12 bg-white rounded-2xl border border-gray-100">
            <p className="text-gray-500 mb-4">No custom report templates found.</p>
            <Link
              href="/admin/analytics/custom-reports/new"
              className="text-blue-600 hover:underline"
            >
              Create your first template
            </Link>
          </div>
        ) : (
          templates.map((template) => (
            <div key={template.id} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
              <h3 className="text-lg font-bold mb-2">{template.name}</h3>
              {template.description && (
                <p className="text-sm text-gray-500 mb-4">{template.description}</p>
              )}
              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-500">Type:</span>
                  <span className="text-xs font-medium capitalize">{template.type}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-500">Format:</span>
                  <span className="text-xs font-medium capitalize">{template.format}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-500">Metrics:</span>
                  <span className="text-xs font-medium">{template.metrics.length} metrics</span>
                </div>
              </div>
              <div className="flex gap-2">
                <Link
                  href={`/admin/analytics/custom-reports/${template.id}`}
                  className="flex-1 text-center px-4 py-2 bg-black text-white rounded-lg text-sm font-medium hover:bg-gray-800 transition-colors"
                >
                  View
                </Link>
                <Link
                  href={`/admin/analytics/custom-reports/edit/${template.id}`}
                  className="flex-1 text-center px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors"
                >
                  Edit
                </Link>
                <button
                  onClick={() => template.id && handleDelete(template.id)}
                  className="px-4 py-2 text-red-600 hover:text-red-800 text-sm font-medium"
                >
                  Delete
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default CustomReportsPage;

