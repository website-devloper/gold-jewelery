'use client';

import React, { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { getCustomReportTemplate, updateCustomReportTemplate } from '@/lib/firestore/analytics_db';
import { CustomReportTemplate } from '@/lib/firestore/analytics';
import { Timestamp } from 'firebase/firestore';

const EditCustomReportPage = () => {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    type: 'sales' as CustomReportTemplate['type'],
    format: 'table' as 'table' | 'chart' | 'both',
    chartType: 'line' as 'line' | 'bar' | 'pie' | 'area',
    dateRange: {
      start: new Date(),
      end: new Date(),
    },
    categories: [] as string[],
    brands: [] as string[],
    products: [] as string[],
    orderStatus: [] as string[],
    metrics: [] as string[],
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      try {
        const template = await getCustomReportTemplate(id);

        if (!template) {
          alert('Template not found');
          router.push('/admin/analytics/custom-reports');
          return;
        }

        setFormData({
          name: template.name,
          description: template.description || '',
          type: template.type,
          format: template.format,
          chartType: template.chartType || 'line',
          dateRange: {
            start: template.filters.dateRange?.start?.toDate() || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
            end: template.filters.dateRange?.end?.toDate() || new Date(),
          },
          categories: template.filters.categories || [],
          brands: template.filters.brands || [],
          products: template.filters.products || [],
          orderStatus: template.filters.orderStatus || [],
          metrics: template.metrics,
        });
      } catch (error) {
        console.error('Error loading template:', error);
        alert('Failed to load template');
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      loadData();
    }
  }, [id, router]);

  const availableMetrics = {
    sales: ['revenue', 'orders', 'averageOrderValue', 'conversionRate', 'refunds'],
    products: ['views', 'clicks', 'addToCart', 'purchases', 'revenue', 'conversionRate', 'rating', 'reviewCount'],
    customers: ['totalCustomers', 'newCustomers', 'returnCustomers', 'averageSpend', 'lifetimeValue'],
    inventory: ['currentStock', 'unitsSold', 'unitsReceived', 'unitsAdjusted', 'turnoverRate', 'stockValue'],
    financial: ['revenue', 'costs', 'profit', 'margin', 'taxes'],
    marketing: ['impressions', 'clicks', 'conversions', 'revenue', 'roi', 'ctr'],
    custom: ['revenue', 'orders', 'customers', 'products'],
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const updates: Partial<Omit<CustomReportTemplate, 'id' | 'createdAt'>> = {
        name: formData.name,
        description: formData.description || undefined,
        type: formData.type,
        filters: {
          dateRange: {
            start: Timestamp.fromDate(formData.dateRange.start),
            end: Timestamp.fromDate(formData.dateRange.end),
          },
          ...(formData.categories.length > 0 && { categories: formData.categories }),
          ...(formData.brands.length > 0 && { brands: formData.brands }),
          ...(formData.products.length > 0 && { products: formData.products }),
          ...(formData.orderStatus.length > 0 && { orderStatus: formData.orderStatus }),
        },
        metrics: formData.metrics,
        format: formData.format,
        ...(formData.format !== 'table' && { chartType: formData.chartType }),
      };

      await updateCustomReportTemplate(id, updates);
      router.push('/admin/analytics/custom-reports');
    } catch (error) {
      console.error('Error updating template:', error);
      alert('Failed to update template.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 max-w-4xl py-12">
      <div className="mb-8">
        <h1 className="text-4xl font-serif font-bold mb-2">Edit Custom Report Template</h1>
        <p className="text-gray-600">Update your custom report template</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-6">
        {/* Same form fields as new page */}
        <div>
          <label className="block text-sm font-semibold text-gray-900 mb-2">Report Name *</label>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-900 mb-2">Description</label>
          <textarea
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
            rows={3}
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-900 mb-2">Report Type *</label>
          <select
            value={formData.type}
            onChange={(e) => {
              setFormData({ 
                ...formData, 
                type: e.target.value as CustomReportTemplate['type'],
                metrics: [],
              });
            }}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
          >
            <option value="sales">Sales</option>
            <option value="products">Products</option>
            <option value="customers">Customers</option>
            <option value="inventory">Inventory</option>
            <option value="financial">Financial</option>
            <option value="marketing">Marketing</option>
            <option value="custom">Custom</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-900 mb-2">Format *</label>
          <select
            value={formData.format}
            onChange={(e) => setFormData({ ...formData, format: e.target.value as 'table' | 'chart' | 'both' })}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
          >
            <option value="table">Table Only</option>
            <option value="chart">Chart Only</option>
            <option value="both">Table + Chart</option>
          </select>
        </div>

        {formData.format !== 'table' && (
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">Chart Type *</label>
            <select
              value={formData.chartType}
              onChange={(e) => setFormData({ ...formData, chartType: e.target.value as 'line' | 'bar' | 'pie' | 'area' })}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
            >
              <option value="line">Line Chart</option>
              <option value="bar">Bar Chart</option>
              <option value="pie">Pie Chart</option>
              <option value="area">Area Chart</option>
            </select>
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">Start Date *</label>
            <input
              type="date"
              value={formData.dateRange.start.toISOString().split('T')[0]}
              onChange={(e) => setFormData({
                ...formData,
                dateRange: { ...formData.dateRange, start: new Date(e.target.value) },
              })}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">End Date *</label>
            <input
              type="date"
              value={formData.dateRange.end.toISOString().split('T')[0]}
              onChange={(e) => setFormData({
                ...formData,
                dateRange: { ...formData.dateRange, end: new Date(e.target.value) },
              })}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-900 mb-2">Metrics *</label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 border border-gray-300 rounded-lg p-4 max-h-60 overflow-y-auto">
            {availableMetrics[formData.type].map((metric) => (
              <label key={metric} className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.metrics.includes(metric)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setFormData({ ...formData, metrics: [...formData.metrics, metric] });
                    } else {
                      setFormData({ ...formData, metrics: formData.metrics.filter(m => m !== metric) });
                    }
                  }}
                  className="w-4 h-4 text-black border-gray-300 rounded focus:ring-black"
                />
                <span className="text-sm text-gray-700 capitalize">{metric.replace(/([A-Z])/g, ' $1').trim()}</span>
              </label>
            ))}
          </div>
        </div>

        <div className="flex gap-4 pt-4 border-t border-gray-200">
          <button
            type="button"
            onClick={() => router.back()}
            className="px-6 py-3 border border-gray-300 rounded-lg font-bold text-gray-700 hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving || !formData.name || formData.metrics.length === 0}
            className="flex-1 bg-black text-white py-3 rounded-lg font-bold hover:bg-gray-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditCustomReportPage;

