'use client';

import React, { useState, useEffect } from 'react';
import { getAuth, onAuthStateChanged, User } from 'firebase/auth';
import { app } from '@/lib/firebase';
import { getCustomerBehavior } from '@/lib/firestore/analytics_db';
import { CustomerBehavior } from '@/lib/firestore/analytics';
import { useRouter } from 'next/navigation';
import { useLanguage } from '@/context/LanguageContext';

const CustomerBehaviorPage = () => {
  const { t } = useLanguage();
  const [, setUser] = useState<User | null>(null);
  const [behaviors, setBehaviors] = useState<CustomerBehavior[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState<'spent' | 'orders' | 'activity'>('spent');
  const router = useRouter();
  const auth = getAuth(app);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        try {
          const data = await getCustomerBehavior();
          setBehaviors(data);
        } catch (error) {
          console.error('Error fetching customer behavior:', error);
        }
      } else {
        router.push('/login');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [auth, router]);

  const sortedBehaviors = [...behaviors].sort((a, b) => {
    switch (sortBy) {
      case 'spent':
        return b.totalSpent - a.totalSpent;
      case 'orders':
        return b.productsPurchased.length - a.productsPurchased.length;
      case 'activity':
        return b.lastActivity.seconds - a.lastActivity.seconds;
      default:
        return 0;
    }
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 max-w-7xl py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-serif font-bold">
          {t('admin.customer_behavior_analytics') || t('admin.customer_behavior') || 'Customer Behavior Analytics'}
        </h1>
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as 'spent' | 'orders' | 'activity')}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
        >
          <option value="spent">Sort by Total Spent</option>
          <option value="orders">Sort by Orders</option>
          <option value="activity">Sort by Last Activity</option>
        </select>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Customer</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Total Spent</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Avg Order Value</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Products Viewed</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Products Purchased</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Return Customer</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Last Activity</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {sortedBehaviors.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                    No customer behavior data available.
                  </td>
                </tr>
              ) : (
                sortedBehaviors.map((behavior) => (
                  <tr key={behavior.userId} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div>
                        <div className="font-medium text-gray-900">{behavior.userName}</div>
                        {behavior.userEmail && (
                          <div className="text-sm text-gray-500">{behavior.userEmail}</div>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-gray-900 font-medium">
                      PKR {behavior.totalSpent.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-gray-600">
                      PKR {behavior.averageOrderValue.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-gray-600">{behavior.productsViewed.length}</td>
                    <td className="px-6 py-4 text-gray-600">{behavior.productsPurchased.length}</td>
                    <td className="px-6 py-4">
                      {behavior.returnCustomer ? (
                        <span className="px-2 py-1 bg-green-100 text-green-800 text-xs font-medium rounded">
                          Yes
                        </span>
                      ) : (
                        <span className="px-2 py-1 bg-gray-100 text-gray-800 text-xs font-medium rounded">
                          No
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-gray-600 text-sm">
                      {new Date(behavior.lastActivity.seconds * 1000).toLocaleDateString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default CustomerBehaviorPage;

