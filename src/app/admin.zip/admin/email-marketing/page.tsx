'use client';

import React, { useState } from 'react';

const EmailMarketingPage = () => {
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [recipientGroup, setRecipientGroup] = useState('all');
  const [sending, setSending] = useState(false);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    
    // Simulate sending
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    alert(`Email "${subject}" sent to ${recipientGroup} users!`);
    setSending(false);
    setSubject('');
    setMessage('');
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Email Marketing</h1>
          <p className="text-gray-500 text-sm mt-1">Send newsletters and updates to your customers.</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <form onSubmit={handleSend} className="p-6 space-y-6">
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Recipients</label>
            <select
              value={recipientGroup}
              onChange={(e) => setRecipientGroup(e.target.value)}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none bg-white"
            >
              <option value="all">All Customers</option>
              <option value="subscribers">Newsletter Subscribers</option>
              <option value="active">Active Customers (Last 30 Days)</option>
              <option value="inactive">Inactive Customers</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Subject Line</label>
            <input
              type="text"
              required
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
              placeholder="e.g. New Collection Arrival!"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Message Content</label>
            <textarea
              required
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full h-64 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none resize-none"
              placeholder="Write your email content here..."
            ></textarea>
            <p className="text-xs text-gray-500 mt-2">HTML is supported for formatting.</p>
          </div>

          <div className="pt-4 border-t border-gray-100 flex justify-end">
            <button
              type="submit"
              disabled={sending}
              className={`px-8 py-3 bg-black text-white font-bold rounded-lg hover:bg-gray-800 transition-all flex items-center gap-2 ${sending ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              {sending ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Sending...
                </>
              ) : (
                <>
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" />
                  </svg>
                  Send Campaign
                </>
              )}
            </button>
          </div>

        </form>
      </div>

      {/* History Section (Placeholder) */}
      <div className="mt-10">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Recent Campaigns</h3>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-sm font-semibold text-gray-700">Subject</th>
                <th className="px-6 py-3 text-sm font-semibold text-gray-700">Recipients</th>
                <th className="px-6 py-3 text-sm font-semibold text-gray-700">Sent Date</th>
                <th className="px-6 py-3 text-sm font-semibold text-gray-700">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              <tr className="hover:bg-gray-50">
                <td className="px-6 py-4 text-sm text-gray-900">Summer Sale Announcement</td>
                <td className="px-6 py-4 text-sm text-gray-600">All Customers</td>
                <td className="px-6 py-4 text-sm text-gray-600">May 15, 2024</td>
                <td className="px-6 py-4 text-sm"><span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">Sent</span></td>
              </tr>
              <tr className="hover:bg-gray-50">
                <td className="px-6 py-4 text-sm text-gray-900">Welcome to Pardah</td>
                <td className="px-6 py-4 text-sm text-gray-600">New Subscribers</td>
                <td className="px-6 py-4 text-sm text-gray-600">Automated</td>
                <td className="px-6 py-4 text-sm"><span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">Active</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default EmailMarketingPage;
