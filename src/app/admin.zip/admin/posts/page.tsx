'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { BlogPost } from '@/lib/firestore/blog';
import { getAllPosts, deletePost } from '@/lib/firestore/blog_db';
import { useAuth } from '../../../context/AuthContext';

const BlogList = () => {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [loadingPosts, setLoadingPosts] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const { user, loading, isAdmin } = useAuth();

  useEffect(() => {
    if (!loading) {
      if (user && isAdmin) {
        fetchPosts();
      } else if (!user) {
        router.push('/admin/login');
      } else {
        setLoadingPosts(false);
      }
    }
  }, [user, loading, isAdmin, router]);

  const fetchPosts = async () => {
    try {
      const fetchedPosts = await getAllPosts();
      setPosts(fetchedPosts);
    } catch (err: unknown) {
      console.error(err);
      if (err instanceof Error) {
        setError(`Failed to fetch posts: ${err.message}`);
      } else {
        setError('Failed to fetch posts.');
      }
    } finally {
      setLoadingPosts(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this post?')) {
      try {
        await deletePost(id);
        setPosts(posts.filter(p => p.id !== id));
      } catch (err: unknown) {
        console.error(err);
        if (err instanceof Error) {
          setError(`Failed to delete post: ${err.message}`);
        } else {
          setError('Failed to delete post.');
        }
      }
    }
  };

  if (loading || loadingPosts) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center h-full text-red-500 text-xl">
        Unauthorized: You do not have administrative access.
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Blog Posts</h1>
        <Link
          href="/admin/posts/new"
          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
          </svg>
          Add Post
        </Link>
      </div>
      
      {error && <div className="text-red-500 bg-red-50 p-4 rounded-lg mb-4">{error}</div>}

      <div className="grid gap-4">
        {posts.map((post) => (
          <div key={post.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between">
             <div className="flex items-center space-x-4">
               {post.coverImage && (
                 // eslint-disable-next-line @next/next/no-img-element
                 <img src={post.coverImage} alt={post.title} className="w-24 h-16 object-cover rounded-lg" />
               )}
               <div>
                 <h3 className="font-bold text-gray-800">{post.title}</h3>
                 <p className="text-sm text-gray-500 truncate max-w-xs">{post.slug}</p>
                 <span className={`text-xs px-2 py-1 rounded-full font-medium ${post.isPublished ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                    {post.isPublished ? 'Published' : 'Draft'}
                 </span>
               </div>
             </div>
             <div className="flex items-center space-x-4">
                <button onClick={() => router.push(`/admin/posts/edit/${post.id}`)} className="text-blue-600 hover:text-blue-800 font-medium">Edit</button>
                <button onClick={() => handleDelete(post.id)} className="text-red-600 hover:text-red-800 font-medium">Delete</button>
             </div>
          </div>
        ))}
        {posts.length === 0 && (
            <div className="text-center py-10 text-gray-500">
                No blog posts found. Create one to get started.
            </div>
        )}
      </div>
    </div>
  );
};

export default BlogList;
