'use client';

import { useRouter } from 'next/navigation';
import BlogForm from '../../../../components/admin/BlogForm';

const NewPostPage = () => {
  const router = useRouter();

  return (
    <div>
      <BlogForm 
        onSuccess={() => router.push('/admin/posts')}
        onCancel={() => router.back()}
      />
    </div>
  );
};

export default NewPostPage;
