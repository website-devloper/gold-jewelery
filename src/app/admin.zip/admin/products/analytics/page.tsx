'use client';

import React, { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Product } from '@/lib/firestore/products';
import { getAllProducts } from '@/lib/firestore/products_db';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts';

const ProductAnalyticsPage = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const productId = searchParams.get('product');
  
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState<'views' | 'clicks' | 'conversion' | 'purchases'>('views');

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const fetchedProducts = await getAllProducts();
        setProducts(fetchedProducts);
        
        if (productId) {
          // Product ID is available in URL for filtering
        }
      } catch (err) {
        console.error('Failed to fetch products:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, [productId]);

  const sortedProducts = [...products].sort((a, b) => {
    const aAnalytics = a.analytics || { views: 0, clicks: 0, conversionRate: 0, purchases: 0 };
    const bAnalytics = b.analytics || { views: 0, clicks: 0, conversionRate: 0, purchases: 0 };
    
    switch (sortBy) {
      case 'views':
        return (bAnalytics.views || 0) - (aAnalytics.views || 0);
      case 'clicks':
        return (bAnalytics.clicks || 0) - (aAnalytics.clicks || 0);
      case 'conversion':
        return (bAnalytics.conversionRate || 0) - (aAnalytics.conversionRate || 0);
      case 'purchases':
        return (bAnalytics.purchases || 0) - (aAnalytics.purchases || 0);
      default:
        return 0;
    }
  });

  const topProducts = sortedProducts.slice(0, 10);

  const chartData = topProducts.map(product => ({
    name: product.name.length > 20 ? product.name.substring(0, 20) + '...' : product.name,
    views: product.analytics?.views || 0,
    clicks: product.analytics?.clicks || 0,
    purchases: product.analytics?.purchases || 0,
    conversion: product.analytics?.conversionRate || 0,
  }));

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Product Analytics</h1>
          <p className="text-gray-500 mt-1">Track product performance metrics</p>
        </div>
        <button
          onClick={() => router.push('/admin/products')}
          className="text-gray-600 hover:text-gray-900"
        >
          ← Back to Products
        </button>
      </div>

      {/* Sort Options */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
        <div className="flex items-center gap-4">
          <label className="text-sm font-medium text-gray-700">Sort By:</label>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'views' | 'clicks' | 'conversion' | 'purchases')}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
          >
            <option value="views">Most Views</option>
            <option value="clicks">Most Clicks</option>
            <option value="conversion">Highest Conversion</option>
            <option value="purchases">Most Purchases</option>
          </select>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-6">Top Products - Views & Clicks</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} fontSize={12} />
                <YAxis fontSize={12} />
                <Tooltip />
                <Legend />
                <Bar dataKey="views" fill="#000000" name="Views" />
                <Bar dataKey="clicks" fill="#6366f1" name="Clicks" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-6">Conversion Rates</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} fontSize={12} />
                <YAxis fontSize={12} />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="conversion" stroke="#10b981" strokeWidth={2} name="Conversion %" />
                <Line type="monotone" dataKey="purchases" stroke="#f59e0b" strokeWidth={2} name="Purchases" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Product List with Analytics */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-bold text-gray-900">All Products Analytics</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Views</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Clicks</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Add to Cart</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Purchases</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Conversion Rate</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {sortedProducts.map((product) => {
                const analytics = product.analytics || {
                  views: 0,
                  clicks: 0,
                  addToCartCount: 0,
                  purchases: 0,
                  conversionRate: 0,
                };
                return (
                  <tr key={product.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">{product.name}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{analytics.views}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{analytics.clicks}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{analytics.addToCartCount}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">{analytics.purchases}</td>
                    <td className="px-6 py-4 text-sm">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        analytics.conversionRate > 5 ? 'bg-green-100 text-green-800' :
                        analytics.conversionRate > 2 ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {analytics.conversionRate.toFixed(1)}%
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ProductAnalyticsPage;

