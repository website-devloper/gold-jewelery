'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Product } from '@/lib/firestore/products';
import { getAllProducts, bulkUpdateProducts } from '@/lib/firestore/products_db';

const BulkActionsPage = () => {
  const router = useRouter();
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);
  const [actionType, setActionType] = useState<'price' | 'stock' | 'status' | 'featured'>('price');
  
  // Update values
  const [priceUpdate, setPriceUpdate] = useState({ type: 'set' as 'set' | 'increase' | 'decrease', value: 0 });
  const [statusUpdate, setStatusUpdate] = useState<'active' | 'inactive'>('active');
  const [featuredUpdate, setFeaturedUpdate] = useState<boolean>(false);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const fetchedProducts = await getAllProducts();
        setProducts(fetchedProducts);
      } catch (err) {
        console.error('Failed to fetch products:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedProducts(products.map(p => p.id));
    } else {
      setSelectedProducts([]);
    }
  };

  const handleSelectProduct = (productId: string, checked: boolean) => {
    if (checked) {
      setSelectedProducts([...selectedProducts, productId]);
    } else {
      setSelectedProducts(selectedProducts.filter(id => id !== productId));
    }
  };

  const handleBulkUpdate = async () => {
    if (selectedProducts.length === 0) {
      alert('Please select at least one product');
      return;
    }

    setUpdating(true);
    try {
      const updates: Partial<Product> = {};

      switch (actionType) {
        case 'price':
          if (priceUpdate.type === 'set') {
            updates.price = priceUpdate.value;
          } else if (priceUpdate.type === 'increase') {
            // We'll need to get current prices and update
            const productsToUpdate = products.filter(p => selectedProducts.includes(p.id));
            await Promise.all(productsToUpdate.map(async (product) => {
              const newPrice = product.price + priceUpdate.value;
              await bulkUpdateProducts([product.id], { price: newPrice });
            }));
            setUpdating(false);
            alert('Prices updated successfully!');
            router.push('/admin/products');
            return;
          } else {
            const productsToUpdate = products.filter(p => selectedProducts.includes(p.id));
            await Promise.all(productsToUpdate.map(async (product) => {
              const newPrice = Math.max(0, product.price - priceUpdate.value);
              await bulkUpdateProducts([product.id], { price: newPrice });
            }));
            setUpdating(false);
            alert('Prices updated successfully!');
            router.push('/admin/products');
            return;
          }
          break;

        case 'stock':
          // Stock updates need to be done per variant
          alert('Stock updates need to be done per variant. Please use the stock management page.');
          setUpdating(false);
          return;

        case 'status':
          updates.isActive = statusUpdate === 'active';
          break;

        case 'featured':
          updates.isFeatured = featuredUpdate;
          break;
      }

      await bulkUpdateProducts(selectedProducts, updates);
      alert(`${selectedProducts.length} products updated successfully!`);
      router.push('/admin/products');
    } catch (error) {
      console.error('Bulk update failed:', error);
      alert('Failed to update products. Please try again.');
    } finally {
      setUpdating(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Bulk Actions</h1>
          <p className="text-gray-500 mt-1">Update multiple products at once</p>
        </div>
        <button
          onClick={() => router.push('/admin/products')}
          className="text-gray-600 hover:text-gray-900"
        >
          ← Back to Products
        </button>
      </div>

      {/* Action Selection */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
        <h2 className="text-lg font-bold mb-4">Select Action</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <button
            onClick={() => setActionType('price')}
            className={`p-4 rounded-lg border-2 transition-all ${
              actionType === 'price' ? 'border-black bg-black text-white' : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            Update Price
          </button>
          <button
            onClick={() => setActionType('stock')}
            className={`p-4 rounded-lg border-2 transition-all ${
              actionType === 'stock' ? 'border-black bg-black text-white' : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            Update Stock
          </button>
          <button
            onClick={() => setActionType('status')}
            className={`p-4 rounded-lg border-2 transition-all ${
              actionType === 'status' ? 'border-black bg-black text-white' : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            Update Status
          </button>
          <button
            onClick={() => setActionType('featured')}
            className={`p-4 rounded-lg border-2 transition-all ${
              actionType === 'featured' ? 'border-black bg-black text-white' : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            Update Featured
          </button>
        </div>

        {/* Action Form */}
        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          {actionType === 'price' && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Update Type</label>
                <select
                  value={priceUpdate.type}
                  onChange={(e) => setPriceUpdate({ ...priceUpdate, type: e.target.value as 'set' | 'increase' | 'decrease' })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                >
                  <option value="set">Set Price</option>
                  <option value="increase">Increase By</option>
                  <option value="decrease">Decrease By</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {priceUpdate.type === 'set' ? 'New Price (PKR)' : 'Amount (PKR)'}
                </label>
                <input
                  type="number"
                  value={priceUpdate.value}
                  onChange={(e) => setPriceUpdate({ ...priceUpdate, value: parseFloat(e.target.value) || 0 })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                  placeholder="0.00"
                  min="0"
                  step="0.01"
                />
              </div>
            </div>
          )}

          {actionType === 'status' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
              <select
                value={statusUpdate}
                onChange={(e) => setStatusUpdate(e.target.value as 'active' | 'inactive')}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg"
              >
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>
          )}

          {actionType === 'featured' && (
            <div>
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={featuredUpdate}
                  onChange={(e) => setFeaturedUpdate(e.target.checked)}
                  className="w-5 h-5"
                />
                <span className="text-sm font-medium text-gray-700">Mark as Featured</span>
              </label>
            </div>
          )}
        </div>
      </div>

      {/* Product Selection */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-4 border-b border-gray-200 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <input
              type="checkbox"
              checked={selectedProducts.length === products.length && products.length > 0}
              onChange={(e) => handleSelectAll(e.target.checked)}
              className="w-5 h-5"
            />
            <span className="font-medium text-gray-900">
              {selectedProducts.length} of {products.length} selected
            </span>
          </div>
          <button
            onClick={handleBulkUpdate}
            disabled={selectedProducts.length === 0 || updating}
            className="bg-black text-white px-6 py-2 rounded-lg hover:bg-gray-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {updating ? 'Updating...' : `Update ${selectedProducts.length} Products`}
          </button>
        </div>

        <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50 sticky top-0">
              <tr>
                <th className="px-6 py-3 text-left">
                  <input
                    type="checkbox"
                    checked={selectedProducts.length === products.length && products.length > 0}
                    onChange={(e) => handleSelectAll(e.target.checked)}
                    className="w-4 h-4"
                  />
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {products.map((product) => (
                <tr key={product.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <input
                      type="checkbox"
                      checked={selectedProducts.includes(product.id)}
                      onChange={(e) => handleSelectProduct(product.id, e.target.checked)}
                      className="w-4 h-4"
                    />
                  </td>
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">{product.name}</td>
                  <td className="px-6 py-4 text-sm text-gray-900">PKR {product.price.toLocaleString()}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      product.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {product.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default BulkActionsPage;

