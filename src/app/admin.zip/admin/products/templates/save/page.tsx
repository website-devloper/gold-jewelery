'use client';

import React, { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Product } from '@/lib/firestore/products';
import { getProduct } from '@/lib/firestore/products_db';
import { addProductTemplate } from '@/lib/firestore/product_templates_db';

const SaveTemplatePage = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const productId = searchParams.get('product');
  
  const [product, setProduct] = useState<Product | null>(null);
  const [templateName, setTemplateName] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const fetchProduct = async () => {
      if (productId) {
        try {
          const fetchedProduct = await getProduct(productId);
          if (fetchedProduct) {
            setProduct(fetchedProduct);
            setTemplateName(`${fetchedProduct.name} Template`);
          }
        } catch (err) {
          console.error('Failed to fetch product:', err);
        }
      }
      setLoading(false);
    };
    fetchProduct();
  }, [productId]);

  const handleSaveTemplate = async () => {
    if (!product || !templateName.trim()) {
      alert('Please enter a template name');
      return;
    }

    setSaving(true);
    try {
      const template = {
        name: templateName,
        description: product.description,
        category: product.category,
        brandId: product.brandId,
        price: product.price,
        variants: product.variants.map(v => ({ ...v })),
        isFeatured: product.isFeatured,
      };

      await addProductTemplate(template);
      alert('Template saved successfully!');
      router.push('/admin/products/templates');
    } catch (error) {
      console.error('Failed to save template:', error);
      alert('Failed to save template. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
          Product not found. Please select a product first.
        </div>
        <button
          onClick={() => router.push('/admin/products')}
          className="mt-4 text-gray-600 hover:text-gray-900"
        >
          ← Back to Products
        </button>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Save Product as Template</h1>
          <p className="text-gray-500 mt-1">Create a reusable template from this product</p>
        </div>
        <button
          onClick={() => router.push('/admin/products/templates')}
          className="text-gray-600 hover:text-gray-900"
        >
          ← Back to Templates
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 max-w-2xl">
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Template Name</label>
            <input
              type="text"
              value={templateName}
              onChange={(e) => setTemplateName(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
              placeholder="Enter template name"
            />
          </div>

          <div className="bg-gray-50 rounded-lg p-4 space-y-3">
            <h3 className="font-bold text-gray-900">Template Preview</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Product:</span>
                <span className="font-medium">{product.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Price:</span>
                <span className="font-medium">PKR {product.price.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Category:</span>
                <span className="font-medium">{product.category}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Variants:</span>
                <span className="font-medium">{product.variants.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Featured:</span>
                <span className="font-medium">{product.isFeatured ? 'Yes' : 'No'}</span>
              </div>
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <button
              onClick={() => router.push('/admin/products/templates')}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveTemplate}
              disabled={saving || !templateName.trim()}
              className="flex-1 bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {saving ? 'Saving...' : 'Save Template'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SaveTemplatePage;

