'use client';

import React, { useState, useEffect } from 'react';
import { getAllProductBundles, createProductBundle, updateProductBundle, deleteProductBundle } from '@/lib/firestore/product_bundles_db';
import { ProductBundle } from '@/lib/firestore/product_bundles';
import { getAllProducts } from '@/lib/firestore/products_db';
import { Product } from '@/lib/firestore/products';
import { Timestamp } from 'firebase/firestore';

const ProductBundlesPage = () => {
  const [bundles, setBundles] = useState<ProductBundle[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingBundle, setEditingBundle] = useState<ProductBundle | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    image: '',
    products: [] as { productId: string; quantity: number; discount?: number; isRequired: boolean }[],
    bundlePrice: '',
    discountType: 'percentage' as 'percentage' | 'fixed' | 'bundle_price',
    discountValue: '',
    validFrom: '',
    validUntil: '',
    isActive: true,
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [bundlesData, productsData] = await Promise.all([
        getAllProductBundles(),
        getAllProducts(),
      ]);
      setBundles(bundlesData);
      setProducts(productsData);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddProduct = () => {
    setFormData({
      ...formData,
      products: [...formData.products, { productId: '', quantity: 1, discount: 0, isRequired: true }],
    });
  };

  const handleRemoveProduct = (index: number) => {
    setFormData({
      ...formData,
      products: formData.products.filter((_, i) => i !== index),
    });
  };

  const handleProductChange = (index: number, field: string, value: string | number | boolean | undefined) => {
    const updatedProducts = [...formData.products];
    updatedProducts[index] = { ...updatedProducts[index], [field]: value };
    setFormData({ ...formData, products: updatedProducts });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const bundleData: Omit<ProductBundle, 'id' | 'createdAt' | 'updatedAt'> = {
        name: formData.name,
        ...(formData.description.trim() ? { description: formData.description.trim() } : {}),
        ...(formData.image.trim() ? { image: formData.image.trim() } : {}),
        products: formData.products.map(p => ({
          productId: p.productId,
          productName: products.find(pr => pr.id === p.productId)?.name || '',
          quantity: p.quantity,
          discount: p.discount,
          isRequired: p.isRequired,
        })),
        ...(formData.bundlePrice ? { bundlePrice: parseFloat(formData.bundlePrice) } : {}),
        discountType: formData.discountType,
        ...(formData.discountValue ? { discountValue: parseFloat(formData.discountValue) } : {}),
        ...(formData.validFrom ? { validFrom: Timestamp.fromDate(new Date(formData.validFrom)) } : {}),
        ...(formData.validUntil ? { validUntil: Timestamp.fromDate(new Date(formData.validUntil)) } : {}),
        isActive: formData.isActive,
      };

      if (editingBundle) {
        await updateProductBundle(editingBundle.id!, bundleData);
      } else {
        await createProductBundle(bundleData);
      }

      setShowForm(false);
      setEditingBundle(null);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Failed to save bundle:', error);
      alert('Failed to save bundle');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      image: '',
      products: [],
      bundlePrice: '',
      discountType: 'percentage',
      discountValue: '',
      validFrom: '',
      validUntil: '',
      isActive: true,
    });
  };

  const handleEdit = (bundle: ProductBundle) => {
    setEditingBundle(bundle);
    setFormData({
      name: bundle.name,
      description: bundle.description || '',
      image: bundle.image || '',
      products: bundle.products.map(p => ({
        productId: p.productId,
        quantity: p.quantity,
        discount: p.discount,
        isRequired: p.isRequired,
      })),
      bundlePrice: bundle.bundlePrice?.toString() || '',
      discountType: bundle.discountType,
      discountValue: bundle.discountValue?.toString() || '',
      validFrom: bundle.validFrom?.toDate ? new Date(bundle.validFrom.toDate()).toISOString().split('T')[0] : '',
      validUntil: bundle.validUntil?.toDate ? new Date(bundle.validUntil.toDate()).toISOString().split('T')[0] : '',
      isActive: bundle.isActive,
    });
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this bundle?')) return;
    try {
      await deleteProductBundle(id);
      fetchData();
    } catch (error) {
      console.error('Failed to delete bundle:', error);
      alert('Failed to delete bundle');
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Product Bundles</h1>
          <p className="text-gray-500 mt-1">Create &quot;Buy Together&quot; product bundles with discounts</p>
        </div>
        <button
          onClick={() => {
            resetForm();
            setEditingBundle(null);
            setShowForm(true);
          }}
          className="bg-black text-white px-6 py-2 rounded-full text-sm font-bold uppercase tracking-widest hover:bg-gray-800 transition-colors"
        >
          + New Bundle
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-bold mb-4">{editingBundle ? 'Edit' : 'Create'} Product Bundle</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Bundle Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Discount Type</label>
              <select
                value={formData.discountType}
                onChange={(e) => setFormData({ ...formData, discountType: e.target.value as 'percentage' | 'fixed' | 'bundle_price' })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
              >
                <option value="percentage">Percentage</option>
                <option value="fixed">Fixed Amount</option>
                <option value="bundle_price">Bundle Price</option>
              </select>
            </div>
            {formData.discountType !== 'bundle_price' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {formData.discountType === 'percentage' ? 'Discount Percentage' : 'Discount Amount'}
                </label>
                <input
                  type="number"
                  value={formData.discountValue}
                  onChange={(e) => setFormData({ ...formData, discountValue: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                />
              </div>
            )}
            {formData.discountType === 'bundle_price' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Bundle Price</label>
                <input
                  type="number"
                  value={formData.bundlePrice}
                  onChange={(e) => setFormData({ ...formData, bundlePrice: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                />
              </div>
            )}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Products</label>
              {formData.products.map((product, index) => (
                <div key={index} className="flex gap-2 mb-2">
                  <select
                    value={product.productId}
                    onChange={(e) => handleProductChange(index, 'productId', e.target.value)}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                    required
                  >
                    <option value="">Select Product</option>
                    {products.map(p => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                  <input
                    type="number"
                    value={product.quantity}
                    onChange={(e) => handleProductChange(index, 'quantity', parseInt(e.target.value))}
                    className="w-24 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                    placeholder="Qty"
                    min="1"
                    required
                  />
                  <input
                    type="number"
                    value={product.discount || ''}
                    onChange={(e) => handleProductChange(index, 'discount', e.target.value ? parseFloat(e.target.value) : undefined)}
                    className="w-24 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                    placeholder="% Off"
                  />
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={product.isRequired}
                      onChange={(e) => handleProductChange(index, 'isRequired', e.target.checked)}
                      className="w-4 h-4"
                    />
                    <span className="text-sm">Required</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => handleRemoveProduct(index)}
                    className="text-red-600 hover:text-red-900"
                  >
                    Remove
                  </button>
                </div>
              ))}
              <button
                type="button"
                onClick={handleAddProduct}
                className="text-blue-600 hover:text-blue-900 text-sm font-medium"
              >
                + Add Product
              </button>
            </div>
            <div className="flex gap-3">
              <button
                type="submit"
                className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 transition-colors"
              >
                {editingBundle ? 'Update' : 'Create'} Bundle
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditingBundle(null);
                  resetForm();
                }}
                className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Bundle Name</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Products</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Discount</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {bundles.map((bundle) => (
                <tr key={bundle.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{bundle.name}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">{bundle.products.length} products</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {bundle.discountType === 'percentage' && bundle.discountValue && `${bundle.discountValue}%`}
                    {bundle.discountType === 'fixed' && bundle.discountValue && `PKR ${bundle.discountValue}`}
                    {bundle.discountType === 'bundle_price' && bundle.bundlePrice && `PKR ${bundle.bundlePrice}`}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-bold rounded-full ${
                      bundle.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {bundle.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex gap-2 justify-end">
                      <button
                        onClick={() => handleEdit(bundle)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(bundle.id!)}
                        className="text-red-600 hover:text-red-900"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ProductBundlesPage;

