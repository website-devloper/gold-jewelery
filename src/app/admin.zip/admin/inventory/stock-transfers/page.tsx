'use client';

import React, { useState, useEffect } from 'react';
import { getAllStockTransfers, createStockTransfer, approveStockTransfer, completeStockTransfer } from '@/lib/firestore/warehouses_db';
import { StockTransfer } from '@/lib/firestore/warehouses';
import { getAllWarehouses } from '@/lib/firestore/warehouses_db';
import { Warehouse } from '@/lib/firestore/warehouses';
import { getAllProducts } from '@/lib/firestore/products_db';
import { Product } from '@/lib/firestore/products';
import { useAuth } from '../../../../context/AuthContext';

const StockTransfersPage = () => {
  const { user } = useAuth();
  const [transfers, setTransfers] = useState<StockTransfer[]>([]);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    fromWarehouseId: '',
    toWarehouseId: '',
    items: [{ productId: '', variantId: '', quantity: 1 }],
    notes: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [transfersData, warehousesData, productsData] = await Promise.all([
        getAllStockTransfers(),
        getAllWarehouses(true),
        getAllProducts(),
      ]);
      setTransfers(transfersData);
      setWarehouses(warehousesData);
      setProducts(productsData);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      const fromWarehouse = warehouses.find(w => w.id === formData.fromWarehouseId);
      const toWarehouse = warehouses.find(w => w.id === formData.toWarehouseId);

      if (!fromWarehouse || !toWarehouse) {
        alert('Please select both warehouses');
        return;
      }

      const items = formData.items.map(item => {
        const product = products.find(p => p.id === item.productId);
        return {
          productId: item.productId,
          productName: product?.name || 'Unknown',
          variantId: item.variantId || undefined,
          variantName: item.variantId ? product?.variants.find(v => v.id === item.variantId)?.name : undefined,
          quantity: item.quantity,
        };
      });

      await createStockTransfer({
        fromWarehouseId: formData.fromWarehouseId,
        fromWarehouseName: fromWarehouse.name,
        toWarehouseId: formData.toWarehouseId,
        toWarehouseName: toWarehouse.name,
        items,
        notes: formData.notes || undefined,
        requestedBy: user.uid,
        requestedByName: user.displayName || user.email || 'Admin',
      });

      setShowForm(false);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Failed to create transfer:', error);
      alert('Failed to create transfer');
    }
  };

  const resetForm = () => {
    setFormData({
      fromWarehouseId: '',
      toWarehouseId: '',
      items: [{ productId: '', variantId: '', quantity: 1 }],
      notes: '',
    });
  };

  const handleApprove = async (id: string) => {
    if (!user) return;
    try {
      await approveStockTransfer(id, user.uid);
      fetchData();
    } catch (error) {
      console.error('Failed to approve transfer:', error);
    }
  };

  const handleComplete = async (id: string) => {
    if (!user) return;
    try {
      await completeStockTransfer(id, user.uid);
      fetchData();
    } catch (error) {
      console.error('Failed to complete transfer:', error);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Stock Transfers</h1>
          <p className="text-gray-500 mt-1">Transfer stock between warehouses</p>
        </div>
        <button
          onClick={() => {
            setShowForm(true);
            resetForm();
          }}
          className="bg-black text-white px-6 py-2 rounded-full text-sm font-bold uppercase tracking-widest hover:bg-gray-800 transition-colors"
        >
          + New Transfer
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-bold mb-4">New Stock Transfer</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">From Warehouse</label>
                <select
                  value={formData.fromWarehouseId}
                  onChange={(e) => setFormData({ ...formData, fromWarehouseId: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  required
                >
                  <option value="">Select warehouse</option>
                  {warehouses.map(warehouse => (
                    <option key={warehouse.id} value={warehouse.id}>{warehouse.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">To Warehouse</label>
                <select
                  value={formData.toWarehouseId}
                  onChange={(e) => setFormData({ ...formData, toWarehouseId: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  required
                >
                  <option value="">Select warehouse</option>
                  {warehouses.map(warehouse => (
                    <option key={warehouse.id} value={warehouse.id}>{warehouse.name}</option>
                  ))}
                </select>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Items</label>
              {formData.items.map((item, idx) => (
                <div key={idx} className="grid grid-cols-4 gap-2 mb-2">
                  <select
                    value={item.productId}
                    onChange={(e) => {
                      const newItems = [...formData.items];
                      newItems[idx].productId = e.target.value;
                      setFormData({ ...formData, items: newItems });
                    }}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                    required
                  >
                    <option value="">Select product</option>
                    {products.map(product => (
                      <option key={product.id} value={product.id}>{product.name}</option>
                    ))}
                  </select>
                  <input
                    type="number"
                    placeholder="Quantity"
                    value={item.quantity}
                    onChange={(e) => {
                      const newItems = [...formData.items];
                      newItems[idx].quantity = parseInt(e.target.value) || 1;
                      setFormData({ ...formData, items: newItems });
                    }}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                    required
                    min="1"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const newItems = formData.items.filter((_, i) => i !== idx);
                      setFormData({ ...formData, items: newItems });
                    }}
                    className="text-red-600 hover:text-red-900"
                  >
                    Remove
                  </button>
                </div>
              ))}
              <button
                type="button"
                onClick={() => setFormData({ ...formData, items: [...formData.items, { productId: '', variantId: '', quantity: 1 }] })}
                className="text-blue-600 hover:text-blue-900 text-sm"
              >
                + Add Item
              </button>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
              />
            </div>
            <div className="flex gap-3">
              <button
                type="submit"
                className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 transition-colors"
              >
                Create Transfer
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  resetForm();
                }}
                className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Transfer #</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">From → To</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Items</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Requested By</th>
                <th className="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {transfers.map((transfer) => (
                <tr key={transfer.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">{transfer.transferNumber}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {transfer.fromWarehouseName} → {transfer.toWarehouseName}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">{transfer.items.length} items</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-bold rounded-full ${
                      transfer.status === 'completed' ? 'bg-green-100 text-green-700' :
                      transfer.status === 'in_transit' ? 'bg-blue-100 text-blue-700' :
                      'bg-yellow-100 text-yellow-700'
                    }`}>
                      {transfer.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">{transfer.requestedByName || 'N/A'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    {transfer.status === 'pending' && (
                      <button
                        onClick={() => handleApprove(transfer.id!)}
                        className="text-blue-600 hover:text-blue-900 mr-4"
                      >
                        Approve
                      </button>
                    )}
                    {transfer.status === 'in_transit' && (
                      <button
                        onClick={() => handleComplete(transfer.id!)}
                        className="text-green-600 hover:text-green-900"
                      >
                        Complete
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default StockTransfersPage;

