'use client';

import React, { useState, useEffect } from 'react';
import { getCities, addCity, updateCity, deleteCity, getStates, getCountries } from '@/lib/firestore/geography_db';
import { City, State, Country } from '@/lib/firestore/geography';
import { useSettings } from '@/context/SettingsContext';

const CitiesPage = () => {
  const { settings } = useSettings();
  const [cities, setCities] = useState<City[]>([]);
  const [states, setStates] = useState<State[]>([]);
  const [countries, setCountries] = useState<Country[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [selectedStateFilter, setSelectedStateFilter] = useState('');
  const [formData, setFormData] = useState<Partial<City>>({
    name: '',
    stateId: '',
    countryId: '',
    status: 'active'
  });

  const fetchCities = React.useCallback(async () => {
    setLoading(true);
    const data = await getCities(selectedStateFilter || undefined);
    
    // Enrich data
    const enrichedData = data.map(city => {
       const state = states.find(s => s.id === city.stateId);
       const country = countries.find(c => c.id === city.countryId);
       return { 
         ...city, 
         stateName: state?.name || city.stateName || 'Unknown',
         countryName: country?.name || city.countryName || 'Unknown'
       };
    });

    setCities(enrichedData);
    setLoading(false);
  }, [selectedStateFilter, states, countries]);

  const fetchInitialData = React.useCallback(async () => {
    const [countriesData, statesData] = await Promise.all([
      getCountries(),
      getStates()
    ]);
    setCountries(countriesData);
    setStates(statesData);
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    fetchInitialData();
  }, [fetchInitialData]);

  useEffect(() => {
    if (states.length > 0 && countries.length > 0) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      fetchCities();
    }
  }, [selectedStateFilter, fetchCities, states.length, countries.length]);

  // Check if cities feature is enabled
  if (!settings?.geography?.cities) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center max-w-md px-4">
          <h1 className="text-3xl font-heading font-bold mb-4 text-gray-900">Cities Not Available</h1>
          <p className="text-gray-500 mb-6">This feature is currently disabled in Geography Settings.</p>
        </div>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const selectedState = states.find(s => s.id === formData.stateId);
      const selectedCountry = countries.find(c => c.id === selectedState?.countryId);

      const dataToSave = {
        ...formData,
        stateName: selectedState?.name,
        countryId: selectedState?.countryId,
        countryName: selectedCountry?.name
      };

      if (editingId) {
        await updateCity(editingId, dataToSave);
      } else {
        await addCity(dataToSave as City);
      }
      setIsModalOpen(false);
      resetForm();
      fetchCities();
    } catch (error) {
      console.error('Error saving city:', error);
      alert('Failed to save city');
    }
  };

  const handleEdit = (city: City) => {
    setEditingId(city.id!);
    setFormData({
      name: city.name,
      stateId: city.stateId,
      countryId: city.countryId,
      status: city.status
    });
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this city?')) {
      await deleteCity(id);
      fetchCities();
    }
  };

  const resetForm = () => {
    setEditingId(null);
    setFormData({
      name: '',
      stateId: '',
      countryId: '',
      status: 'active'
    });
  };

  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
        <h1 className="text-2xl font-bold text-gray-900">Cities</h1>
        
        <div className="flex gap-4 w-full md:w-auto">
          <select
            value={selectedStateFilter}
            onChange={(e) => setSelectedStateFilter(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none bg-white text-sm"
          >
            <option value="">All States</option>
            {states.map(s => (
              <option key={s.id} value={s.id}>{s.name} ({countries.find(c=>c.id === s.countryId)?.name})</option>
            ))}
          </select>

          <button
            onClick={() => { resetForm(); setIsModalOpen(true); }}
            className="bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition-colors flex items-center gap-2 whitespace-nowrap"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
            </svg>
            Add City
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-200">
              <th className="px-6 py-4 text-sm font-semibold text-gray-700">Name</th>
              <th className="px-6 py-4 text-sm font-semibold text-gray-700">State</th>
              <th className="px-6 py-4 text-sm font-semibold text-gray-700">Country</th>
              <th className="px-6 py-4 text-sm font-semibold text-gray-700">Status</th>
              <th className="px-6 py-4 text-sm font-semibold text-gray-700 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {loading ? (
              <tr>
                <td colSpan={5} className="px-6 py-8 text-center text-gray-500">Loading...</td>
              </tr>
            ) : cities.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-6 py-8 text-center text-gray-500">No cities found.</td>
              </tr>
            ) : (
              cities.map((city) => (
                <tr key={city.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm text-gray-900 font-medium">{city.name}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">
                     {states.find(s => s.id === city.stateId)?.name || city.stateName || 'Unknown'}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">
                     {countries.find(c => c.id === city.countryId)?.name || city.countryName || 'Unknown'}
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      city.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {city.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right space-x-2">
                    <button 
                      onClick={() => handleEdit(city)}
                      className="text-blue-600 hover:text-blue-900 text-sm font-medium"
                    >
                      Edit
                    </button>
                    <button 
                      onClick={() => handleDelete(city.id!)}
                      className="text-red-600 hover:text-red-900 text-sm font-medium"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-6 transform transition-all">
            <h2 className="text-xl font-bold mb-6">{editingId ? 'Edit City' : 'Add New City'}</h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">State</label>
                <select 
                  required
                  value={formData.stateId}
                  onChange={(e) => setFormData({...formData, stateId: e.target.value})}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none bg-white"
                >
                  <option value="">Select State</option>
                  {states.map(s => (
                    <option key={s.id} value={s.id}>
                        {s.name} ({countries.find(c=>c.id === s.countryId)?.name})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">City Name</label>
                <input 
                  type="text" 
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                  placeholder="e.g. Lahore"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <select 
                  value={formData.status}
                  onChange={(e) => setFormData({...formData, status: e.target.value as 'active' | 'inactive'})}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none bg-white"
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>

              <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-gray-100">
                <button 
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-black hover:bg-gray-800 rounded-lg transition-colors"
                >
                  {editingId ? 'Update City' : 'Add City'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default CitiesPage;
