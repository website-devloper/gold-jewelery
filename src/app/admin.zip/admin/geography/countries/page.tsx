'use client';

import React, { useState, useEffect } from 'react';
import { getCountries, addCountry, updateCountry, deleteCountry } from '@/lib/firestore/geography_db';
import { Country } from '@/lib/firestore/geography';
import { useSettings } from '@/context/SettingsContext';

const CountriesPage = () => {
  const { settings } = useSettings();
  const [countries, setCountries] = useState<Country[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<Country>>({
    name: '',
    isoCode: '',
    phoneCode: '',
    currency: '',
    status: 'active'
  });

  const fetchCountries = React.useCallback(async () => {
    setLoading(true);
    const data = await getCountries();
    setCountries(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    fetchCountries();
  }, [fetchCountries]);

  // Check if countries feature is enabled
  if (!settings?.geography?.countries) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center max-w-md px-4">
          <h1 className="text-3xl font-heading font-bold mb-4 text-gray-900">Countries Not Available</h1>
          <p className="text-gray-500 mb-6">This feature is currently disabled in Geography Settings.</p>
        </div>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingId) {
        await updateCountry(editingId, formData);
      } else {
        await addCountry(formData as Country);
      }
      setIsModalOpen(false);
      resetForm();
      fetchCountries();
    } catch (error) {
      console.error('Error saving country:', error);
      alert('Failed to save country');
    }
  };

  const handleEdit = (country: Country) => {
    setEditingId(country.id!);
    setFormData({
      name: country.name,
      isoCode: country.isoCode,
      phoneCode: country.phoneCode,
      currency: country.currency,
      status: country.status
    });
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this country?')) {
      await deleteCountry(id);
      fetchCountries();
    }
  };

  const resetForm = () => {
    setEditingId(null);
    setFormData({
      name: '',
      isoCode: '',
      phoneCode: '',
      currency: '',
      status: 'active'
    });
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Countries</h1>
        <button
          onClick={() => { resetForm(); setIsModalOpen(true); }}
          className="bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition-colors flex items-center gap-2"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
          </svg>
          Add Country
        </button>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-200">
              <th className="px-6 py-4 text-sm font-semibold text-gray-700">Name</th>
              <th className="px-6 py-4 text-sm font-semibold text-gray-700">ISO Code</th>
              <th className="px-6 py-4 text-sm font-semibold text-gray-700">Phone Code</th>
              <th className="px-6 py-4 text-sm font-semibold text-gray-700">Currency</th>
              <th className="px-6 py-4 text-sm font-semibold text-gray-700">Status</th>
              <th className="px-6 py-4 text-sm font-semibold text-gray-700 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {loading ? (
              <tr>
                <td colSpan={6} className="px-6 py-8 text-center text-gray-500">Loading...</td>
              </tr>
            ) : countries.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-6 py-8 text-center text-gray-500">No countries found. Add one to get started.</td>
              </tr>
            ) : (
              countries.map((country) => (
                <tr key={country.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm text-gray-900 font-medium">{country.name}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{country.isoCode}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{country.phoneCode}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{country.currency}</td>
                  <td className="px-6 py-4 text-sm">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      country.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {country.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right space-x-2">
                    <button 
                      onClick={() => handleEdit(country)}
                      className="text-blue-600 hover:text-blue-900 text-sm font-medium"
                    >
                      Edit
                    </button>
                    <button 
                      onClick={() => handleDelete(country.id!)}
                      className="text-red-600 hover:text-red-900 text-sm font-medium"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-6 transform transition-all">
            <h2 className="text-xl font-bold mb-6">{editingId ? 'Edit Country' : 'Add New Country'}</h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Country Name</label>
                <input 
                  type="text" 
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                  placeholder="e.g. Pakistan"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">ISO Code</label>
                  <input 
                    type="text" 
                    required
                    value={formData.isoCode}
                    onChange={(e) => setFormData({...formData, isoCode: e.target.value.toUpperCase()})}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                    placeholder="e.g. PK"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Phone Code</label>
                  <input 
                    type="text" 
                    required
                    value={formData.phoneCode}
                    onChange={(e) => setFormData({...formData, phoneCode: e.target.value})}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                    placeholder="e.g. +92"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                 <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Currency</label>
                  <input 
                    type="text" 
                    required
                    value={formData.currency}
                    onChange={(e) => setFormData({...formData, currency: e.target.value.toUpperCase()})}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                    placeholder="e.g. PKR"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                  <select 
                    value={formData.status}
                    onChange={(e) => setFormData({...formData, status: e.target.value as 'active' | 'inactive'})}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none bg-white"
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-gray-100">
                <button 
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-black hover:bg-gray-800 rounded-lg transition-colors"
                >
                  {editingId ? 'Update Country' : 'Add Country'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default CountriesPage;
