'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Collection } from '@/lib/firestore/collections';
import { getAllCollections, deleteCollection } from '@/lib/firestore/collections_db';

interface CollectionWithChildren extends Collection {
  children?: CollectionWithChildren[];
  level?: number;
}

const CollectionList = () => {
  const [collections, setCollections] = useState<Collection[]>([]);
  const [hierarchicalCollections, setHierarchicalCollections] = useState<CollectionWithChildren[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'flat' | 'tree'>('tree');
  const router = useRouter();

  useEffect(() => {
    fetchCollections();
  }, []);

  const fetchCollections = async () => {
    try {
      const fetchedCollections = await getAllCollections();
      setCollections(fetchedCollections);
      
      // Build hierarchical structure
      const collectionMap = new Map<string, CollectionWithChildren>();
      const rootCollections: CollectionWithChildren[] = [];
      
      // First pass: create map
      fetchedCollections.forEach(col => {
        collectionMap.set(col.id, { ...col, children: [], level: 0 });
      });
      
      // Second pass: build tree
      fetchedCollections.forEach(col => {
        const collectionWithChildren = collectionMap.get(col.id)!;
        if (col.parentCollection) {
          const parent = collectionMap.get(col.parentCollection);
          if (parent) {
            collectionWithChildren.level = (parent.level || 0) + 1;
            if (!parent.children) parent.children = [];
            parent.children.push(collectionWithChildren);
          } else {
            rootCollections.push(collectionWithChildren);
          }
        } else {
          rootCollections.push(collectionWithChildren);
        }
      });
      
      setHierarchicalCollections(rootCollections);
    } catch (err) {
      setError('Failed to fetch collections.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const renderCollectionRow = (collection: CollectionWithChildren, level: number = 0): React.ReactNode => {
    const indent = level * 24;
    return (
      <React.Fragment key={collection.id}>
        <tr className="hover:bg-gray-50">
          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900" style={{ paddingLeft: `${24 + indent}px` }}>
            <div className="flex items-center gap-2">
              {level > 0 && (
                <span className="text-gray-400">└─</span>
              )}
              {collection.name}
              {collection.children && collection.children.length > 0 && (
                <span className="text-xs text-gray-400 ml-2">({collection.children.length} sub-collections)</span>
              )}
            </div>
          </td>
          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
            {collection.slug}
          </td>
          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 truncate max-w-xs">
            {collection.description || '-'}
          </td>
          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
            {collection.parentCollection ? (
              <span className="text-xs text-gray-400">Sub-collection</span>
            ) : (
              <span className="text-xs text-green-600 font-medium">Top Level</span>
            )}
          </td>
          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
            <button
              onClick={() => router.push(`/admin/collections/edit/${collection.id}`)}
              className="text-blue-600 hover:text-blue-900 mr-4"
            >
              Edit
            </button>
            <button
              onClick={() => handleDelete(collection.id)}
              className="text-red-600 hover:text-red-900"
            >
              Delete
            </button>
          </td>
        </tr>
        {collection.children && collection.children.map(child => renderCollectionRow(child, level + 1))}
      </React.Fragment>
    );
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this collection?')) {
      try {
        await deleteCollection(id);
        setCollections(collections.filter(collection => collection.id !== id));
        fetchCollections(); // Refresh to update tree
      } catch (err) {
        setError('Failed to delete collection.');
        console.error(err);
      }
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Collections</h1>
          <p className="text-gray-500 text-sm mt-1">Manage product collections and sub-collections</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setViewMode('tree')}
              className={`px-3 py-1.5 text-sm font-medium rounded transition-colors ${
                viewMode === 'tree' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-600'
              }`}
            >
              Tree View
            </button>
            <button
              onClick={() => setViewMode('flat')}
              className={`px-3 py-1.5 text-sm font-medium rounded transition-colors ${
                viewMode === 'flat' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-600'
              }`}
            >
              Flat View
            </button>
          </div>
          <Link
            href="/admin/collections/new"
            className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
            </svg>
            Add Collection
          </Link>
        </div>
      </div>

      {error && <div className="text-red-500 bg-red-50 p-4 rounded-lg mb-4">{error}</div>}

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        {collections.length === 0 ? (
          <div className="p-8 text-center text-gray-500">No collections found.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Slug</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {viewMode === 'tree' ? (
                  hierarchicalCollections.map(collection => renderCollectionRow(collection, 0))
                ) : (
                  collections.map((collection) => {
                    const parentName = collections.find(c => c.id === collection.parentCollection)?.name;
                    return (
                      <tr key={collection.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {collection.name}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {collection.slug}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 truncate max-w-xs">
                          {collection.description || '-'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {parentName ? (
                            <span className="text-xs text-gray-600">Sub of: {parentName}</span>
                          ) : (
                            <span className="text-xs text-green-600 font-medium">Top Level</span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <button
                            onClick={() => router.push(`/admin/collections/edit/${collection.id}`)}
                            className="text-blue-600 hover:text-blue-900 mr-4"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => handleDelete(collection.id)}
                            className="text-red-600 hover:text-red-900"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default CollectionList;

