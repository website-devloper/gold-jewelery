'use client';

import React, { useEffect, useState } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Sidebar from '../../components/admin/Sidebar';
import { onAdminAuthStateChanged } from '@/lib/auth';
import { useLanguage } from '../../context/LanguageContext';

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { t } = useLanguage();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    const unsubscribe = onAdminAuthStateChanged((user, isAdmin) => {
      if (user && isAdmin) {
        setIsAuthenticated(true);
      } else {
        setIsAuthenticated(false);
        router.push('/login?returnUrl=/admin');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [router, pathname]);

  // Handle loading state
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 mx-auto mb-4"></div>
          <p className="text-gray-600">{t('admin.loading') || 'Loading Admin Panel...'}</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect in useEffect
  }

  return (
    <div className="flex min-h-screen bg-gray-100">
      <Sidebar />
      <main className="flex-1 overflow-y-auto h-screen">
        <div className="p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
