'use client';

import React, { useState } from 'react';
import { getAuth, onAuthStateChanged, User } from 'firebase/auth';
import { app } from '@/lib/firebase';
import { exportCustomersToCSV, importCustomersFromCSV } from '@/lib/firestore/customer_management_db';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

const CustomerImportExportPage = () => {
  const [, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<{ success: number; errors: string[] } | null>(null);
  const router = useRouter();
  const auth = getAuth(app);

  React.useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
      } else {
        router.push('/login');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [auth, router]);

  const handleExport = async () => {
    setExporting(true);
    try {
      const csv = await exportCustomersToCSV();
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `customers-export-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error exporting:', error);
      alert('Failed to export customers.');
    } finally {
      setExporting(false);
    }
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImporting(true);
    try {
      const text = await file.text();
      const result = await importCustomersFromCSV(text);
      setImportResult(result);
      if (result.errors.length > 0) {
        alert(`Import completed with ${result.success} successes and ${result.errors.length} errors.`);
      } else {
        alert(`Successfully imported ${result.success} customers.`);
      }
    } catch (error) {
      console.error('Error importing:', error);
      alert('Failed to import customers.');
    } finally {
      setImporting(false);
      e.target.value = ''; // Reset input
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 max-w-4xl py-12">
      <div className="mb-6">
        <Link
          href="/admin/customers"
          className="text-gray-500 hover:text-gray-700 flex items-center gap-1 text-sm font-medium"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
            <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
          </svg>
          Back to Customers
        </Link>
      </div>

      <h1 className="text-4xl font-serif font-bold mb-8">Import/Export Customers</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Export */}
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
          <h2 className="text-xl font-bold mb-4">Export Customers</h2>
          <p className="text-sm text-gray-600 mb-4">
            Export all customer data to a CSV file for backup or analysis.
          </p>
          <button
            onClick={handleExport}
            disabled={exporting}
            className="w-full bg-black text-white px-6 py-3 rounded-lg font-bold hover:bg-gray-800 transition-colors disabled:opacity-70"
          >
            {exporting ? 'Exporting...' : 'Export to CSV'}
          </button>
        </div>

        {/* Import */}
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
          <h2 className="text-xl font-bold mb-4">Import Customers</h2>
          <p className="text-sm text-gray-600 mb-4">
            Import customers from a CSV file. Make sure the CSV matches the export format.
          </p>
          <label className="block">
            <input
              type="file"
              accept=".csv"
              onChange={handleImport}
              disabled={importing}
              className="hidden"
            />
            <div className="w-full bg-gray-100 border-2 border-dashed border-gray-300 rounded-lg p-6 text-center cursor-pointer hover:border-gray-400 transition-colors">
              {importing ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-black"></div>
                  <span>Importing...</span>
                </div>
              ) : (
                <>
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 text-gray-400 mx-auto mb-2">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5m-13.5-9L12 3m0 0 4.5 4.5M12 3v13.5" />
                  </svg>
                  <p className="text-sm font-medium text-gray-700">Click to upload CSV</p>
                  <p className="text-xs text-gray-500 mt-1">or drag and drop</p>
                </>
              )}
            </div>
          </label>
        </div>
      </div>

      {importResult && (
        <div className="mt-6 bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
          <h3 className="text-lg font-bold mb-4">Import Results</h3>
          <div className="space-y-2">
            <p className="text-green-600 font-medium">Successfully imported: {importResult.success} customers</p>
            {importResult.errors.length > 0 && (
              <div>
                <p className="text-red-600 font-medium mb-2">Errors ({importResult.errors.length}):</p>
                <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                  {importResult.errors.map((error, idx) => (
                    <li key={idx}>{error}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      )}

      {/* CSV Format Guide */}
      <div className="mt-6 bg-gray-50 p-6 rounded-2xl border border-gray-200">
        <h3 className="text-lg font-bold mb-4">CSV Format</h3>
        <p className="text-sm text-gray-600 mb-2">The CSV file should have the following columns:</p>
        <code className="block bg-white p-3 rounded border border-gray-300 text-xs font-mono">
          Email, Name, Phone, Total Orders, Total Spent, Last Order Date, Created Date, Wallet Balance, Loyalty Points
        </code>
      </div>
    </div>
  );
};

export default CustomerImportExportPage;

