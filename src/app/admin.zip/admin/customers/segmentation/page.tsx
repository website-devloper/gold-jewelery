'use client';

import React, { useState, useEffect } from 'react';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { app } from '@/lib/firebase';
import { getAllUsers } from '@/lib/firestore/users';
import { segmentAllCustomers } from '@/lib/firestore/customer_management_db';
import { CustomerSegment } from '@/lib/firestore/customer_management';
import { UserProfile } from '@/lib/firestore/users';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useLanguage } from '@/context/LanguageContext';

const CustomerSegmentationPage = () => {
  const { t } = useLanguage();
  const [customers, setCustomers] = useState<UserProfile[]>([]);
  const [segments, setSegments] = useState<{ [userId: string]: CustomerSegment }>({});
  const [loading, setLoading] = useState(true);
  const [selectedSegment, setSelectedSegment] = useState<CustomerSegment | 'all'>('all');
  const router = useRouter();
  const auth = getAuth(app);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        try {
          const fetchedCustomers = await getAllUsers();
          setCustomers(fetchedCustomers.filter(c => c.role !== 'admin'));
          
          const customerSegments = await segmentAllCustomers();
          setSegments(customerSegments);
        } catch (error) {
          console.error('Error fetching data:', error);
        }
      } else {
        router.push('/login');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [auth, router]);

  const filteredCustomers = selectedSegment === 'all'
    ? customers
    : customers.filter(c => segments[c.uid] === selectedSegment);

  const segmentCounts = Object.values(segments).reduce((acc, segment) => {
    acc[segment] = (acc[segment] || 0) + 1;
    return acc;
  }, {} as { [key: string]: number });

  const getSegmentColor = (segment: CustomerSegment) => {
    switch (segment) {
      case CustomerSegment.VIP:
        return 'bg-purple-100 text-purple-800';
      case CustomerSegment.HighValue:
        return 'bg-blue-100 text-blue-800';
      case CustomerSegment.Frequent:
        return 'bg-green-100 text-green-800';
      case CustomerSegment.Regular:
        return 'bg-gray-100 text-gray-800';
      case CustomerSegment.New:
        return 'bg-yellow-100 text-yellow-800';
      case CustomerSegment.Inactive:
        return 'bg-red-100 text-red-800';
      case CustomerSegment.OneTime:
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 max-w-7xl py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-serif font-bold">
          {t('admin.customer_segmentation') || 'Customer Segmentation'}
        </h1>
        <button
          onClick={async () => {
            const customerSegments = await segmentAllCustomers();
            setSegments(customerSegments);
          }}
          className="bg-black text-white px-6 py-3 rounded-xl font-bold hover:bg-gray-800 transition-colors"
        >
          {t('admin.resend_segmentation') || 'Re-segment Customers'}
        </button>
      </div>

      {/* Segment Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-8">
        <button
          onClick={() => setSelectedSegment('all')}
          className={`p-4 rounded-lg border-2 transition-colors ${
            selectedSegment === 'all'
              ? 'border-black bg-black text-white'
              : 'border-gray-200 bg-white hover:border-gray-300'
          }`}
        >
          <p className="font-bold text-lg">All</p>
          <p className="text-sm opacity-70">{customers.length}</p>
        </button>
        {Object.values(CustomerSegment).map(segment => (
          <button
            key={segment}
            onClick={() => setSelectedSegment(segment)}
            className={`p-4 rounded-lg border-2 transition-colors ${
              selectedSegment === segment
                ? 'border-black bg-black text-white'
                : 'border-gray-200 bg-white hover:border-gray-300'
            }`}
          >
            <p className="font-bold text-lg capitalize">{segment.replace('_', ' ')}</p>
            <p className="text-sm opacity-70">{segmentCounts[segment] || 0}</p>
          </button>
        ))}
      </div>

      {/* Customers List */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Customer</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Email</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Segment</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-6 py-12 text-center text-gray-500">
                    No customers found in this segment.
                  </td>
                </tr>
              ) : (
                filteredCustomers.map((customer) => (
                  <tr key={customer.uid} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="font-medium text-gray-900">{customer.displayName || customer.email || 'Customer'}</div>
                      {customer.phoneNumber && (
                        <div className="text-sm text-gray-500">{customer.phoneNumber}</div>
                      )}
                    </td>
                    <td className="px-6 py-4 text-gray-600">{customer.email}</td>
                    <td className="px-6 py-4">
                      {segments[customer.uid] && (
                        <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${getSegmentColor(segments[customer.uid])}`}>
                          {segments[customer.uid].replace('_', ' ')}
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <Link
                        href={`/admin/customers/${customer.uid}`}
                        className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                      >
                        View Details
                      </Link>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default CustomerSegmentationPage;

