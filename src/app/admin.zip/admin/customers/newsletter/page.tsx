'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { getAllNewsletterSubscriptions, unsubscribeNewsletter } from '@/lib/firestore/newsletter_db';
import { NewsletterSubscription } from '@/lib/firestore/newsletter_db';

const NewsletterPage = () => {
  const [, setUser] = useState<User | null>(null);
  const [subscriptions, setSubscriptions] = useState<NewsletterSubscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'active' | 'unsubscribed'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const loadSubscriptions = useCallback(async () => {
    try {
      const allSubscriptions = await getAllNewsletterSubscriptions();
      setSubscriptions(allSubscriptions);
    } catch (error) {
      console.error('Error loading newsletter subscriptions:', error);
      alert('Failed to load newsletter subscriptions.');
    }
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        await loadSubscriptions();
      } else {
        window.location.href = '/login?returnUrl=/admin/customers/newsletter';
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [loadSubscriptions]);

  const handleUnsubscribe = async (email: string) => {
    if (!confirm(`Are you sure you want to unsubscribe ${email}?`)) {
      return;
    }
    
    try {
      await unsubscribeNewsletter(email);
      await loadSubscriptions();
      alert('Unsubscribed successfully.');
    } catch (error) {
      console.error('Error unsubscribing:', error);
      alert('Failed to unsubscribe.');
    }
  };

  const filteredSubscriptions = subscriptions.filter(sub => {
    const matchesFilter = filter === 'all' || sub.status === filter;
    const matchesSearch = searchQuery === '' || 
      sub.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (sub.source && sub.source.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesFilter && matchesSearch;
  });

  const activeCount = subscriptions.filter(s => s.status === 'active').length;
  const unsubscribedCount = subscriptions.filter(s => s.status === 'unsubscribed').length;

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Newsletter Subscriptions</h1>
            <p className="text-gray-500 text-sm mt-1">Manage newsletter email subscriptions</p>
          </div>
          <div className="flex items-center gap-4 text-sm">
            <div className="text-center">
              <p className="font-bold text-gray-900">{activeCount}</p>
              <p className="text-gray-500">Active</p>
            </div>
            <div className="text-center">
              <p className="font-bold text-gray-900">{unsubscribedCount}</p>
              <p className="text-gray-500">Unsubscribed</p>
            </div>
            <div className="text-center">
              <p className="font-bold text-gray-900">{subscriptions.length}</p>
              <p className="text-gray-500">Total</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1">
            <input
              type="text"
              placeholder="Search by email or source..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
            />
          </div>
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value as 'all' | 'active' | 'unsubscribed')}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
          >
            <option value="all">All Subscriptions</option>
            <option value="active">Active Only</option>
            <option value="unsubscribed">Unsubscribed Only</option>
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Source</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subscribed</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredSubscriptions.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-gray-500">
                    No subscriptions found
                  </td>
                </tr>
              ) : (
                filteredSubscriptions.map((subscription) => (
                  <tr key={subscription.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{subscription.email}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`px-2 py-1 text-xs rounded-full ${
                          subscription.status === 'active'
                            ? 'bg-green-100 text-green-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}
                      >
                        {subscription.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">{subscription.source || 'Unknown'}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">
                        {subscription.subscribedAt && typeof subscription.subscribedAt.toDate === 'function'
                          ? new Date(subscription.subscribedAt.toDate()).toLocaleDateString()
                          : 'Unknown'}
                      </div>
                      {subscription.unsubscribedAt && (
                        <div className="text-xs text-gray-400">
                          Unsubscribed: {typeof subscription.unsubscribedAt.toDate === 'function'
                            ? new Date(subscription.unsubscribedAt.toDate()).toLocaleDateString()
                            : 'Unknown'}
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      {subscription.status === 'active' && (
                        <button
                          onClick={() => handleUnsubscribe(subscription.email)}
                          className="text-red-600 hover:text-red-800 font-medium"
                        >
                          Unsubscribe
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default NewsletterPage;

