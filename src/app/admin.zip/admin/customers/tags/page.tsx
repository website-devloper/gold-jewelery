'use client';

import React, { useState, useEffect } from 'react';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { app } from '@/lib/firebase';
import { getAllCustomerTags, addCustomerTag, updateCustomerTag, deleteCustomerTag } from '@/lib/firestore/customer_management_db';
import { CustomerTag } from '@/lib/firestore/customer_management';
import { useRouter } from 'next/navigation';

const CustomerTagsPage = () => {
  const [tags, setTags] = useState<CustomerTag[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingTag, setEditingTag] = useState<CustomerTag | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    color: '#000000',
    description: '',
  });
  const router = useRouter();
  const auth = getAuth(app);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        try {
          const fetchedTags = await getAllCustomerTags();
          setTags(fetchedTags);
        } catch (error) {
          console.error('Error fetching tags:', error);
        }
      } else {
        router.push('/login');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [auth, router]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    try {
      if (editingTag) {
        await updateCustomerTag(editingTag.id!, formData);
      } else {
        await addCustomerTag(formData);
      }
      const fetchedTags = await getAllCustomerTags();
      setTags(fetchedTags);
      setShowForm(false);
      setEditingTag(null);
      setFormData({ name: '', color: '#000000', description: '' });
    } catch (error) {
      console.error('Error saving tag:', error);
      alert('Failed to save tag.');
    }
  };

  const handleEdit = (tag: CustomerTag) => {
    setEditingTag(tag);
    setFormData({
      name: tag.name,
      color: tag.color || '#000000',
      description: tag.description || '',
    });
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this tag?')) return;
    try {
      await deleteCustomerTag(id);
      setTags(tags.filter(t => t.id !== id));
    } catch (error) {
      console.error('Error deleting tag:', error);
      alert('Failed to delete tag.');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 max-w-4xl py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-serif font-bold">Customer Tags</h1>
        <button
          onClick={() => {
            setShowForm(true);
            setEditingTag(null);
            setFormData({ name: '', color: '#000000', description: '' });
          }}
          className="bg-black text-white px-6 py-3 rounded-xl font-bold hover:bg-gray-800 transition-colors"
        >
          Add Tag
        </button>
      </div>

      {showForm && (
        <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm mb-6">
          <h2 className="text-xl font-bold mb-4">{editingTag ? 'Edit' : 'Add'} Tag</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Tag Name *</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Color</label>
              <div className="flex gap-4 items-center">
                <input
                  type="color"
                  value={formData.color}
                  onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                  className="w-16 h-10 border border-gray-300 rounded"
                />
                <input
                  type="text"
                  value={formData.color}
                  onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none font-mono"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Description</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
              />
            </div>
            <div className="flex gap-4">
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditingTag(null);
                  setFormData({ name: '', color: '#000000', description: '' });
                }}
                className="flex-1 px-6 py-3 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 px-6 py-3 bg-black text-white rounded-lg font-bold hover:bg-gray-800 transition-colors"
              >
                {editingTag ? 'Update' : 'Create'} Tag
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-6">
          {tags.length === 0 ? (
            <div className="col-span-full text-center py-12 text-gray-500">
              No tags found. Create your first tag to get started.
            </div>
          ) : (
            tags.map((tag) => (
              <div key={tag.id} className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-4 h-4 rounded"
                      style={{ backgroundColor: tag.color || '#000000' }}
                    />
                    <h3 className="font-bold text-gray-900">{tag.name}</h3>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleEdit(tag)}
                      className="text-blue-600 hover:text-blue-800 text-sm"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => tag.id && handleDelete(tag.id)}
                      className="text-red-600 hover:text-red-800 text-sm"
                    >
                      Delete
                    </button>
                  </div>
                </div>
                {tag.description && (
                  <p className="text-sm text-gray-500">{tag.description}</p>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default CustomerTagsPage;

