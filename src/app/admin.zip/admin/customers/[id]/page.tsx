'use client';

import React, { useState, useEffect } from 'react';
import { getAuth, onAuthStateChanged, User } from 'firebase/auth';
import { app } from '@/lib/firebase';
import { getUserProfile } from '@/lib/firestore/users';
import { getCustomerNotes, addCustomerNote, deleteCustomerNote } from '@/lib/firestore/customer_management_db';
import { getCustomerCommunications } from '@/lib/firestore/customer_management_db';
import { calculateCustomerLifetimeValue } from '@/lib/firestore/customer_management_db';
import { getAllCustomerTags, addTagToCustomer, removeTagFromCustomer } from '@/lib/firestore/customer_management_db';
import { getOrdersByUserId } from '@/lib/firestore/orders_db';
import { Order } from '@/lib/firestore/orders';
import { CustomerNote, CustomerTag, CustomerLifetimeValue, CustomerCommunication } from '@/lib/firestore/customer_management';
import { UserProfile } from '@/lib/firestore/users';
import { useRouter, useParams } from 'next/navigation';
import Link from 'next/link';

const CustomerDetailPage = () => {
  const [user, setUser] = useState<User | null>(null);
  const [customer, setCustomer] = useState<UserProfile | null>(null);
  const [notes, setNotes] = useState<CustomerNote[]>([]);
  const [communications, setCommunications] = useState<CustomerCommunication[]>([]);
  const [clv, setClv] = useState<CustomerLifetimeValue | null>(null);
  const [tags, setTags] = useState<CustomerTag[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'notes' | 'communications' | 'orders'>('overview');
  const [newNote, setNewNote] = useState('');
  const [isPrivateNote, setIsPrivateNote] = useState(false);
  const router = useRouter();
  const params = useParams();
  const customerId = params?.id as string;
  const auth = getAuth(app);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        try {
          const [customerData, notesData, commsData, clvData, tagsData] = await Promise.all([
            getUserProfile(customerId),
            getCustomerNotes(customerId, false, currentUser.uid),
            getCustomerCommunications(customerId),
            calculateCustomerLifetimeValue(customerId),
            getAllCustomerTags(),
          ]);
          
          setCustomer(customerData);
          setNotes(notesData);
          setCommunications(commsData);
          setClv(clvData);
          setTags(tagsData);
        } catch (error) {
          console.error('Error fetching customer data:', error);
          router.push('/admin/customers');
        }
      } else {
        router.push('/login');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [auth, router, customerId]);

  const handleAddNote = async () => {
    if (!user || !newNote.trim()) return;

    try {
      await addCustomerNote({
        userId: customerId,
        note: newNote.trim(),
        createdBy: user.uid,
        createdByName: user.displayName || user.email || 'Admin',
        isPrivate: isPrivateNote,
      });
      setNewNote('');
      setIsPrivateNote(false);
      const updatedNotes = await getCustomerNotes(customerId, false, user.uid);
      setNotes(updatedNotes);
    } catch (error) {
      console.error('Error adding note:', error);
      alert('Failed to add note.');
    }
  };

  const handleDeleteNote = async (noteId: string) => {
    if (!window.confirm('Are you sure you want to delete this note?')) return;
    try {
      await deleteCustomerNote(noteId);
      if (user) {
        const updatedNotes = await getCustomerNotes(customerId, false, user.uid);
        setNotes(updatedNotes);
      }
    } catch (error) {
      console.error('Error deleting note:', error);
      alert('Failed to delete note.');
    }
  };

  const handleToggleTag = async (tagId: string, isTagged: boolean) => {
    try {
      if (isTagged) {
        await removeTagFromCustomer(customerId, tagId);
      } else {
        await addTagToCustomer(customerId, tagId);
      }
      // Refresh customer data
      const customerData = await getUserProfile(customerId);
      setCustomer(customerData);
    } catch (error) {
      console.error('Error updating tag:', error);
      alert('Failed to update tag.');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  if (!customer) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Customer not found</h1>
          <Link href="/admin/customers" className="text-blue-600 hover:underline">
            Back to Customers
          </Link>
        </div>
      </div>
    );
  }

  // Get customer's tag IDs from user document (tags are stored as array of tag IDs)
  const customerTagIds = ((customer as UserProfile & { tags?: string[] })?.tags) || [];
  const customerTags = tags.filter(tag => tag.id && customerTagIds.includes(tag.id));

  return (
    <div className="container mx-auto p-4 max-w-7xl py-12">
      <div className="mb-6">
        <Link
          href="/admin/customers"
          className="text-gray-500 hover:text-gray-700 flex items-center gap-1 text-sm font-medium"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
            <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
          </svg>
          Back to Customers
        </Link>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 mb-6">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h1 className="text-3xl font-serif font-bold mb-2">{customer.displayName || customer.email || 'Customer'}</h1>
            <p className="text-gray-500">{customer.email}</p>
            {customer.phoneNumber && (
              <p className="text-gray-500">{customer.phoneNumber}</p>
            )}
          </div>
          {clv && (
            <div className="text-right">
              <p className="text-sm text-gray-500">Lifetime Value</p>
              <p className="text-2xl font-bold text-green-600">PKR {clv.totalRevenue.toLocaleString()}</p>
              <p className="text-xs text-gray-500">Predicted: PKR {clv.predictedCLV.toLocaleString()}</p>
            </div>
          )}
        </div>

        {/* Tags */}
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-gray-700 mb-2">Tags</h3>
          <div className="flex flex-wrap gap-2">
            {tags.map(tag => {
              const isTagged = customerTags.some(ct => ct.id === tag.id);
              return (
                <button
                  key={tag.id}
                  onClick={() => handleToggleTag(tag.id!, isTagged)}
                  className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                    isTagged
                      ? 'bg-black text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                  style={isTagged && tag.color ? { backgroundColor: tag.color } : {}}
                >
                  {tag.name}
                </button>
              );
            })}
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200 mb-6">
          <nav className="flex gap-4">
            {(['overview', 'notes', 'communications', 'orders'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`pb-3 px-4 font-medium text-sm transition-colors ${
                  activeTab === tab
                    ? 'border-b-2 border-black text-black'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Content */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {clv && (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500 mb-1">Total Revenue</p>
                  <p className="text-xl font-bold">PKR {clv.totalRevenue.toLocaleString()}</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500 mb-1">Total Orders</p>
                  <p className="text-xl font-bold">{clv.totalOrders}</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500 mb-1">Avg Order Value</p>
                  <p className="text-xl font-bold">PKR {clv.averageOrderValue.toLocaleString()}</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-500 mb-1">Customer Age</p>
                  <p className="text-xl font-bold">{clv.customerAge} days</p>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'notes' && (
          <div className="space-y-6">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-bold mb-3">Add Note</h3>
              <textarea
                value={newNote}
                onChange={(e) => setNewNote(e.target.value)}
                placeholder="Add a note about this customer..."
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none mb-3"
              />
              <div className="flex items-center gap-3 mb-3">
                <input
                  type="checkbox"
                  id="privateNote"
                  checked={isPrivateNote}
                  onChange={(e) => setIsPrivateNote(e.target.checked)}
                  className="w-4 h-4"
                />
                <label htmlFor="privateNote" className="text-sm text-gray-600">Private note (only visible to me)</label>
              </div>
              <button
                onClick={handleAddNote}
                className="bg-black text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-800 transition-colors"
              >
                Add Note
              </button>
            </div>

            <div className="space-y-4">
              {notes.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No notes yet.</p>
              ) : (
                notes.map(note => (
                  <div key={note.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <p className="font-medium text-gray-900">{note.createdByName}</p>
                        <p className="text-xs text-gray-500">
                          {new Date(note.createdAt.seconds * 1000).toLocaleString()}
                          {note.isPrivate && <span className="ml-2 text-orange-600">(Private)</span>}
                        </p>
                      </div>
                      {note.createdBy === user?.uid && (
                        <button
                          onClick={() => note.id && handleDeleteNote(note.id)}
                          className="text-red-600 hover:text-red-800 text-sm"
                        >
                          Delete
                        </button>
                      )}
                    </div>
                    <p className="text-gray-700">{note.note}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {activeTab === 'communications' && (
          <div className="space-y-4">
            {communications.length === 0 ? (
              <p className="text-gray-500 text-center py-8">No communications yet.</p>
            ) : (
              communications.map(comm => (
                <div key={comm.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-medium rounded capitalize">
                        {comm.type}
                      </span>
                      <span className={`ml-2 px-2 py-1 text-xs font-medium rounded ${
                        comm.direction === 'inbound' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {comm.direction}
                      </span>
                    </div>
                    <span className="text-xs text-gray-500">
                      {new Date(comm.createdAt.seconds * 1000).toLocaleString()}
                    </span>
                  </div>
                  {comm.subject && (
                    <p className="font-medium text-gray-900 mb-1">{comm.subject}</p>
                  )}
                  <p className="text-gray-700">{comm.message}</p>
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'orders' && (
          <CustomerOrdersTab customerId={customerId} />
        )}
      </div>
    </div>
  );
};

const CustomerOrdersTab = ({ customerId }: { customerId: string }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const customerOrders = await getOrdersByUserId(customerId);
        setOrders(customerOrders);
      } catch (error) {
        console.error('Error fetching orders:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchOrders();
  }, [customerId]);

  if (loading) {
    return <div className="text-center py-8">Loading orders...</div>;
  }

  return (
    <div>
      {orders.length === 0 ? (
        <p className="text-gray-500 text-center py-8">No orders yet.</p>
      ) : (
        <div className="space-y-4">
          {orders.map(order => (
            <div key={order.id} className="border border-gray-200 rounded-lg p-4">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="font-medium text-gray-900">Order #{order.id?.slice(0, 8)}</p>
                  <p className="text-sm text-gray-500">
                    {new Date(order.createdAt.seconds * 1000).toLocaleDateString()}
                  </p>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                  order.status === 'delivered' ? 'bg-green-100 text-green-800' : 
                  order.status === 'cancelled' ? 'bg-red-100 text-red-800' : 
                  'bg-yellow-100 text-yellow-800'
                }`}>
                  {order.status}
                </span>
              </div>
              <p className="text-gray-900 font-medium">PKR {order.totalAmount.toLocaleString()}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CustomerDetailPage;

