'use client';

import React, { useState, useEffect } from 'react';
import { getAuth, onAuthStateChanged, User } from 'firebase/auth';
import { app } from '@/lib/firebase';
import { getAllStaffMembers, deleteStaffMember, updateStaffMember } from '@/lib/firestore/user_management_db';
import { StaffMember, AdminRole } from '@/lib/firestore/user_management';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useLanguage } from '@/context/LanguageContext';

const StaffPage = () => {
  const { t } = useLanguage();
  const [, setUser] = useState<User | null>(null);
  const [staffMembers, setStaffMembers] = useState<StaffMember[]>([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const auth = getAuth(app);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        try {
          const fetchedStaff = await getAllStaffMembers();
          setStaffMembers(fetchedStaff);
        } catch (error) {
          console.error('Error fetching staff:', error);
        }
      } else {
        router.push('/login');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [auth, router]);

  const handleToggleActive = async (id: string, currentStatus: boolean) => {
    try {
      await updateStaffMember(id, { isActive: !currentStatus });
      setStaffMembers(staffMembers.map(s => s.id === id ? { ...s, isActive: !currentStatus } : s));
    } catch (error) {
      console.error('Error updating staff:', error);
      alert('Failed to update staff member.');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this staff member?')) return;
    try {
      await deleteStaffMember(id);
      setStaffMembers(staffMembers.filter(s => s.id !== id));
    } catch (error) {
      console.error('Error deleting staff:', error);
      alert('Failed to delete staff member.');
    }
  };

  const getRoleBadgeColor = (role: AdminRole) => {
    switch (role) {
      case AdminRole.SuperAdmin:
        return 'bg-red-100 text-red-800';
      case AdminRole.Admin:
        return 'bg-purple-100 text-purple-800';
      case AdminRole.Manager:
        return 'bg-blue-100 text-blue-800';
      case AdminRole.Staff:
        return 'bg-green-100 text-green-800';
      case AdminRole.Viewer:
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 max-w-7xl py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-serif font-bold">
          {t('admin.staff_management') || 'Staff Management'}
        </h1>
        <Link
          href="/admin/staff/new"
          className="bg-black text-white px-6 py-3 rounded-xl font-bold hover:bg-gray-800 transition-colors"
        >
          {t('admin.add_staff_member') || 'Add Staff Member'}
        </Link>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Name</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Email</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Role</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Status</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Last Login</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {staffMembers.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                  No staff members found. Add your first staff member to get started.
                </td>
              </tr>
            ) : (
              staffMembers.map((staff) => (
                <tr key={staff.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="font-medium text-gray-900">{staff.displayName}</div>
                    {staff.phoneNumber && (
                      <div className="text-sm text-gray-500">{staff.phoneNumber}</div>
                    )}
                  </td>
                  <td className="px-6 py-4 text-gray-600">{staff.email}</td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${getRoleBadgeColor(staff.role)}`}>
                      {staff.role.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                      staff.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {staff.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-gray-600 text-sm">
                    {staff.lastLoginAt 
                      ? new Date(staff.lastLoginAt.seconds * 1000).toLocaleDateString()
                      : 'Never'
                    }
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <Link
                        href={`/admin/staff/edit/${staff.id}`}
                        className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                      >
                        Edit
                      </Link>
                      <button
                        onClick={() => handleToggleActive(staff.id!, staff.isActive)}
                        className={`text-sm font-medium ${
                          staff.isActive ? 'text-orange-600 hover:text-orange-800' : 'text-green-600 hover:text-green-800'
                        }`}
                      >
                        {staff.isActive ? 'Deactivate' : 'Activate'}
                      </button>
                      <button
                        onClick={() => handleDelete(staff.id!)}
                        className="text-red-600 hover:text-red-800 text-sm font-medium"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default StaffPage;

