'use client';

import React, { useState, useEffect } from 'react';
import { getAuth, onAuthStateChanged, User, createUserWithEmailAndPassword } from 'firebase/auth';
import { app } from '@/lib/firebase';
import { addStaffMember } from '@/lib/firestore/user_management_db';
import { AdminRole } from '@/lib/firestore/user_management';
import { setDoc, doc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useLanguage } from '@/context/LanguageContext';

const NewStaffPage = () => {
  const { t } = useLanguage();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const router = useRouter();
  const auth = getAuth(app);

  const [staff, setStaff] = useState({
    email: '',
    password: '',
    displayName: '',
    phoneNumber: '',
    role: AdminRole.Staff,
    isActive: true,
  });

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
      } else {
        router.push('/login');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [auth, router]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setStaff(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setSaving(true);
    try {
      // Create Firebase Auth user
      const userCredential = await createUserWithEmailAndPassword(auth, staff.email, staff.password);
      const newUser = userCredential.user;

      // Create user document in Firestore
      await setDoc(doc(db, 'users', newUser.uid), {
        uid: newUser.uid,
        email: newUser.email,
        displayName: staff.displayName,
        isAdmin: true, // Mark as admin
        role: staff.role,
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      // Create staff member record
      await addStaffMember({
        uid: newUser.uid,
        email: staff.email,
        displayName: staff.displayName,
        phoneNumber: staff.phoneNumber || undefined,
        role: staff.role as AdminRole,
        isActive: staff.isActive,
        createdBy: user.uid,
      });

      router.push('/admin/staff');
    } catch (error: unknown) {
      console.error('Error creating staff:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to create staff member.';
      alert(errorMessage);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 max-w-2xl py-12">
      <div className="mb-6">
        <Link
          href="/admin/staff"
          className="text-gray-500 hover:text-gray-700 flex items-center gap-1 text-sm font-medium"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
            <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
          </svg>
          Back to Staff
        </Link>
      </div>

      <h1 className="text-4xl font-serif font-bold mb-8">
        {t('admin.add_staff_member') || 'Add Staff Member'}
      </h1>

      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm space-y-6">
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">Email *</label>
          <input
            type="email"
            name="email"
            value={staff.email}
            onChange={handleChange}
            required
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">Password *</label>
          <input
            type="password"
            name="password"
            value={staff.password}
            onChange={handleChange}
            required
            minLength={6}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">Display Name *</label>
          <input
            type="text"
            name="displayName"
            value={staff.displayName}
            onChange={handleChange}
            required
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">Phone Number</label>
          <input
            type="tel"
            name="phoneNumber"
            value={staff.phoneNumber}
            onChange={handleChange}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">Role *</label>
          <select
            name="role"
            value={staff.role}
            onChange={handleChange}
            required
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black outline-none"
          >
            <option value={AdminRole.SuperAdmin}>Super Admin</option>
            <option value={AdminRole.Admin}>Admin</option>
            <option value={AdminRole.Manager}>Manager</option>
            <option value={AdminRole.Staff}>Staff</option>
            <option value={AdminRole.Viewer}>Viewer</option>
          </select>
        </div>

        <div className="flex items-center gap-3">
          <input
            type="checkbox"
            name="isActive"
            checked={staff.isActive}
            onChange={handleChange}
            className="w-5 h-5"
          />
          <label className="text-sm text-gray-700">Active</label>
        </div>

        <div className="flex gap-4 pt-4">
          <button
            type="button"
            onClick={() => router.push('/admin/staff')}
            className="flex-1 px-6 py-3 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="flex-1 px-6 py-3 bg-black text-white rounded-lg font-bold hover:bg-gray-800 transition-colors disabled:opacity-70"
          >
            {saving ? 'Creating...' : 'Create Staff Member'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default NewStaffPage;

