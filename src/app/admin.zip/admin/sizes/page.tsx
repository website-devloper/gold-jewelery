'use client';

import React, { useState, useEffect } from 'react';
import { getSizes, addSize, updateSize, deleteSize } from '@/lib/firestore/attributes_db';
import { Size, SizeTranslation } from '@/lib/firestore/attributes';
import { getAllLanguages } from '@/lib/firestore/internationalization_db';
import { Language } from '@/lib/firestore/internationalization';
import { Timestamp } from 'firebase/firestore';
import { useLanguage } from '@/context/LanguageContext';

const SizesPage = () => {
  const [sizes, setSizes] = useState<Size[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [languages, setLanguages] = useState<Language[]>([]);
  const [selectedLanguageCode, setSelectedLanguageCode] = useState<string>('en');
  const [translations, setTranslations] = useState<SizeTranslation[]>([]);
  const { currentLanguage } = useLanguage();
  
  // Form State
  const [formData, setFormData] = useState<Partial<Size>>({
    name: '',
    code: '',
    order: 0
  });

  const fetchSizes = React.useCallback(async () => {
    setLoading(true);
    const data = await getSizes();
    setSizes(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    // Load languages
    getAllLanguages(false).then(setLanguages).catch(console.error);
  }, []);

  useEffect(() => {
    // Fetch sizes on mount and when fetchSizes changes
    fetchSizes();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const defaultLang = currentLanguage?.code || 'en';
    if (defaultLang !== selectedLanguageCode) {
      setSelectedLanguageCode(defaultLang);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentLanguage?.code]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // Save current translation if editing a specific language
      const finalTranslations = [...translations];
      if (selectedLanguageCode !== 'en') {
        const existingIndex = finalTranslations.findIndex((t: SizeTranslation) => t.languageCode === selectedLanguageCode);
        const currentTranslation: SizeTranslation = {
          languageCode: selectedLanguageCode,
          name: formData.name || '',
          updatedAt: Timestamp.now()
        };
        if (existingIndex >= 0) {
          finalTranslations[existingIndex] = currentTranslation;
        } else {
          finalTranslations.push(currentTranslation);
        }
      }

      const sizeData: Partial<Size> & { translations?: SizeTranslation[] } = { ...formData };
      if (finalTranslations.length > 0) {
        sizeData.translations = finalTranslations;
      }

      if (editingId) {
        await updateSize(editingId, sizeData);
      } else {
        await addSize(sizeData as Size);
      }
      setIsModalOpen(false);
      resetForm();
      fetchSizes();
    } catch (error) {
      console.error('Error saving size:', error);
      alert('Failed to save size');
    }
  };

  const handleEdit = (size: Size) => {
    setEditingId(size.id!);
    setFormData({
      name: size.name,
      code: size.code,
      order: size.order
    });
    
    // Load translations
    const sizeTranslations = (size as Size & { translations?: SizeTranslation[] }).translations;
    if (sizeTranslations && sizeTranslations.length > 0) {
      setTranslations(sizeTranslations);
      const defaultLang = sizeTranslations.find((t: SizeTranslation) => t.languageCode === currentLanguage?.code) 
        || sizeTranslations.find((t: SizeTranslation) => t.languageCode === 'en')
        || sizeTranslations[0];
      if (defaultLang) {
        setSelectedLanguageCode(defaultLang.languageCode);
        setFormData(prev => ({
          ...prev,
          name: defaultLang.name || prev.name
        }));
      }
    } else {
      setTranslations([]);
      setSelectedLanguageCode(currentLanguage?.code || 'en');
    }
    
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this size?')) {
      await deleteSize(id);
      fetchSizes();
    }
  };

  const resetForm = () => {
    setEditingId(null);
    setFormData({
      name: '',
      code: '',
      order: sizes.length + 1
    });
    setTranslations([]);
    setSelectedLanguageCode(currentLanguage?.code || 'en');
  };

  const handleLanguageChange = (languageCode: string) => {
    setSelectedLanguageCode(languageCode);
    const translation = translations.find((t: SizeTranslation) => t.languageCode === languageCode);
    if (translation) {
      setFormData(prev => ({
        ...prev,
        name: translation.name || prev.name
      }));
    } else if (languageCode === 'en') {
      // Reset to default name when switching to English
      const size = sizes.find(s => s.id === editingId);
      if (size) {
        setFormData(prev => ({
          ...prev,
          name: size.name
        }));
      }
    }
  };

  const handleNameChange = (value: string) => {
    setFormData(prev => ({ ...prev, name: value }));
    
    // Update translation if editing a specific language
    if (selectedLanguageCode !== 'en') {
      setTranslations((prev: SizeTranslation[]) => {
        const existing = prev.find((t: SizeTranslation) => t.languageCode === selectedLanguageCode);
        if (existing) {
          return prev.map((t: SizeTranslation) => 
            t.languageCode === selectedLanguageCode 
              ? { ...t, name: value, updatedAt: Timestamp.now() }
              : t
          );
        } else {
          return [...prev, {
            languageCode: selectedLanguageCode,
            name: value,
            updatedAt: Timestamp.now()
          }];
        }
      });
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Sizes</h1>
        <button
          onClick={() => { resetForm(); setIsModalOpen(true); }}
          className="bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition-colors flex items-center gap-2"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
          </svg>
          Add Size
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-200">
              <th className="px-6 py-4 text-sm font-semibold text-gray-700">Sort Order</th>
              <th className="px-6 py-4 text-sm font-semibold text-gray-700">Name</th>
              <th className="px-6 py-4 text-sm font-semibold text-gray-700">Code</th>
              <th className="px-6 py-4 text-sm font-semibold text-gray-700 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {loading ? (
              <tr>
                <td colSpan={4} className="px-6 py-8 text-center text-gray-500">Loading...</td>
              </tr>
            ) : sizes.length === 0 ? (
              <tr>
                <td colSpan={4} className="px-6 py-8 text-center text-gray-500">No sizes found.</td>
              </tr>
            ) : (
              sizes.map((size) => (
                <tr key={size.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm text-gray-600">{size.order}</td>
                  <td className="px-6 py-4 text-sm text-gray-900 font-medium">{size.name}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-medium bg-gray-100 text-gray-800">
                      {size.code}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right space-x-2">
                    <button 
                      onClick={() => handleEdit(size)}
                      className="text-blue-600 hover:text-blue-900 text-sm font-medium"
                    >
                      Edit
                    </button>
                    <button 
                      onClick={() => handleDelete(size.id!)}
                      className="text-red-600 hover:text-red-900 text-sm font-medium"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-6 transform transition-all max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold mb-6">{editingId ? 'Edit Size' : 'Add New Size'}</h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Language Selector */}
              {languages.length > 0 && (
                <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200">
                  <label className="block text-sm font-bold text-gray-700 mb-2">Select Language</label>
                  <div className="flex flex-wrap gap-2">
                    {languages.map((lang: Language) => {
                      const hasTranslation = translations.some((t: SizeTranslation) => t.languageCode === lang.code);
                      const isSelected = selectedLanguageCode === lang.code;
                      return (
                        <button
                          key={lang.code}
                          type="button"
                          onClick={() => handleLanguageChange(lang.code)}
                          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                            isSelected
                              ? 'bg-black text-white'
                              : hasTranslation
                              ? 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                              : 'bg-gray-50 text-gray-500 hover:bg-gray-100 border border-gray-200'
                          }`}
                        >
                          {lang.name} {lang.nativeName && `(${lang.nativeName})`}
                          {!hasTranslation && <span className="ml-1 text-xs">(New)</span>}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Size Name</label>
                <input 
                  type="text" 
                  required
                  value={formData.name}
                  onChange={(e) => handleNameChange(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                  placeholder="e.g. Medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Code</label>
                  <input 
                    type="text" 
                    required
                    value={formData.code}
                    onChange={(e) => setFormData({...formData, code: e.target.value})}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                    placeholder="e.g. M"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Sort Order</label>
                  <input 
                    type="number" 
                    required
                    value={formData.order}
                    onChange={(e) => setFormData({...formData, order: parseInt(e.target.value)})}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent outline-none"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-gray-100">
                <button 
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-black hover:bg-gray-800 rounded-lg transition-colors"
                >
                  {editingId ? 'Update Size' : 'Add Size'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default SizesPage;
