'use client';

import React, { useState, useEffect } from 'react';
import { Timestamp } from 'firebase/firestore';
import { getAllGiftCards, createGiftCard, updateGiftCard, getAllGiftCardTemplates, createGiftCardTemplate, updateGiftCardTemplate, deleteGiftCardTemplate } from '@/lib/firestore/gift_cards_db';
import { GiftCard, GiftCardTemplate } from '@/lib/firestore/gift_cards';
import { useAuth } from '../../../../context/AuthContext';

const GiftCardsPage = () => {
  const { user } = useAuth();
  const [cards, setCards] = useState<GiftCard[]>([]);
  const [templates, setTemplates] = useState<GiftCardTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'cards' | 'templates'>('cards');
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    amount: 0,
    currency: 'PKR',
    issuedTo: '',
    issuedToEmail: '',
    validFrom: '',
    validUntil: '',
  });
  const [templateFormData, setTemplateFormData] = useState({
    name: '',
    amount: 0,
    description: '',
    validDays: 365,
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [cardsData, templatesData] = await Promise.all([
        getAllGiftCards(),
        getAllGiftCardTemplates(),
      ]);
      setCards(cardsData);
      setTemplates(templatesData);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateCard = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      const now = Timestamp.now();
      const validFrom = formData.validFrom ? Timestamp.fromDate(new Date(formData.validFrom)) : now;
      const validUntil = formData.validUntil 
        ? Timestamp.fromDate(new Date(formData.validUntil)) 
        : Timestamp.fromMillis(now.toMillis() + 365 * 24 * 60 * 60 * 1000);

      const giftCardData: Omit<GiftCard, 'id' | 'code' | 'createdAt' | 'updatedAt' | 'isRedeemed' | 'usageHistory'> = {
        amount: formData.amount,
        currency: formData.currency,
        balance: formData.amount, // Initial balance equals amount
        issuedBy: user.uid,
        validFrom,
        validUntil,
        isActive: true,
        ...(formData.issuedTo && formData.issuedTo.trim() !== '' && { issuedTo: formData.issuedTo }),
        ...(formData.issuedToEmail && formData.issuedToEmail.trim() !== '' && { issuedToEmail: formData.issuedToEmail }),
      };

      await createGiftCard(giftCardData);

      setShowForm(false);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Failed to create gift card:', error);
      alert('Failed to create gift card');
    }
  };

  const handleCreateTemplate = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      await createGiftCardTemplate({
        ...templateFormData,
        isActive: true,
      });
      setShowForm(false);
      setTemplateFormData({
        name: '',
        amount: 0,
        description: '',
        validDays: 365,
      });
      fetchData();
    } catch (error) {
      console.error('Failed to create template:', error);
      alert('Failed to create template');
    }
  };

  const resetForm = () => {
    setFormData({
      amount: 0,
      currency: 'PKR',
      issuedTo: '',
      issuedToEmail: '',
      validFrom: '',
      validUntil: '',
    });
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Gift Cards</h1>
          <p className="text-gray-500 mt-1">Generate and manage gift cards</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('cards')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === 'cards' ? 'bg-black text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Gift Cards
          </button>
          <button
            onClick={() => setActiveTab('templates')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === 'templates' ? 'bg-black text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Templates
          </button>
        </div>
      </div>

      {activeTab === 'cards' && (
        <>
          <div className="flex justify-end">
            <button
              onClick={() => setShowForm(true)}
              className="bg-black text-white px-6 py-2 rounded-full text-sm font-bold uppercase tracking-widest hover:bg-gray-800 transition-colors"
            >
              + New Gift Card
            </button>
          </div>

          {showForm && (
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-xl font-bold mb-4">Create Gift Card</h2>
              <form onSubmit={handleCreateCard} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Amount</label>
                    <input
                      type="number"
                      value={formData.amount}
                      onChange={(e) => setFormData({ ...formData, amount: parseFloat(e.target.value) || 0 })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                      required
                      min="0"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Currency</label>
                    <select
                      value={formData.currency}
                      onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                    >
                      <option value="PKR">PKR</option>
                      <option value="USD">USD</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Issued To (User ID - Optional)</label>
                  <input
                    type="text"
                    value={formData.issuedTo}
                    onChange={(e) => setFormData({ ...formData, issuedTo: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Issued To Email (Optional)</label>
                  <input
                    type="email"
                    value={formData.issuedToEmail}
                    onChange={(e) => setFormData({ ...formData, issuedToEmail: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Valid From (Optional)</label>
                    <input
                      type="date"
                      value={formData.validFrom}
                      onChange={(e) => setFormData({ ...formData, validFrom: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Valid Until (Optional)</label>
                    <input
                      type="date"
                      value={formData.validUntil}
                      onChange={(e) => setFormData({ ...formData, validUntil: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                    />
                  </div>
                </div>
                <div className="flex gap-3">
                  <button
                    type="submit"
                    className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 transition-colors"
                  >
                    Create Gift Card
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowForm(false);
                      resetForm();
                    }}
                    className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Code</th>
                    <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Amount</th>
                    <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Balance</th>
                    <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Issued To</th>
                    <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Valid Until</th>
                    <th className="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {cards.map((card) => (
                    <tr key={card.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">{card.code}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{card.currency} {card.amount.toLocaleString()}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{card.currency} {card.balance.toLocaleString()}</td>
                      <td className="px-6 py-4 text-sm text-gray-500">{card.issuedToEmail || card.issuedTo || 'N/A'}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs font-bold rounded-full ${
                          card.isRedeemed ? 'bg-gray-100 text-gray-700' :
                          card.isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                        }`}>
                          {card.isRedeemed ? 'Redeemed' : card.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {card.validUntil?.toDate ? new Date(card.validUntil.toDate()).toLocaleDateString() : 'N/A'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(card.code);
                              alert('Gift card code copied to clipboard!');
                            }}
                            className="text-blue-600 hover:text-blue-900"
                            title="Copy code"
                          >
                            📋
                          </button>
                          <button
                            onClick={async () => {
                              if (confirm('Are you sure you want to deactivate this gift card?')) {
                                try {
                                  await updateGiftCard(card.id!, { isActive: !card.isActive });
                                  fetchData();
                                } catch (error) {
                                  console.error('Failed to update gift card:', error);
                                  alert('Failed to update gift card');
                                }
                              }
                            }}
                            className="text-gray-600 hover:text-gray-900"
                            title={card.isActive ? 'Deactivate' : 'Activate'}
                          >
                            {card.isActive ? '⏸️' : '▶️'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {activeTab === 'templates' && (
        <>
          <div className="flex justify-end">
            <button
              onClick={() => {
                setShowForm(true);
                setTemplateFormData({
                  name: '',
                  amount: 0,
                  description: '',
                  validDays: 365,
                });
              }}
              className="bg-black text-white px-6 py-2 rounded-full text-sm font-bold uppercase tracking-widest hover:bg-gray-800 transition-colors"
            >
              + New Template
            </button>
          </div>

          {showForm && (
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-xl font-bold mb-4">Create Gift Card Template</h2>
              <form onSubmit={handleCreateTemplate} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Template Name</label>
                  <input
                    type="text"
                    value={templateFormData.name}
                    onChange={(e) => setTemplateFormData({ ...templateFormData, name: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Amount</label>
                    <input
                      type="number"
                      value={templateFormData.amount}
                      onChange={(e) => setTemplateFormData({ ...templateFormData, amount: parseFloat(e.target.value) || 0 })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                      required
                      min="0"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Valid Days</label>
                    <input
                      type="number"
                      value={templateFormData.validDays}
                      onChange={(e) => setTemplateFormData({ ...templateFormData, validDays: parseInt(e.target.value) || 365 })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                      required
                      min="1"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <textarea
                    value={templateFormData.description}
                    onChange={(e) => setTemplateFormData({ ...templateFormData, description: e.target.value })}
                    rows={3}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  />
                </div>
                <div className="flex gap-3">
                  <button
                    type="submit"
                    className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 transition-colors"
                  >
                    Create Template
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Name</th>
                    <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Amount</th>
                    <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Valid Days</th>
                    <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {templates.map((template) => (
                    <tr key={template.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{template.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">PKR {template.amount.toLocaleString()}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{template.validDays} days</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs font-bold rounded-full ${
                          template.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                        }`}>
                          {template.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={async () => {
                              if (confirm('Are you sure you want to toggle this template status?')) {
                                try {
                                  await updateGiftCardTemplate(template.id!, { isActive: !template.isActive });
                                  fetchData();
                                } catch (error) {
                                  console.error('Failed to update template:', error);
                                  alert('Failed to update template');
                                }
                              }
                            }}
                            className="text-gray-600 hover:text-gray-900"
                            title={template.isActive ? 'Deactivate' : 'Activate'}
                          >
                            {template.isActive ? '⏸️' : '▶️'}
                          </button>
                          <button
                            onClick={async () => {
                              if (confirm('Are you sure you want to delete this template?')) {
                                try {
                                  await deleteGiftCardTemplate(template.id!);
                                  fetchData();
                                } catch (error) {
                                  console.error('Failed to delete template:', error);
                                  alert('Failed to delete template');
                                }
                              }
                            }}
                            className="text-red-600 hover:text-red-900"
                            title="Delete"
                          >
                            🗑️
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default GiftCardsPage;

