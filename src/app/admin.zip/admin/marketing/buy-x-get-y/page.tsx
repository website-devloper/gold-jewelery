'use client';

import React, { useState, useEffect } from 'react';
import { getAllBuyXGetY, createBuyXGetY, updateBuyXGetY, deleteBuyXGetY } from '@/lib/firestore/campaigns_db';
import { BuyXGetYPromotion } from '@/lib/firestore/campaigns';
import { getAllProducts } from '@/lib/firestore/products_db';
import { Product } from '@/lib/firestore/products';
import { useAuth } from '../../../../context/AuthContext';
import { Timestamp } from 'firebase/firestore';

const BuyXGetYPage = () => {
  const { user } = useAuth();
  const [promos, setPromos] = useState<BuyXGetYPromotion[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingPromo, setEditingPromo] = useState<BuyXGetYPromotion | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    buyProductIds: [] as string[],
    buyQuantity: 1,
    getProductIds: [] as string[],
    getQuantity: 1,
    getDiscountType: 'free' as 'free' | 'percentage' | 'fixed',
    getDiscountValue: 0,
    validFrom: '',
    validUntil: '',
    usageLimit: 0,
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [promosData, productsData] = await Promise.all([
        getAllBuyXGetY(),
        getAllProducts(),
      ]);
      setPromos(promosData);
      setProducts(productsData);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      const promoData = {
        name: formData.name,
        description: formData.description || undefined,
        buyProductIds: formData.buyProductIds,
        buyQuantity: formData.buyQuantity,
        getProductIds: formData.getProductIds,
        getQuantity: formData.getQuantity,
        getDiscountType: formData.getDiscountType,
        getDiscountValue: formData.getDiscountType !== 'free' ? formData.getDiscountValue : undefined,
        validFrom: Timestamp.fromDate(new Date(formData.validFrom)),
        validUntil: Timestamp.fromDate(new Date(formData.validUntil)),
        usageLimit: formData.usageLimit || undefined,
        isActive: true,
        createdBy: user.uid,
      };

      if (editingPromo) {
        await updateBuyXGetY(editingPromo.id!, promoData);
      } else {
        await createBuyXGetY(promoData);
      }

      setShowForm(false);
      setEditingPromo(null);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Failed to save promotion:', error);
      alert('Failed to save promotion');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      buyProductIds: [],
      buyQuantity: 1,
      getProductIds: [],
      getQuantity: 1,
      getDiscountType: 'free',
      getDiscountValue: 0,
      validFrom: '',
      validUntil: '',
      usageLimit: 0,
    });
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this promotion?')) return;
    try {
      await deleteBuyXGetY(id);
      fetchData();
    } catch (error) {
      console.error('Failed to delete promotion:', error);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Buy X Get Y Promotions</h1>
          <p className="text-gray-500 mt-1">Create advanced buy X get Y promotion rules</p>
        </div>
        <button
          onClick={() => {
            setShowForm(true);
            setEditingPromo(null);
            resetForm();
          }}
          className="bg-black text-white px-6 py-2 rounded-full text-sm font-bold uppercase tracking-widest hover:bg-gray-800 transition-colors"
        >
          + New Promotion
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-bold mb-4">{editingPromo ? 'Edit Promotion' : 'New Buy X Get Y Promotion'}</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Promotion Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Buy Products</label>
                <select
                  multiple
                  value={formData.buyProductIds}
                  onChange={(e) => setFormData({ ...formData, buyProductIds: Array.from(e.target.selectedOptions, option => option.value) })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent h-24"
                >
                  {products.map(product => (
                    <option key={product.id} value={product.id}>{product.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Buy Quantity (X)</label>
                <input
                  type="number"
                  value={formData.buyQuantity}
                  onChange={(e) => setFormData({ ...formData, buyQuantity: parseInt(e.target.value) || 1 })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  required
                  min="1"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Get Products</label>
                <select
                  multiple
                  value={formData.getProductIds}
                  onChange={(e) => setFormData({ ...formData, getProductIds: Array.from(e.target.selectedOptions, option => option.value) })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent h-24"
                >
                  {products.map(product => (
                    <option key={product.id} value={product.id}>{product.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Get Quantity (Y)</label>
                <input
                  type="number"
                  value={formData.getQuantity}
                  onChange={(e) => setFormData({ ...formData, getQuantity: parseInt(e.target.value) || 1 })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  required
                  min="1"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Get Discount Type</label>
                <select
                  value={formData.getDiscountType}
                  onChange={(e) => setFormData({ ...formData, getDiscountType: e.target.value as 'free' | 'percentage' | 'fixed' })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                >
                  <option value="free">Free</option>
                  <option value="percentage">Percentage Off</option>
                  <option value="fixed">Fixed Amount Off</option>
                </select>
              </div>
              {formData.getDiscountType !== 'free' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Discount Value</label>
                  <input
                    type="number"
                    value={formData.getDiscountValue}
                    onChange={(e) => setFormData({ ...formData, getDiscountValue: parseFloat(e.target.value) || 0 })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                    required
                    min="0"
                  />
                </div>
              )}
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Valid From</label>
                <input
                  type="datetime-local"
                  value={formData.validFrom}
                  onChange={(e) => setFormData({ ...formData, validFrom: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Valid Until</label>
                <input
                  type="datetime-local"
                  value={formData.validUntil}
                  onChange={(e) => setFormData({ ...formData, validUntil: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent"
                  required
                />
              </div>
            </div>
            <div className="flex gap-3">
              <button
                type="submit"
                className="bg-black text-white px-6 py-2 rounded-lg font-medium hover:bg-gray-800 transition-colors"
              >
                {editingPromo ? 'Update' : 'Create'} Promotion
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowForm(false);
                  setEditingPromo(null);
                }}
                className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Rule</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Valid Period</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Usage</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {promos.map((promo) => (
                <tr key={promo.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{promo.name}</td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    Buy {promo.buyQuantity} Get {promo.getQuantity} {promo.getDiscountType === 'free' ? 'Free' : `${promo.getDiscountType} ${promo.getDiscountValue}`}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {promo.validFrom?.toDate ? new Date(promo.validFrom.toDate()).toLocaleDateString() : 'N/A'} - {promo.validUntil?.toDate ? new Date(promo.validUntil.toDate()).toLocaleDateString() : 'N/A'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{promo.usedCount} / {promo.usageLimit || '∞'}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-bold rounded-full ${
                      promo.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {promo.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      onClick={() => {
                        setEditingPromo(promo);
                        setFormData({
                          name: promo.name,
                          description: promo.description || '',
                          buyProductIds: promo.buyProductIds,
                          buyQuantity: promo.buyQuantity,
                          getProductIds: promo.getProductIds,
                          getQuantity: promo.getQuantity,
                          getDiscountType: promo.getDiscountType,
                          getDiscountValue: promo.getDiscountValue || 0,
                          validFrom: promo.validFrom?.toDate ? new Date(promo.validFrom.toDate()).toISOString().slice(0, 16) : '',
                          validUntil: promo.validUntil?.toDate ? new Date(promo.validUntil.toDate()).toISOString().slice(0, 16) : '',
                          usageLimit: promo.usageLimit || 0,
                        });
                        setShowForm(true);
                      }}
                      className="text-blue-600 hover:text-blue-900 mr-4"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(promo.id!)}
                      className="text-red-600 hover:text-red-900"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default BuyXGetYPage;

