'use client';

import React, { useState, useEffect } from 'react';
import { getAllAbandonedCarts, updateAbandonedCart } from '@/lib/firestore/campaigns_db';
import { AbandonedCart } from '@/lib/firestore/campaigns';
import { addEmailNotification } from '@/lib/firestore/notifications_db';
import Image from 'next/image';

const AbandonedCartsPage = () => {
  const [carts, setCarts] = useState<AbandonedCart[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'recovered' | 'unrecovered'>('unrecovered');

  useEffect(() => {
    fetchCarts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  const fetchCarts = async () => {
    setLoading(true);
    try {
      const recoveredFilter = filter === 'recovered' ? true : filter === 'unrecovered' ? false : undefined;
      console.log('Fetching abandoned carts with filter:', { filter, recoveredFilter });
      const data = await getAllAbandonedCarts(recoveredFilter);
      console.log('Fetched abandoned carts:', data?.length || 0, 'items');
      setCarts(data || []);
    } catch (error: unknown) {
      console.error('Failed to fetch abandoned carts:', error);
      // Show user-friendly error message
      const errorObj = error as { message?: string; code?: string };
      if (errorObj?.message?.includes('index') || errorObj?.code === 'failed-precondition') {
        const errorMsg = 'Firestore index is missing. Please check the console for the index creation link.';
        console.error('Index error details:', error);
        alert(errorMsg);
      } else {
        alert(`Failed to load abandoned carts: ${errorObj?.message || 'Unknown error'}`);
      }
      setCarts([]);
    } finally {
      setLoading(false);
    }
  };

  const sendRecoveryEmail = async (cart: AbandonedCart) => {
    if (!cart.userId || !cart.userEmail) {
      alert('User email not available');
      return;
    }

    try {
      const subject = 'Complete Your Purchase - Items Waiting in Your Cart';
      const body = `
        <h2>Don't Miss Out!</h2>
        <p>You left some items in your cart. Complete your purchase now!</p>
        <ul>
          ${cart.items.map(item => `<li>${item.productName} x ${item.quantity} - PKR ${item.price}</li>`).join('')}
        </ul>
        <p><strong>Total: PKR ${cart.totalAmount}</strong></p>
        <a href="/cart" style="display: inline-block; padding: 12px 24px; background: black; color: white; text-decoration: none; border-radius: 8px; margin-top: 16px;">Complete Purchase</a>
      `;

      await addEmailNotification({
        userId: cart.userId,
        type: 'order_confirmation',
        subject,
        body,
        sent: false,
      });

      await updateAbandonedCart(cart.id!, {
        recoveryEmailsSent: (cart.recoveryEmailsSent || 0) + 1,
      });

      alert('Recovery email sent!');
      fetchCarts();
    } catch (error) {
      console.error('Failed to send recovery email:', error);
      alert('Failed to send recovery email');
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-serif font-bold text-gray-900">Abandoned Carts</h1>
          <p className="text-gray-500 mt-1">Track and recover abandoned shopping carts</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === 'all' ? 'bg-black text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter('unrecovered')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === 'unrecovered' ? 'bg-black text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Unrecovered
          </button>
          <button
            onClick={() => setFilter('recovered')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              filter === 'recovered' ? 'bg-black text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Recovered
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Customer</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Items</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Total</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Last Updated</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Emails Sent</th>
                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {carts.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center">
                    <div className="text-gray-500">
                      <svg className="mx-auto h-12 w-12 text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
                      </svg>
                      <p className="text-lg font-medium text-gray-900 mb-1">No abandoned carts found</p>
                      <p className="text-sm">There are no abandoned carts {filter === 'recovered' ? 'that have been recovered' : filter === 'unrecovered' ? 'pending recovery' : ''} at this time.</p>
                    </div>
                  </td>
                </tr>
              ) : (
                carts.map((cart) => (
                <tr key={cart.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="text-sm">
                      <div className="font-medium text-gray-900">{cart.userName || 'Guest'}</div>
                      <div className="text-gray-500">{cart.userEmail || 'No email'}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      {cart.items.slice(0, 3).map((item, idx) => (
                        <div key={idx} className="relative w-12 h-12 rounded-lg overflow-hidden bg-gray-100">
                          <Image src={item.productImage} alt={item.productName} fill className="object-cover" unoptimized />
                        </div>
                      ))}
                      {cart.items.length > 3 && (
                        <div className="w-12 h-12 rounded-lg bg-gray-100 flex items-center justify-center text-xs font-bold text-gray-600">
                          +{cart.items.length - 3}
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">PKR {cart.totalAmount.toLocaleString()}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {cart.lastUpdated?.toDate ? new Date(cart.lastUpdated.toDate()).toLocaleDateString() : 'N/A'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{cart.recoveryEmailsSent || 0}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-bold rounded-full ${
                      cart.recovered ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                    }`}>
                      {cart.recovered ? 'Recovered' : 'Pending'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    {!cart.recovered && (
                      <button
                        onClick={() => sendRecoveryEmail(cart)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        Send Email
                      </button>
                    )}
                  </td>
                </tr>
              ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AbandonedCartsPage;

